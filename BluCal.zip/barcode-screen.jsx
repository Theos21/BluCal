// barcode-screen.jsx — Barcode scanner with three states:
//   'scanning'  → viewfinder + hint text
//   'found'     → bottom sheet with product details
//   'notfound'  → bottom sheet with empty state

// ─── Faux camera viewfinder background ─────────────────────────────────
function CameraView() {
  // Simulated camera feed: dark gradient + subtle noise + a barcode-ish shape
  // peeking near the scanning frame so the scanner feels in-context.
  return (
    <div style={{
      position: 'absolute', inset: 0,
      background: 'radial-gradient(ellipse 90% 70% at 50% 45%, #2a2724 0%, #181614 55%, #0a0907 100%)',
      overflow: 'hidden',
    }}>
      {/* Subtle vignette + grain via overlapping gradients */}
      <div style={{
        position: 'absolute', inset: 0,
        backgroundImage: 'radial-gradient(circle at 20% 30%, rgba(255,255,255,0.05) 0%, transparent 30%), radial-gradient(circle at 80% 70%, rgba(120,90,60,0.08) 0%, transparent 30%)',
      }} />
      {/* Hint of a packaged-food box silhouette on the right */}
      <div style={{
        position: 'absolute', right: -40, top: '20%', bottom: '20%',
        width: 200,
        background: 'linear-gradient(135deg, rgba(180,170,160,0.10) 0%, rgba(80,75,70,0.10) 100%)',
        borderRadius: 16,
        transform: 'rotate(-3deg)',
      }} />
      {/* Bottom darkening so the card pops */}
      <div style={{
        position: 'absolute', left: 0, right: 0, bottom: 0, height: '45%',
        background: 'linear-gradient(to bottom, transparent 0%, rgba(0,0,0,0.55) 100%)',
      }} />
      {/* Top darkening so the status bar reads */}
      <div style={{
        position: 'absolute', left: 0, right: 0, top: 0, height: 110,
        background: 'linear-gradient(to bottom, rgba(0,0,0,0.45) 0%, transparent 100%)',
      }} />
    </div>
  );
}

// ─── Camera status bar — always white ────────────────────────────────
function CameraStatusBar() {
  const c = '#fff';
  return (
    <div style={{
      position: 'relative', zIndex: 2,
      height: 54, padding: '14px 28px 0',
      display: 'flex', alignItems: 'center', justifyContent: 'space-between',
      fontSize: 17, fontWeight: 600, letterSpacing: -0.41, color: c,
      fontFamily: SF_STACK,
    }}>
      <span style={{ fontVariantNumeric: 'tabular-nums' }}>9:41</span>
      <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
        <svg width="18" height="11" viewBox="0 0 18 11">
          <rect x="0" y="7" width="3" height="4" rx="0.6" fill={c}/>
          <rect x="5" y="5" width="3" height="6" rx="0.6" fill={c}/>
          <rect x="10" y="3" width="3" height="8" rx="0.6" fill={c}/>
          <rect x="15" y="0" width="3" height="11" rx="0.6" fill={c}/>
        </svg>
        <svg width="26" height="12" viewBox="0 0 26 12">
          <rect x="0.5" y="0.5" width="22" height="11" rx="3" stroke={c} strokeOpacity="0.4" fill="none"/>
          <rect x="2" y="2" width="19" height="8" rx="1.5" fill={c}/>
          <rect x="23.5" y="4" width="1.5" height="4" rx="0.7" fill={c} fillOpacity="0.4"/>
        </svg>
      </div>
    </div>
  );
}

// ─── Top controls (close + flash) ─────────────────────────────────────
function CameraTopBar({ onDismiss }) {
  const pill = {
    width: 38, height: 38, borderRadius: 999,
    background: 'rgba(20,18,16,0.55)',
    backdropFilter: 'blur(10px)',
    border: '1px solid rgba(255,255,255,0.10)',
    display: 'flex', alignItems: 'center', justifyContent: 'center',
    cursor: 'pointer', color: '#fff',
  };
  return (
    <div style={{
      position: 'relative', zIndex: 2,
      padding: '8px 16px 0',
      display: 'flex', alignItems: 'center',
    }}>
      <button onClick={onDismiss} style={{ ...pill, border: 'none' }}>
        <BCIcon name="close" size={18} color="#fff" strokeWidth={2.2} />
      </button>
      <div style={{ flex: 1 }} />
      <button style={{ ...pill, border: 'none' }} aria-label="Toggle flash">
        {/* Flash bolt */}
        <svg width="16" height="20" viewBox="0 0 16 20" fill="none">
          <path d="M9 1L1 11h6l-1 8 8-11H8l1-7z" stroke="#fff" strokeWidth="1.6" strokeLinejoin="round"/>
        </svg>
      </button>
    </div>
  );
}

// ─── Scanning frame with corner brackets + scan line ──────────────────
function ScanFrame({ animate = false, dimmed = false }) {
  const stroke = dimmed ? '#fff' : '#fff';
  const op = dimmed ? 0.6 : 1;
  // Frame is 280 × 180, centered horizontally, ~ 1/3 from top of viewport.
  const W = 280, H = 180, BR = 24, T = 4; // bracket size 24, stroke 4
  const corner = (x, y, dx, dy) => (
    <svg width={BR} height={BR} viewBox={`0 0 ${BR} ${BR}`}
      style={{ position: 'absolute', left: x, top: y, opacity: op }}>
      <path
        d={`M ${dx < 0 ? BR : 0} ${dy === 0 ? T/2 : (dy < 0 ? BR : 0)} 
            L ${dx < 0 ? BR : 0} ${dy < 0 ? BR : 0} 
            L ${dx === 0 ? T/2 : (dx < 0 ? BR : 0)} ${dy < 0 ? BR : 0}`}
        fill="none" stroke={stroke} strokeWidth={T} strokeLinecap="round" strokeLinejoin="round"
      />
    </svg>
  );

  return (
    <div style={{
      position: 'absolute', left: '50%', top: '32%',
      transform: 'translate(-50%, -50%)',
      width: W, height: H,
    }}>
      {/* Corner brackets — each a small L drawn with SVG */}
      <CornerBracket pos="tl" />
      <CornerBracket pos="tr" />
      <CornerBracket pos="bl" />
      <CornerBracket pos="br" />

      {/* Scan line (vertical sweep) */}
      {animate && (
        <div style={{
          position: 'absolute', left: 10, right: 10,
          height: 2,
          background: 'linear-gradient(to right, transparent 0%, rgba(255,80,80,0.85) 20%, rgba(255,80,80,0.95) 50%, rgba(255,80,80,0.85) 80%, transparent 100%)',
          boxShadow: '0 0 14px rgba(255,80,80,0.7)',
          animation: 'bc-scanline 2s ease-in-out infinite',
          willChange: 'transform',
        }} />
      )}
      {!animate && (
        <div style={{
          position: 'absolute', left: 10, right: 10, top: '50%',
          height: 2,
          background: 'linear-gradient(to right, transparent 0%, rgba(255,80,80,0.85) 20%, rgba(255,80,80,0.95) 50%, rgba(255,80,80,0.85) 80%, transparent 100%)',
          boxShadow: '0 0 14px rgba(255,80,80,0.7)',
        }} />
      )}

      <style>{`
        @keyframes bc-scanline {
          0% { transform: translateY(8px); opacity: 0.4; }
          50% { transform: translateY(168px); opacity: 1; }
          100% { transform: translateY(8px); opacity: 0.4; }
        }
        @keyframes bc-corner-pulse {
          0%, 100% { opacity: 0.7; }
          50% { opacity: 1; }
        }
      `}</style>
    </div>
  );
}

function CornerBracket({ pos }) {
  // 24×24 SVG of an L-shape; orientation by pos.
  const T = 4, L = 24;
  const path = {
    tl: `M 2 ${L} L 2 2 L ${L} 2`,
    tr: `M ${L-2} 2 L ${L-2} ${L} M ${L-2} 2 L 0 2`,
    bl: `M 2 0 L 2 ${L-2} L ${L} ${L-2}`,
    br: `M 0 ${L-2} L ${L-2} ${L-2} L ${L-2} 0`,
  }[pos];
  const style = {
    position: 'absolute',
    [pos[0] === 't' ? 'top' : 'bottom']: -2,
    [pos[1] === 'l' ? 'left' : 'right']: -2,
    animation: 'bc-corner-pulse 2s ease-in-out infinite',
  };
  return (
    <svg width={L} height={L} viewBox={`0 0 ${L} ${L}`} style={style}>
      <path d={path} fill="none" stroke="#fff" strokeWidth={T} strokeLinecap="round" strokeLinejoin="round"/>
    </svg>
  );
}

// ─── Hint pill ────────────────────────────────────────────────────────
function HintPill({ children, tone = 'default' }) {
  const bg = tone === 'danger' ? 'rgba(216,54,47,0.85)' : 'rgba(20,18,16,0.55)';
  return (
    <div style={{
      position: 'absolute', left: '50%', top: '32%',
      transform: 'translate(-50%, 120px)',
      padding: '8px 16px',
      background: bg,
      backdropFilter: 'blur(10px)',
      borderRadius: 999,
      color: '#fff',
      fontSize: 14, fontWeight: 600, letterSpacing: -0.1,
      border: '1px solid rgba(255,255,255,0.10)',
      display: 'inline-flex', alignItems: 'center', gap: 8,
      whiteSpace: 'nowrap',
    }}>
      {children}
    </div>
  );
}

// ─── Product image placeholder ────────────────────────────────────────
function ProductImage({ tone = 'amber' }) {
  // Stylized packaged-food box; not a real product, just a placeholder.
  return (
    <div style={{
      width: 64, height: 64, borderRadius: 12,
      background: tone === 'amber' ? '#E8B978' : '#C8D6B8',
      position: 'relative', flexShrink: 0,
      overflow: 'hidden',
      border: '1px solid rgba(0,0,0,0.06)',
    }}>
      <div style={{
        position: 'absolute', left: 8, right: 8, top: 10, height: 8, background: 'rgba(20,16,10,0.4)', borderRadius: 2,
      }}/>
      <div style={{
        position: 'absolute', left: 12, right: 12, top: 22, height: 4, background: 'rgba(20,16,10,0.25)', borderRadius: 2,
      }}/>
      <div style={{
        position: 'absolute', left: 8, right: 8, bottom: 8, height: 18, background: 'rgba(255,255,255,0.6)', borderRadius: 3,
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        gap: 1.5, padding: '0 4px',
      }}>
        {/* Mini barcode lines */}
        {[2, 1, 1.5, 1, 2.5, 1, 1.5, 1, 1, 2, 1.5, 1].map((w, i) => (
          <div key={i} style={{ width: w, height: '70%', background: '#0E0E0E' }} />
        ))}
      </div>
    </div>
  );
}

// ─── Product card (found state) ───────────────────────────────────────
function ProductCard({ mode }) {
  const t = mode === 'dark' ? BC_DARK : BC_LIGHT;
  const [servings, setServings] = React.useState(1);

  return (
    <div style={{
      position: 'relative', zIndex: 3,
      background: t.surface,
      borderTopLeftRadius: 24, borderTopRightRadius: 24,
      boxShadow: '0 -10px 40px rgba(0,0,0,0.30)',
      padding: '12px 18px 22px',
    }}>
      {/* Grabber */}
      <div style={{ display: 'flex', justifyContent: 'center', marginBottom: 12 }}>
        <div style={{ width: 38, height: 5, borderRadius: 999, background: t.hairline }} />
      </div>

      {/* Header row — image + name */}
      <div style={{ display: 'flex', gap: 14, alignItems: 'flex-start' }}>
        <ProductImage />
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ fontSize: 18, fontWeight: 700, color: t.text, letterSpacing: -0.4, lineHeight: '22px' }}>
            Chocolate Chip Clif Bar
          </div>
          <div style={{ fontSize: 13, color: t.textSec, marginTop: 4, fontWeight: 500 }}>
            Clif Bar &amp; Company · 68 g bar
          </div>
          <div style={{ marginTop: 8 }}>
            <BCBadge tone="success" size="sm" dot>Verified</BCBadge>
          </div>
        </div>
      </div>

      {/* Macro pills */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 8, marginTop: 16 }}>
        {[
          ['kcal', '250', t.text],
          ['Protein', '9g',  t.protein],
          ['Carbs',   '45g', t.carbs],
          ['Fat',     '6g',  t.fat],
        ].map(([label, val, color]) => (
          <div key={label} style={{
            background: t.surface2, borderRadius: 10,
            padding: '10px 10px 8px', textAlign: 'center',
          }}>
            <div style={{ fontSize: 17, fontWeight: 700, color, letterSpacing: -0.3, fontVariantNumeric: 'tabular-nums' }}>{val}</div>
            <div style={{ fontSize: 10, fontWeight: 700, letterSpacing: 0.4, textTransform: 'uppercase', color: t.textTer, marginTop: 2 }}>{label}</div>
          </div>
        ))}
      </div>

      {/* Serving + unit selector */}
      <div style={{
        marginTop: 14, padding: '10px 12px',
        background: t.surface2, borderRadius: 12,
        display: 'flex', alignItems: 'center', gap: 12,
      }}>
        <div style={{ fontSize: 13, fontWeight: 600, color: t.textSec, letterSpacing: -0.1 }}>Servings</div>
        <div style={{ flex: 1 }} />
        <div style={{
          display: 'inline-flex', alignItems: 'center',
          background: t.surface, borderRadius: 999, padding: 3,
          border: '1px solid ' + t.separator,
        }}>
          <button onClick={() => setServings(s => Math.max(0.25, +(s - 0.25).toFixed(2)))} style={{
            width: 28, height: 28, borderRadius: 999, border: 'none', background: 'transparent',
            color: t.text, fontSize: 18, cursor: 'pointer', padding: 0,
          }}>−</button>
          <div style={{ width: 44, textAlign: 'center', fontSize: 14, fontWeight: 700, color: t.text, fontVariantNumeric: 'tabular-nums' }}>{servings}</div>
          <button onClick={() => setServings(s => +(s + 0.25).toFixed(2))} style={{
            width: 28, height: 28, borderRadius: 999, border: 'none', background: 'transparent',
            color: t.text, fontSize: 18, cursor: 'pointer', padding: 0,
          }}>+</button>
        </div>
        <div style={{
          display: 'inline-flex', alignItems: 'center', gap: 4,
          padding: '5px 10px 5px 12px',
          background: t.surface, borderRadius: 999,
          border: '1px solid ' + t.separator,
          fontSize: 14, fontWeight: 600, color: t.text,
          cursor: 'pointer',
        }}>
          bar
          <BCIcon name="caret-down" size={14} color={t.textSec} />
        </div>
      </div>

      {/* CTA */}
      <div style={{ marginTop: 14 }}>
        <BCButton kind="primary" size="lg" block icon={<BCIcon name="plus" size={20} color="#fff" strokeWidth={2.4}/>}>
          Add to log
        </BCButton>
      </div>
    </div>
  );
}

// ─── Not-found card ───────────────────────────────────────────────────
function NotFoundCard({ mode }) {
  const t = mode === 'dark' ? BC_DARK : BC_LIGHT;
  return (
    <div style={{
      position: 'relative', zIndex: 3,
      background: t.surface,
      borderTopLeftRadius: 24, borderTopRightRadius: 24,
      boxShadow: '0 -10px 40px rgba(0,0,0,0.30)',
      padding: '12px 18px 22px',
    }}>
      <div style={{ display: 'flex', justifyContent: 'center', marginBottom: 12 }}>
        <div style={{ width: 38, height: 5, borderRadius: 999, background: t.hairline }} />
      </div>

      <div style={{ display: 'flex', gap: 14, alignItems: 'center' }}>
        <div style={{
          width: 56, height: 56, borderRadius: 14,
          background: t.warnSoft, color: t.warn,
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          flexShrink: 0,
        }}>
          <BCIcon name="info" size={26} color={t.warn} />
        </div>
        <div style={{ flex: 1 }}>
          <div style={{ fontSize: 17, fontWeight: 700, color: t.text, letterSpacing: -0.3 }}>
            Product not found
          </div>
          <div style={{ fontSize: 13, color: t.textSec, marginTop: 4, lineHeight: '18px' }}>
            We couldn't match this barcode. Try another product, or add it as a custom food.
          </div>
        </div>
      </div>

      <div style={{ marginTop: 14, fontFamily: 'ui-monospace, SFMono-Regular, Menlo, monospace',
        fontSize: 12, color: t.textTer, padding: '8px 12px',
        background: t.surface2, borderRadius: 8, letterSpacing: 0.4 }}>
        UPC <span style={{ color: t.text, fontWeight: 600 }}>0 72225 87193 4</span>
      </div>

      <div style={{ marginTop: 14, display: 'flex', gap: 10 }}>
        <BCButton kind="secondary" size="lg" style={{ flex: 1 }}>Try again</BCButton>
        <BCButton kind="primary" size="lg" style={{ flex: 1 }}
          icon={<BCIcon name="plus" size={18} color="#fff" strokeWidth={2.4}/>}>
          Add as custom
        </BCButton>
      </div>
    </div>
  );
}

// ─── Screen ───────────────────────────────────────────────────────────
function BarcodeScreen({ mode = 'light', state = 'scanning', onDismiss }) {
  const animate = state === 'scanning';

  return (
    <div style={{
      position: 'relative', height: '100%', width: '100%',
      overflow: 'hidden',
      background: '#000',
      fontFamily: SF_STACK,
    }}>
      <CameraView />
      <CameraStatusBar />
      <CameraTopBar onDismiss={onDismiss} />

      <ScanFrame animate={animate} dimmed={state !== 'scanning'} />

      {state === 'scanning' && (
        <HintPill>
          <span style={{ display: 'inline-block', width: 8, height: 8, borderRadius: 999, background: '#FF5050',
            boxShadow: '0 0 8px rgba(255,80,80,0.8)',
            animation: 'bc-corner-pulse 1.2s ease-in-out infinite',
          }} />
          Point at any barcode
        </HintPill>
      )}

      {/* Bottom card slot */}
      <div style={{
        position: 'absolute', left: 0, right: 0, bottom: 0,
      }}>
        {state === 'found'    && <ProductCard mode={mode} />}
        {state === 'notfound' && <NotFoundCard mode={mode} />}
      </div>
    </div>
  );
}

// ─── Interactive walkthrough — cycle states ───────────────────────────
function BarcodeWalkthrough({ mode = 'light' }) {
  const [state, setState] = React.useState('scanning');
  React.useEffect(() => {
    if (state !== 'scanning') return;
    const id = setTimeout(() => setState('found'), 2800);
    return () => clearTimeout(id);
  }, [state]);

  return (
    <div style={{ position: 'relative', height: '100%' }}>
      <BarcodeScreen mode={mode} state={state} />
      {/* Walkthrough state pills — top center, below status bar */}
      <div style={{
        position: 'absolute', top: 70, left: '50%', transform: 'translateX(-50%)',
        zIndex: 50, display: 'flex', gap: 6,
        background: 'rgba(20,18,16,0.55)', backdropFilter: 'blur(10px)',
        padding: 4, borderRadius: 999,
        border: '1px solid rgba(255,255,255,0.10)',
      }}>
        {['scanning', 'found', 'notfound'].map(s => (
          <button key={s} onClick={() => setState(s)} style={{
            padding: '5px 11px', borderRadius: 999, border: 'none', cursor: 'pointer',
            background: state === s ? '#fff' : 'transparent',
            color: state === s ? '#111' : '#fff',
            fontSize: 11, fontWeight: 700, letterSpacing: 0.2, textTransform: 'uppercase',
            fontFamily: SF_STACK,
          }}>{s === 'notfound' ? 'not found' : s}</button>
        ))}
      </div>
    </div>
  );
}

Object.assign(window, { BarcodeScreen, BarcodeWalkthrough });
