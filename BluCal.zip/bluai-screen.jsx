// bluai-screen.jsx — BluAI photo-to-macros, three states:
//   'camera'   → viewfinder + shutter + gallery picker
//   'analyzing'→ photo + scanning overlay + spinner
//   'results'  → photo (top) + detected items list + totals + CTA

// ─── Status / top bars reused style ────────────────────────────────────
function BAStatusBar({ light = false }) {
  const c = light ? '#fff' : '#000';
  return (
    <div style={{
      position: 'relative', zIndex: 5,
      height: 54, padding: '14px 28px 0',
      display: 'flex', alignItems: 'center', justifyContent: 'space-between',
      fontSize: 17, fontWeight: 600, letterSpacing: -0.41, color: c,
      fontFamily: SF_STACK,
    }}>
      <span style={{ fontVariantNumeric: 'tabular-nums' }}>9:41</span>
      <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
        <svg width="18" height="11" viewBox="0 0 18 11">
          <rect x="0" y="7" width="3" height="4" rx="0.6" fill={c}/>
          <rect x="5" y="5" width="3" height="6" rx="0.6" fill={c}/>
          <rect x="10" y="3" width="3" height="8" rx="0.6" fill={c}/>
          <rect x="15" y="0" width="3" height="11" rx="0.6" fill={c}/>
        </svg>
        <svg width="26" height="12" viewBox="0 0 26 12">
          <rect x="0.5" y="0.5" width="22" height="11" rx="3" stroke={c} strokeOpacity="0.4" fill="none"/>
          <rect x="2" y="2" width="19" height="8" rx="1.5" fill={c}/>
          <rect x="23.5" y="4" width="1.5" height="4" rx="0.7" fill={c} fillOpacity="0.4"/>
        </svg>
      </div>
    </div>
  );
}

function BATopBar({ onDismiss, light = true, title }) {
  const pill = {
    width: 38, height: 38, borderRadius: 999,
    background: light ? 'rgba(20,18,16,0.45)' : 'rgba(20,18,16,0.08)',
    backdropFilter: 'blur(10px)',
    border: light ? '1px solid rgba(255,255,255,0.10)' : '1px solid rgba(0,0,0,0.06)',
    display: 'flex', alignItems: 'center', justifyContent: 'center',
    cursor: 'pointer',
  };
  return (
    <div style={{
      position: 'relative', zIndex: 5,
      padding: '6px 16px 0',
      display: 'flex', alignItems: 'center', gap: 10,
    }}>
      <button onClick={onDismiss} style={{ ...pill, border: 'none' }}>
        <BCIcon name="close" size={18} color={light ? '#fff' : '#111'} strokeWidth={2.2} />
      </button>
      <div style={{ flex: 1, textAlign: 'center', color: light ? '#fff' : '#111', fontSize: 16, fontWeight: 700, letterSpacing: -0.2, display: 'inline-flex', alignItems: 'center', gap: 6, justifyContent: 'center' }}>
        <BluAIBadge />
        {title || 'BluAI'}
      </div>
      <button style={{ ...pill, border: 'none' }} aria-label="Help">
        <BCIcon name="info" size={18} color={light ? '#fff' : '#111'} strokeWidth={2} />
      </button>
    </div>
  );
}

// Small sparkle-mark used in headers/buttons to signal "AI"
function BluAIBadge({ size = 18, color = 'currentColor' }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none">
      <path d="M12 3 L13.5 9.5 L20 11 L13.5 12.5 L12 19 L10.5 12.5 L4 11 L10.5 9.5 Z" fill={color}/>
      <circle cx="19" cy="5" r="1.4" fill={color}/>
      <circle cx="5" cy="19" r="1.1" fill={color}/>
    </svg>
  );
}

// ─── Faux meal photo background ────────────────────────────────────────
function MealPhoto({ rounded = false }) {
  // Stylized overhead-bowl photo placeholder.
  return (
    <div style={{
      position: 'absolute', inset: 0, overflow: 'hidden',
      borderRadius: rounded ? 22 : 0,
      background: 'radial-gradient(ellipse 90% 80% at 50% 60%, #4a3a26 0%, #2c2418 60%, #15110a 100%)',
    }}>
      {/* Plate ring */}
      <div style={{
        position: 'absolute', left: '50%', top: '52%', transform: 'translate(-50%, -50%)',
        width: '78%', aspectRatio: '1 / 1', borderRadius: '50%',
        background: 'radial-gradient(circle at 35% 30%, #f1e8d6 0%, #e0d2b3 60%, #c9b894 100%)',
        boxShadow: '0 30px 60px rgba(0,0,0,0.40), inset 0 0 0 6px rgba(255,255,255,0.10)',
      }} />
      {/* Food clusters */}
      <div style={{
        position: 'absolute', left: '34%', top: '42%',
        width: 80, height: 60, borderRadius: '50%',
        background: 'radial-gradient(ellipse at 40% 30%, #c46a32 0%, #8c3e15 100%)',
        filter: 'blur(0.3px)',
        transform: 'rotate(-8deg)',
      }} />
      <div style={{
        position: 'absolute', left: '46%', top: '40%',
        width: 70, height: 65, borderRadius: '46%',
        background: 'radial-gradient(circle at 40% 30%, #f4c870 0%, #c8801c 100%)',
        transform: 'rotate(10deg)',
      }} />
      <div style={{
        position: 'absolute', left: '38%', top: '54%',
        width: 100, height: 50, borderRadius: '50%',
        background: 'radial-gradient(ellipse at 50% 30%, #6da554 0%, #2f5d2a 100%)',
        transform: 'rotate(-4deg)',
      }} />
      <div style={{
        position: 'absolute', left: '52%', top: '55%',
        width: 60, height: 70, borderRadius: '50%',
        background: 'radial-gradient(ellipse at 40% 35%, #f0e3a8 0%, #c9a85a 100%)',
        transform: 'rotate(6deg)',
      }} />
      <div style={{
        position: 'absolute', left: '40%', top: '60%',
        width: 50, height: 40, borderRadius: '50%',
        background: 'radial-gradient(circle at 40% 30%, #d24a3a 0%, #8a221a 100%)',
      }} />
      {/* Soft top gradient for status-bar legibility */}
      <div style={{
        position: 'absolute', left: 0, right: 0, top: 0, height: 120,
        background: 'linear-gradient(to bottom, rgba(0,0,0,0.50) 0%, transparent 100%)',
      }} />
    </div>
  );
}

// ─── Scanning overlay (analyzing state) ────────────────────────────────
function ScanningOverlay() {
  return (
    <div style={{ position: 'absolute', inset: 0, pointerEvents: 'none' }}>
      {/* Gentle bluish tint */}
      <div style={{
        position: 'absolute', inset: 0,
        background: 'radial-gradient(circle at 50% 50%, rgba(24,95,165,0.18) 0%, rgba(0,0,0,0.0) 60%)',
      }} />
      {/* Horizontal scan band */}
      <div style={{
        position: 'absolute', left: 0, right: 0, height: 80,
        background: 'linear-gradient(to bottom, transparent 0%, rgba(79,149,220,0.40) 50%, transparent 100%)',
        animation: 'ba-scan 2.4s linear infinite',
      }} />
      {/* Mesh dots — recognized regions hinted at */}
      {[
        { x: 32, y: 42, d: 0 },
        { x: 50, y: 38, d: 0.3 },
        { x: 60, y: 52, d: 0.6 },
        { x: 40, y: 58, d: 0.9 },
        { x: 52, y: 60, d: 1.2 },
      ].map((p, i) => (
        <div key={i} style={{
          position: 'absolute', left: `${p.x}%`, top: `${p.y}%`,
          width: 12, height: 12, marginLeft: -6, marginTop: -6,
          border: '2px solid #4F95DC',
          borderRadius: 999,
          background: 'rgba(79,149,220,0.15)',
          animation: `ba-blip 1.6s ease-in-out ${p.d}s infinite`,
          boxShadow: '0 0 12px rgba(79,149,220,0.7)',
        }} />
      ))}
      <style>{`
        @keyframes ba-scan {
          0%   { top: -80px; }
          100% { top: 100%; }
        }
        @keyframes ba-blip {
          0%, 100% { transform: scale(0.6); opacity: 0.3; }
          50%      { transform: scale(1.4); opacity: 1; }
        }
        @keyframes ba-spin { to { transform: rotate(360deg) } }
      `}</style>
    </div>
  );
}

// ─── Camera state ──────────────────────────────────────────────────────
function CameraState({ onDismiss, onShutter }) {
  return (
    <>
      {/* Faux camera view (live preview placeholder) */}
      <div style={{
        position: 'absolute', inset: 0,
        background: 'radial-gradient(ellipse 90% 70% at 50% 40%, #2a2724 0%, #181614 55%, #0a0907 100%)',
      }}>
        {/* Hint of a meal scene  */}
        <div style={{
          position: 'absolute', left: '50%', top: '46%', transform: 'translate(-50%, -50%)',
          width: '70%', aspectRatio: '1 / 1', borderRadius: '50%',
          background: 'radial-gradient(circle at 35% 30%, rgba(241,232,214,0.45) 0%, rgba(201,184,148,0.25) 60%, transparent 100%)',
          filter: 'blur(8px)',
        }} />
        <div style={{
          position: 'absolute', left: 0, right: 0, bottom: 0, height: '40%',
          background: 'linear-gradient(to bottom, transparent 0%, rgba(0,0,0,0.6) 100%)',
        }} />
      </div>
      <BAStatusBar light />
      <BATopBar onDismiss={onDismiss} light />

      {/* Centered hint */}
      <div style={{
        position: 'absolute', left: '50%', top: '38%', transform: 'translate(-50%, -50%)',
        textAlign: 'center', color: '#fff', zIndex: 5,
      }}>
        <div style={{
          width: 60, height: 60, borderRadius: 999,
          background: 'rgba(79,149,220,0.18)',
          border: '1px solid rgba(255,255,255,0.18)',
          display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
          color: '#9DC3EE',
          backdropFilter: 'blur(10px)',
          marginBottom: 14,
        }}>
          <BluAIBadge size={30} color="#fff" />
        </div>
        <div style={{ fontSize: 22, fontWeight: 700, letterSpacing: -0.4 }}>Point at your meal</div>
        <div style={{ fontSize: 14, marginTop: 6, color: 'rgba(255,255,255,0.75)', maxWidth: 260, marginLeft: 'auto', marginRight: 'auto', lineHeight: '20px' }}>
          BluAI will detect every item on your plate and estimate macros.
        </div>
      </div>

      {/* Shutter row */}
      <div style={{
        position: 'absolute', left: 0, right: 0, bottom: 0, zIndex: 5,
        padding: '0 28px 36px',
        display: 'flex', alignItems: 'center', justifyContent: 'space-between',
      }}>
        {/* Gallery */}
        <button style={{
          width: 52, height: 52, borderRadius: 14,
          background: 'rgba(20,18,16,0.55)',
          backdropFilter: 'blur(10px)',
          border: '1px solid rgba(255,255,255,0.18)',
          display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer',
        }} aria-label="Pick from library">
          {/* gallery icon: image stack */}
          <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#fff" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
            <rect x="3" y="3" width="14" height="14" rx="2"/>
            <circle cx="9" cy="9" r="1.5" fill="#fff" stroke="none"/>
            <path d="M3 14l4-4 4 4 3-3 3 3"/>
            <path d="M7 21h12a2 2 0 0 0 2-2V7"/>
          </svg>
        </button>

        {/* Shutter */}
        <button onClick={onShutter} style={{
          width: 76, height: 76, borderRadius: 999,
          background: 'rgba(255,255,255,0.10)',
          border: '4px solid rgba(255,255,255,0.95)',
          padding: 6,
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          cursor: 'pointer',
        }} aria-label="Capture">
          <div style={{
            width: '100%', height: '100%', borderRadius: 999,
            background: '#fff',
          }} />
        </button>

        {/* Flip camera */}
        <button style={{
          width: 52, height: 52, borderRadius: 14,
          background: 'rgba(20,18,16,0.55)',
          backdropFilter: 'blur(10px)',
          border: '1px solid rgba(255,255,255,0.18)',
          display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer',
        }} aria-label="Flip camera">
          <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#fff" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
            <path d="M3 7h4l2-3h6l2 3h4v12H3z"/>
            <circle cx="12" cy="13" r="3.5"/>
            <path d="M15 11l2-2-2-2 M9 15l-2 2 2 2" opacity="0.6"/>
          </svg>
        </button>
      </div>
    </>
  );
}

// ─── Analyzing state ───────────────────────────────────────────────────
function AnalyzingState({ onDismiss }) {
  return (
    <>
      <MealPhoto />
      <ScanningOverlay />
      <BAStatusBar light />
      <BATopBar onDismiss={onDismiss} light />

      {/* Centered analysis card */}
      <div style={{
        position: 'absolute', left: '50%', bottom: '12%', transform: 'translateX(-50%)',
        background: 'rgba(20,18,16,0.55)',
        backdropFilter: 'blur(14px)',
        border: '1px solid rgba(255,255,255,0.12)',
        borderRadius: 18,
        padding: '14px 18px',
        display: 'flex', alignItems: 'center', gap: 12,
        color: '#fff', zIndex: 5,
        minWidth: 260,
      }}>
        <div style={{
          width: 24, height: 24, borderRadius: 999,
          border: '2.5px solid rgba(255,255,255,0.3)',
          borderTopColor: '#fff',
          animation: 'ba-spin 0.8s linear infinite',
        }} />
        <div>
          <div style={{ fontSize: 15, fontWeight: 700, letterSpacing: -0.2 }}>Analyzing your meal…</div>
          <div style={{ fontSize: 12, color: 'rgba(255,255,255,0.75)', marginTop: 2 }}>Detecting items · estimating quantity</div>
        </div>
      </div>
    </>
  );
}

// ─── Confidence dot ────────────────────────────────────────────────────
function ConfidenceDot({ level, label = true, mode = 'light' }) {
  const t = mode === 'dark' ? BC_DARK : BC_LIGHT;
  const map = {
    high: [t.success, 'High'],
    med:  [t.warn,    'Medium'],
    low:  [t.danger,  'Low'],
  };
  const [color, name] = map[level] || map.med;
  return (
    <span style={{ display: 'inline-flex', alignItems: 'center', gap: 5 }}>
      <span style={{ width: 7, height: 7, borderRadius: 999, background: color }} />
      {label && (
        <span style={{ fontSize: 11, fontWeight: 700, color, letterSpacing: 0.2, textTransform: 'uppercase' }}>{name}</span>
      )}
    </span>
  );
}

// ─── Detected item row ─────────────────────────────────────────────────
function ItemRow({ mode, item, checked, onToggle }) {
  const t = mode === 'dark' ? BC_DARK : BC_LIGHT;
  return (
    <div style={{
      display: 'flex', alignItems: 'flex-start', gap: 12,
      padding: '12px 0',
      borderBottom: '0.5px solid ' + t.separator,
      opacity: checked ? 1 : 0.55,
    }}>
      {/* Checkbox */}
      <button onClick={onToggle} style={{
        width: 22, height: 22, borderRadius: 6,
        background: checked ? t.primary : 'transparent',
        border: `1.8px solid ${checked ? t.primary : t.hairline}`,
        color: '#fff', flexShrink: 0,
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        cursor: 'pointer', padding: 0, marginTop: 1,
      }}>
        {checked && <BCIcon name="check" size={14} color="#fff" strokeWidth={2.8} />}
      </button>

      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
          <div style={{
            fontSize: 15, fontWeight: 700, color: t.text, letterSpacing: -0.24,
            whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis', minWidth: 0,
          }}>{item.name}</div>
          <ConfidenceDot level={item.conf} label={false} mode={mode} />
        </div>
        <div style={{ fontSize: 12, color: t.textSec, marginTop: 2, letterSpacing: -0.1 }}>
          {item.quantity}
        </div>
        {/* macros pill row */}
        <div style={{
          display: 'flex', gap: 12,
          marginTop: 8,
          fontSize: 12, fontWeight: 600,
          fontVariantNumeric: 'tabular-nums',
        }}>
          <span style={{ color: t.text }}>{item.kcal} <span style={{ color: t.textTer, fontWeight: 500 }}>kcal</span></span>
          <span style={{ color: t.protein }}>{item.p}p</span>
          <span style={{ color: t.carbs }}>{item.c}c</span>
          <span style={{ color: t.fat }}>{item.f}f</span>
        </div>
      </div>

      <button style={{
        height: 30, padding: '0 10px',
        background: 'transparent', border: '1px solid ' + t.separator, borderRadius: 8,
        color: t.text, fontSize: 12, fontWeight: 600, letterSpacing: -0.1,
        cursor: 'pointer', flexShrink: 0, marginTop: 1,
        fontFamily: SF_STACK,
      }}>Edit</button>
    </div>
  );
}

// ─── Results state ─────────────────────────────────────────────────────
const BA_ITEMS = [
  { name: 'Grilled chicken',         quantity: '~ 4 oz · 113 g',  kcal: 165, p: 31, c: 0,  f: 4,  conf: 'high' },
  { name: 'Brown rice',              quantity: '~ ¾ cup · 150 g', kcal: 165, p: 4,  c: 35, f: 1,  conf: 'high' },
  { name: 'Roasted sweet potato',    quantity: '~ ½ cup · 100 g', kcal: 90,  p: 2,  c: 21, f: 0,  conf: 'med'  },
  { name: 'Broccoli, steamed',       quantity: '~ 1 cup · 90 g',  kcal: 30,  p: 3,  c: 6,  f: 0,  conf: 'high' },
  { name: 'Cherry tomatoes',         quantity: '~ 6 pieces',      kcal: 18,  p: 1,  c: 4,  f: 0,  conf: 'med'  },
  { name: 'Tahini drizzle',          quantity: '~ 1 tbsp',        kcal: 90,  p: 3,  c: 3,  f: 8,  conf: 'low'  },
];

function ResultsState({ mode = 'light', onDismiss }) {
  const t = mode === 'dark' ? BC_DARK : BC_LIGHT;
  const [checks, setChecks] = React.useState(() => BA_ITEMS.map(() => true));
  const toggle = (i) => setChecks(cs => cs.map((v, j) => j === i ? !v : v));

  // Sum included macros
  const tot = BA_ITEMS.reduce((acc, it, i) => {
    if (!checks[i]) return acc;
    return {
      kcal: acc.kcal + it.kcal,
      p: acc.p + it.p, c: acc.c + it.c, f: acc.f + it.f,
    };
  }, { kcal: 0, p: 0, c: 0, f: 0 });
  const includedCount = checks.filter(Boolean).length;

  return (
    <div style={{
      position: 'relative', height: '100%', width: '100%',
      background: t.bg, color: t.text,
      fontFamily: SF_STACK,
    }}>
      {/* Photo region — top 40% */}
      <div style={{ position: 'absolute', left: 0, right: 0, top: 0, height: '40%' }}>
        <MealPhoto />
        <BAStatusBar light />
        <BATopBar onDismiss={onDismiss} light />

        {/* AI summary chip */}
        <div style={{
          position: 'absolute', left: '50%', bottom: 12, transform: 'translateX(-50%)',
          padding: '6px 12px', borderRadius: 999,
          background: 'rgba(20,18,16,0.55)',
          backdropFilter: 'blur(10px)',
          border: '1px solid rgba(255,255,255,0.16)',
          color: '#fff', fontSize: 12, fontWeight: 700, letterSpacing: 0.2,
          display: 'inline-flex', alignItems: 'center', gap: 6,
          textTransform: 'uppercase',
        }}>
          <BluAIBadge size={12} color="#fff" />
          BluAI detected {BA_ITEMS.length} items
        </div>
      </div>

      {/* Results region — below photo, with rounded top corners overlapping photo */}
      <div style={{
        position: 'absolute', left: 0, right: 0, top: 'calc(40% - 14px)', bottom: 0,
        background: t.bg,
        borderTopLeftRadius: 22, borderTopRightRadius: 22,
        boxShadow: '0 -6px 16px rgba(0,0,0,0.20)',
        display: 'flex', flexDirection: 'column',
        overflow: 'hidden',
      }}>
        {/* header line */}
        <div style={{
          padding: '14px 18px 10px',
          display: 'flex', alignItems: 'center', gap: 10,
          borderBottom: '0.5px solid ' + t.separator,
        }}>
          <div style={{ flex: 1 }}>
            <div style={{ fontSize: 17, fontWeight: 700, color: t.text, letterSpacing: -0.4 }}>
              Detected items
            </div>
            <div style={{ fontSize: 12, color: t.textSec, marginTop: 2 }}>
              {includedCount} of {BA_ITEMS.length} selected · tap to toggle
            </div>
          </div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
            <ConfidenceDot level="high" mode={mode} />
            <ConfidenceDot level="med" mode={mode} />
            <ConfidenceDot level="low" mode={mode} />
          </div>
        </div>

        {/* Item list (scrolls) */}
        <div style={{ flex: 1, padding: '0 18px', overflowY: 'auto', overflowX: 'hidden' }}>
          {BA_ITEMS.map((it, i) => (
            <ItemRow key={it.name} mode={mode} item={it} checked={checks[i]} onToggle={() => toggle(i)} />
          ))}
        </div>

        {/* Totals + CTAs */}
        <div style={{
          padding: '12px 18px 22px',
          borderTop: '0.5px solid ' + t.separator,
          background: t.surface,
        }}>
          <div style={{
            display: 'flex', alignItems: 'center', gap: 12,
            padding: '6px 0 12px',
          }}>
            <div style={{ flex: 1 }}>
              <div style={{
                fontSize: 11, fontWeight: 700, letterSpacing: 0.6, textTransform: 'uppercase',
                color: t.textTer,
              }}>Total</div>
              <div style={{
                fontSize: 22, fontWeight: 800, color: t.text, letterSpacing: -0.4,
                fontVariantNumeric: 'tabular-nums', lineHeight: 1,
                marginTop: 4,
              }}>{tot.kcal}<span style={{ fontSize: 13, color: t.textSec, fontWeight: 600, marginLeft: 4 }}>kcal</span></div>
            </div>
            <div style={{ display: 'flex', gap: 14, fontSize: 13, fontWeight: 700, fontVariantNumeric: 'tabular-nums' }}>
              <span><span style={{ color: t.protein }}>{tot.p}g</span><div style={{ fontSize: 10, color: t.textTer, marginTop: 2, fontWeight: 600 }}>protein</div></span>
              <span><span style={{ color: t.carbs }}>{tot.c}g</span><div style={{ fontSize: 10, color: t.textTer, marginTop: 2, fontWeight: 600 }}>carbs</div></span>
              <span><span style={{ color: t.fat }}>{tot.f}g</span><div style={{ fontSize: 10, color: t.textTer, marginTop: 2, fontWeight: 600 }}>fat</div></span>
            </div>
          </div>
          <BCButton kind="primary" size="lg" block
            icon={<BCIcon name="plus" size={20} color="#fff" strokeWidth={2.4} />}>
            Add all to log
          </BCButton>
          <div style={{ height: 8 }} />
          <BCButton kind="plain" size="md" block>Edit before adding</BCButton>
        </div>
      </div>
    </div>
  );
}

// ─── Top-level screen ─────────────────────────────────────────────────
function BluAIScreen({ mode = 'light', state = 'camera', onDismiss }) {
  // Camera + analyzing share the dark camera-style chrome; results uses the
  // theme-aware body.
  if (state === 'results') return <ResultsState mode={mode} onDismiss={onDismiss} />;

  return (
    <div style={{
      position: 'relative', height: '100%', width: '100%',
      overflow: 'hidden', background: '#000', fontFamily: SF_STACK,
    }}>
      {state === 'camera'    && <CameraState onDismiss={onDismiss} />}
      {state === 'analyzing' && <AnalyzingState onDismiss={onDismiss} />}
    </div>
  );
}

function BluAIWalkthrough({ mode = 'light' }) {
  const [state, setState] = React.useState('camera');
  React.useEffect(() => {
    if (state === 'camera') {
      const id = setTimeout(() => setState('analyzing'), 2500);
      return () => clearTimeout(id);
    }
    if (state === 'analyzing') {
      const id = setTimeout(() => setState('results'), 2400);
      return () => clearTimeout(id);
    }
  }, [state]);
  return (
    <div style={{ position: 'relative', height: '100%' }}>
      <BluAIScreen mode={mode} state={state} />
      {/* state pills overlay */}
      <div style={{
        position: 'absolute', top: 70, left: '50%', transform: 'translateX(-50%)',
        zIndex: 60, display: 'flex', gap: 6,
        background: 'rgba(20,18,16,0.55)', backdropFilter: 'blur(10px)',
        padding: 4, borderRadius: 999,
        border: '1px solid rgba(255,255,255,0.10)',
      }}>
        {['camera', 'analyzing', 'results'].map(s => (
          <button key={s} onClick={() => setState(s)} style={{
            padding: '5px 11px', borderRadius: 999, border: 'none', cursor: 'pointer',
            background: state === s ? '#fff' : 'transparent',
            color: state === s ? '#111' : '#fff',
            fontSize: 11, fontWeight: 700, letterSpacing: 0.2, textTransform: 'uppercase',
            fontFamily: SF_STACK,
          }}>{s}</button>
        ))}
      </div>
    </div>
  );
}

Object.assign(window, { BluAIScreen, BluAIWalkthrough, BluAIBadge });
