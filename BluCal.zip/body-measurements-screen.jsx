// body-measurements-screen.jsx — Profile › Body measurements

function BMStatusBar({ mode }) {
  const c = mode === 'dark' ? '#fff' : '#000';
  return (
    <div style={{
      height: 54, padding: '14px 28px 0',
      display: 'flex', alignItems: 'center', justifyContent: 'space-between',
      fontSize: 17, fontWeight: 600, letterSpacing: -0.41, color: c, fontFamily: SF_STACK,
    }}>
      <span style={{ fontVariantNumeric: 'tabular-nums' }}>9:41</span>
      <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
        <svg width="18" height="11" viewBox="0 0 18 11">
          <rect x="0" y="7" width="3" height="4" rx="0.6" fill={c}/>
          <rect x="5" y="5" width="3" height="6" rx="0.6" fill={c}/>
          <rect x="10" y="3" width="3" height="8" rx="0.6" fill={c}/>
          <rect x="15" y="0" width="3" height="11" rx="0.6" fill={c}/>
        </svg>
        <svg width="26" height="12" viewBox="0 0 26 12">
          <rect x="0.5" y="0.5" width="22" height="11" rx="3" stroke={c} strokeOpacity="0.4" fill="none"/>
          <rect x="2" y="2" width="19" height="8" rx="1.5" fill={c}/>
          <rect x="23.5" y="4" width="1.5" height="4" rx="0.7" fill={c} fillOpacity="0.4"/>
        </svg>
      </div>
    </div>
  );
}

function BMNavBar({ mode, onBack }) {
  const t = mode === 'dark' ? BC_DARK : BC_LIGHT;
  return (
    <div style={{ height: 44, padding: '0 8px', display: 'flex', alignItems: 'center' }}>
      <button onClick={onBack} style={{
        height: 32, padding: '0 8px 0 4px', border: 'none', background: 'transparent',
        display: 'inline-flex', alignItems: 'center', gap: 2,
        color: t.primary, fontSize: 17, letterSpacing: -0.41,
        fontFamily: SF_STACK, cursor: 'pointer',
      }}>
        <BCIcon name="chev" size={20} color={t.primary} style={{ transform: 'scaleX(-1)' }} />
        <span>Profile</span>
      </button>
      <div style={{ flex: 1 }} />
    </div>
  );
}

// ─── Measurement row ─────────────────────────────────────────────────
function MeasureRow({ mode, label, value, unit, delta, date, first, last }) {
  const t = mode === 'dark' ? BC_DARK : BC_LIGHT;
  const deltaColor = !delta ? t.textTer
    : (delta < 0 ? t.success : t.warn);
  return (
    <button style={{
      width: '100%',
      background: t.surface,
      borderTopLeftRadius: first ? BC_RADIUS.lg : 0,
      borderTopRightRadius: first ? BC_RADIUS.lg : 0,
      borderBottomLeftRadius: last ? BC_RADIUS.lg : 0,
      borderBottomRightRadius: last ? BC_RADIUS.lg : 0,
      borderTop: first ? '1px solid ' + t.separator : 'none',
      borderBottom: last ? '1px solid ' + t.separator : '0.5px solid ' + t.separator,
      borderLeft: '1px solid ' + t.separator,
      borderRight: '1px solid ' + t.separator,
      padding: '12px 14px',
      display: 'flex', alignItems: 'center', gap: 12,
      cursor: 'pointer', fontFamily: SF_STACK, textAlign: 'left',
    }}>
      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{ fontSize: 15, fontWeight: 600, color: t.text, letterSpacing: -0.2 }}>{label}</div>
        <div style={{ fontSize: 12, color: t.textSec, marginTop: 2, fontVariantNumeric: 'tabular-nums' }}>
          {date ? `Last · ${date}` : <span style={{ color: t.textTer }}>Not measured yet</span>}
        </div>
      </div>
      <div style={{ textAlign: 'right' }}>
        <div style={{ fontSize: 17, fontWeight: 700, color: value ? t.text : t.textTer, letterSpacing: -0.2, fontVariantNumeric: 'tabular-nums' }}>
          {value ? <>{value}<span style={{ fontSize: 12, color: t.textSec, fontWeight: 600, marginLeft: 2 }}>{unit}</span></> : '—'}
        </div>
        {delta != null && (
          <div style={{
            fontSize: 11, fontWeight: 700, color: deltaColor, marginTop: 2,
            fontVariantNumeric: 'tabular-nums',
          }}>
            {delta > 0 ? '+' : ''}{delta} {unit}
          </div>
        )}
      </div>
      <BCIcon name="chev" size={16} color={t.textTer} />
    </button>
  );
}

// ─── Photo tile (stylized placeholder) ───────────────────────────────
function PhotoTile({ mode, date, hue = 200, onClick, selected }) {
  const t = mode === 'dark' ? BC_DARK : BC_LIGHT;
  // Stylized "figure" silhouette in a tinted square
  return (
    <button onClick={onClick} style={{
      position: 'relative', border: 'none', padding: 0,
      borderRadius: 14, overflow: 'hidden',
      cursor: 'pointer', fontFamily: SF_STACK,
      aspectRatio: '3 / 4',
      boxShadow: selected ? `0 0 0 3px ${t.primary}` : 'none',
    }}>
      {/* tinted gradient bg */}
      <div style={{
        position: 'absolute', inset: 0,
        background: `linear-gradient(160deg, hsl(${hue}, 35%, 78%) 0%, hsl(${hue + 30}, 30%, 56%) 100%)`,
      }} />
      {/* silhouette */}
      <svg viewBox="0 0 100 130" preserveAspectRatio="xMidYMid meet" style={{ position: 'absolute', inset: 0, opacity: 0.45 }}>
        <ellipse cx="50" cy="22" rx="12" ry="14" fill="rgba(0,0,0,0.35)"/>
        <path d="M 38 40 Q 50 36 62 40 L 64 86 Q 60 92 50 92 Q 40 92 36 86 Z" fill="rgba(0,0,0,0.35)" />
        <rect x="40" y="86" width="8" height="36" rx="3" fill="rgba(0,0,0,0.35)" />
        <rect x="52" y="86" width="8" height="36" rx="3" fill="rgba(0,0,0,0.35)" />
        <rect x="30" y="46" width="6" height="36" rx="3" fill="rgba(0,0,0,0.35)" />
        <rect x="64" y="46" width="6" height="36" rx="3" fill="rgba(0,0,0,0.35)" />
      </svg>
      {/* date label */}
      <div style={{
        position: 'absolute', left: 6, bottom: 6, right: 6,
        padding: '4px 8px', borderRadius: 6,
        background: 'rgba(0,0,0,0.45)',
        backdropFilter: 'blur(6px)',
        color: '#fff', fontSize: 10, fontWeight: 700, letterSpacing: 0.2,
        textAlign: 'left',
      }}>{date}</div>
      {selected && (
        <div style={{
          position: 'absolute', top: 6, right: 6,
          width: 22, height: 22, borderRadius: 999,
          background: t.primary, color: '#fff',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          boxShadow: '0 1px 3px rgba(0,0,0,0.25)',
        }}>
          <BCIcon name="check" size={12} color="#fff" strokeWidth={3} />
        </div>
      )}
    </button>
  );
}

function AddPhotoTile({ mode }) {
  const t = mode === 'dark' ? BC_DARK : BC_LIGHT;
  return (
    <button style={{
      position: 'relative', border: '1.5px dashed ' + t.hairline, padding: 0,
      borderRadius: 14, background: t.surface2,
      aspectRatio: '3 / 4',
      cursor: 'pointer', fontFamily: SF_STACK,
      display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 6,
      color: t.primary,
    }}>
      <div style={{
        width: 38, height: 38, borderRadius: 999, background: t.primarySoft,
        display: 'flex', alignItems: 'center', justifyContent: 'center',
      }}>
        <BCIcon name="plus" size={18} color={t.primary} strokeWidth={2.4} />
      </div>
      <span style={{ fontSize: 11, fontWeight: 700, letterSpacing: 0.2 }}>Add photo</span>
    </button>
  );
}

// ─── Screen ──────────────────────────────────────────────────────────
function BodyMeasurementsScreen({ mode = 'light', onBack }) {
  const t = mode === 'dark' ? BC_DARK : BC_LIGHT;
  const [selected, setSelected] = React.useState([0, 4]); // for Compare visual

  const measurements = [
    { label: 'Waist',    value: 33.4, unit: 'in', delta: -0.8, date: 'May 12' },
    { label: 'Hips',     value: 39.6, unit: 'in', delta: -0.4, date: 'May 12' },
    { label: 'Chest',    value: 41.2, unit: 'in', delta:  0.1, date: 'May 12' },
    { label: 'Neck',     value: 15.0, unit: 'in', delta: -0.1, date: 'May 12' },
    { label: 'Bicep · L', value: 13.4, unit: 'in', delta: +0.2, date: 'May 8' },
    { label: 'Bicep · R', value: 13.5, unit: 'in', delta: +0.2, date: 'May 8' },
    { label: 'Thigh · L', value: 22.2, unit: 'in', delta: -0.3, date: 'May 8' },
    { label: 'Thigh · R', value: 22.1, unit: 'in', delta: -0.3, date: 'May 8' },
    { label: 'Calf · L',  value: 14.6, unit: 'in', delta: null, date: 'Apr 24' },
    { label: 'Calf · R',  value: null, unit: 'in', delta: null, date: null },
  ];

  const photos = [
    { date: 'May 12', hue: 200 },
    { date: 'May 5',  hue: 195 },
    { date: 'Apr 28', hue: 188 },
    { date: 'Apr 21', hue: 182 },
    { date: 'Apr 14', hue: 176 },
    { date: 'Apr 7',  hue: 170 },
    { date: 'Mar 31', hue: 164 },
    { date: 'Mar 24', hue: 158 },
  ];

  const toggleSelect = (i) => {
    setSelected(sel => {
      if (sel.includes(i)) return sel.filter(x => x !== i);
      if (sel.length >= 2) return [sel[1], i];
      return [...sel, i];
    });
  };

  return (
    <BCTheme mode={mode} padding={0} style={{ position: 'relative', overflow: 'hidden', height: '100%' }}>
      <BMStatusBar mode={mode} />
      <BMNavBar mode={mode} onBack={onBack} />

      <div style={{ position: 'absolute', top: 54 + 44, left: 0, right: 0, bottom: 0, overflowY: 'auto', overflowX: 'hidden' }}>
        {/* Title */}
        <div style={{ padding: '4px 20px 12px' }}>
          <div style={{ fontSize: 32, fontWeight: 800, color: t.text, letterSpacing: -0.7, lineHeight: '38px' }}>
            Body measurements
          </div>
          <div style={{ fontSize: 14, color: t.textSec, marginTop: 2, fontWeight: 500 }}>
            Tap any row to log a new measurement
          </div>
        </div>

        {/* Measurements */}
        <div style={{ padding: '0 16px 0' }}>
          <div style={{
            display: 'flex', alignItems: 'baseline', justifyContent: 'space-between',
            padding: '4px 4px 8px',
          }}>
            <span style={{ fontSize: 11, fontWeight: 700, color: t.textTer, letterSpacing: 0.6, textTransform: 'uppercase' }}>
              Current measurements
            </span>
            <span style={{ fontSize: 13, fontWeight: 600, color: t.primary }}>Edit list</span>
          </div>
          <div>
            {measurements.map((m, i) => (
              <MeasureRow key={m.label} mode={mode}
                {...m}
                first={i === 0} last={i === measurements.length - 1}
              />
            ))}
          </div>
        </div>

        {/* Progress photos */}
        <div style={{ padding: '24px 16px 24px' }}>
          <div style={{
            display: 'flex', alignItems: 'baseline', justifyContent: 'space-between',
            padding: '0 4px 10px',
          }}>
            <div>
              <div style={{ fontSize: 11, fontWeight: 700, color: t.textTer, letterSpacing: 0.6, textTransform: 'uppercase' }}>
                Progress photos
              </div>
              <div style={{ fontSize: 12, color: t.textSec, marginTop: 2 }}>
                {photos.length} photos · weekly since Mar 24
              </div>
            </div>
            <button style={{
              padding: '6px 12px', borderRadius: 999,
              background: t.primarySoft, color: t.primary, border: 'none',
              fontSize: 12, fontWeight: 700,
              display: 'inline-flex', alignItems: 'center', gap: 5,
              cursor: 'pointer', fontFamily: SF_STACK,
            }}>
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke={t.primary} strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
                <rect x="3" y="4" width="8" height="16" rx="2"/>
                <rect x="13" y="4" width="8" height="16" rx="2"/>
              </svg>
              Compare
            </button>
          </div>

          {/* Compare strip — visible because 2 are selected */}
          {selected.length === 2 && (
            <div style={{
              marginBottom: 12, padding: '10px 12px',
              background: t.primarySoft, borderRadius: BC_RADIUS.md,
              display: 'flex', alignItems: 'center', gap: 10,
            }}>
              <BCIcon name="info" size={14} color={t.primary} />
              <span style={{ flex: 1, fontSize: 12, color: t.text }}>
                Comparing <b>{photos[selected[0]].date}</b> ↔ <b>{photos[selected[1]].date}</b>
              </span>
              <button style={{
                padding: '5px 10px', borderRadius: 999, border: 'none',
                background: t.primary, color: '#fff',
                fontSize: 12, fontWeight: 700, cursor: 'pointer', fontFamily: SF_STACK,
              }}>Open</button>
            </div>
          )}

          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 10 }}>
            <AddPhotoTile mode={mode} />
            {photos.map((p, i) => (
              <PhotoTile key={i} mode={mode} date={p.date} hue={p.hue}
                selected={selected.includes(i)}
                onClick={() => toggleSelect(i)}
              />
            ))}
          </div>
        </div>
      </div>
    </BCTheme>
  );
}

Object.assign(window, { BodyMeasurementsScreen });
