// coach-screen.jsx — AI Coach tab (summary + insight + chat thread)

function CHStatusBar({ mode }) {
  const c = mode === 'dark' ? '#fff' : '#000';
  return (
    <div style={{
      height: 54, padding: '14px 28px 0',
      display: 'flex', alignItems: 'center', justifyContent: 'space-between',
      fontSize: 17, fontWeight: 600, letterSpacing: -0.41, color: c,
      fontFamily: SF_STACK,
    }}>
      <span style={{ fontVariantNumeric: 'tabular-nums' }}>9:41</span>
      <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
        <svg width="18" height="11" viewBox="0 0 18 11">
          <rect x="0" y="7" width="3" height="4" rx="0.6" fill={c}/>
          <rect x="5" y="5" width="3" height="6" rx="0.6" fill={c}/>
          <rect x="10" y="3" width="3" height="8" rx="0.6" fill={c}/>
          <rect x="15" y="0" width="3" height="11" rx="0.6" fill={c}/>
        </svg>
        <svg width="26" height="12" viewBox="0 0 26 12">
          <rect x="0.5" y="0.5" width="22" height="11" rx="3" stroke={c} strokeOpacity="0.4" fill="none"/>
          <rect x="2" y="2" width="19" height="8" rx="1.5" fill={c}/>
          <rect x="23.5" y="4" width="1.5" height="4" rx="0.7" fill={c} fillOpacity="0.4"/>
        </svg>
      </div>
    </div>
  );
}

// ─── Summary stat block ───────────────────────────────────────────────
function StatBlock({ mode, label, value, sub, color }) {
  const t = mode === 'dark' ? BC_DARK : BC_LIGHT;
  return (
    <div style={{ flex: 1, padding: '0 4px' }}>
      <div style={{ fontSize: 10, fontWeight: 700, color: t.textTer, letterSpacing: 0.5, textTransform: 'uppercase' }}>{label}</div>
      <div style={{ fontSize: 17, fontWeight: 800, color: color || t.text, marginTop: 4, letterSpacing: -0.3, fontVariantNumeric: 'tabular-nums', lineHeight: 1 }}>{value}</div>
      <div style={{ fontSize: 11, color: t.textSec, marginTop: 3, fontWeight: 500 }}>{sub}</div>
    </div>
  );
}

// ─── Summary card ─────────────────────────────────────────────────────
function CoachSummary({ mode }) {
  const t = mode === 'dark' ? BC_DARK : BC_LIGHT;
  return (
    <div style={{
      background: t.surface, border: '1px solid ' + t.separator, borderRadius: BC_RADIUS.lg,
      padding: '16px',
    }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 14 }}>
        {/* Momentum dial */}
        <div style={{ position: 'relative', width: 84, height: 84, flexShrink: 0 }}>
          <svg width="84" height="84" viewBox="0 0 84 84">
            <circle cx="42" cy="42" r="34" stroke={t.surface2} strokeWidth="9" fill="none" />
            <circle cx="42" cy="42" r="34"
              stroke={t.success} strokeWidth="9" fill="none"
              strokeDasharray={2 * Math.PI * 34}
              strokeDashoffset={2 * Math.PI * 34 * (1 - 0.84)}
              strokeLinecap="round"
              transform="rotate(-90 42 42)"
            />
          </svg>
          <div style={{ position: 'absolute', inset: 0, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center' }}>
            <span style={{ fontSize: 24, fontWeight: 800, color: t.text, letterSpacing: -0.5, lineHeight: 1, fontVariantNumeric: 'tabular-nums' }}>84</span>
            <span style={{ fontSize: 9, color: t.textTer, fontWeight: 700, letterSpacing: 0.4, textTransform: 'uppercase', marginTop: 2 }}>/ 100</span>
          </div>
        </div>
        <div style={{ flex: 1 }}>
          <div style={{ fontSize: 11, fontWeight: 700, color: t.textTer, letterSpacing: 0.6, textTransform: 'uppercase' }}>Momentum</div>
          <div style={{ fontSize: 18, fontWeight: 800, color: t.text, marginTop: 2, letterSpacing: -0.3 }}>
            On track — keep going
          </div>
          <div style={{ fontSize: 13, color: t.textSec, marginTop: 4, lineHeight: '18px' }}>
            At this rate, you'll reach <b style={{ color: t.text }}>175 lbs</b> in <b style={{ color: t.text }}>~9 weeks</b>.
          </div>
        </div>
      </div>

      <div style={{ height: 1, background: t.separator, margin: '14px -2px 12px' }} />

      <div style={{ display: 'flex' }}>
        <StatBlock mode={mode} label="Avg cals · 7d"
          value="1,847" sub="153 under target" color={t.text} />
        <div style={{ width: 1, background: t.separator }} />
        <StatBlock mode={mode} label="Weight trend"
          value="−0.5 lb/wk" sub="178.0 → 177.5" color={t.success} />
        <div style={{ width: 1, background: t.separator }} />
        <StatBlock mode={mode} label="Streak"
          value="9 days" sub="logged every meal" color={t.primary} />
      </div>
    </div>
  );
}

// ─── Weekly insight card ─────────────────────────────────────────────
function InsightCard({ mode }) {
  const t = mode === 'dark' ? BC_DARK : BC_LIGHT;
  return (
    <div style={{
      background: t.primarySoft, borderRadius: BC_RADIUS.lg,
      padding: '14px 16px',
      display: 'flex', gap: 12, alignItems: 'flex-start',
    }}>
      <div style={{
        width: 36, height: 36, borderRadius: 10, flexShrink: 0,
        background: t.primary, color: '#fff',
        display: 'flex', alignItems: 'center', justifyContent: 'center',
      }}>
        {/* lightbulb */}
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#fff" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
          <path d="M9 18h6"/>
          <path d="M10 21h4"/>
          <path d="M12 3a6 6 0 016 6c0 2.5-1.5 4-3 5.5V17H9v-2.5C7.5 13 6 11.5 6 9a6 6 0 016-6z"/>
        </svg>
      </div>
      <div style={{ flex: 1 }}>
        <div style={{ fontSize: 11, fontWeight: 700, color: t.primary, letterSpacing: 0.6, textTransform: 'uppercase' }}>Weekly insight</div>
        <div style={{ fontSize: 14, color: t.text, marginTop: 4, lineHeight: '20px', textWrap: 'pretty' }}>
          You hit your <b>protein target 6 of 7 days</b> this week — strong consistency. Your weakest day was <b>Sunday</b> — 38g under. Want a quick high-protein swap idea?
        </div>
        <div style={{ display: 'flex', gap: 8, marginTop: 10 }}>
          <button style={{
            padding: '6px 12px', borderRadius: 999, border: 'none',
            background: t.primary, color: '#fff',
            fontSize: 12, fontWeight: 700, fontFamily: SF_STACK, cursor: 'pointer',
          }}>Yes, suggest</button>
          <button style={{
            padding: '6px 12px', borderRadius: 999,
            border: '1px solid ' + t.primary,
            background: 'transparent', color: t.primary,
            fontSize: 12, fontWeight: 700, fontFamily: SF_STACK, cursor: 'pointer',
          }}>Maybe later</button>
        </div>
      </div>
    </div>
  );
}

// ─── Chat bubble ──────────────────────────────────────────────────────
function CoachBubble({ mode, role, children, time, attached }) {
  const t = mode === 'dark' ? BC_DARK : BC_LIGHT;
  const isUser = role === 'user';
  return (
    <div style={{
      display: 'flex', gap: 8,
      flexDirection: isUser ? 'row-reverse' : 'row',
      alignItems: 'flex-end',
    }}>
      {!isUser && (
        <div style={{
          width: 30, height: 30, borderRadius: 999, flexShrink: 0,
          background: t.primary, color: '#fff',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          marginBottom: 4,
        }}>
          <BluCalMark size={20} color="#fff" />
        </div>
      )}
      <div style={{
        maxWidth: '76%',
        display: 'flex', flexDirection: 'column',
        alignItems: isUser ? 'flex-end' : 'flex-start',
        gap: 6,
      }}>
        <div style={{
          padding: '10px 14px',
          borderRadius: 18,
          borderBottomRightRadius: isUser ? 6 : 18,
          borderBottomLeftRadius: isUser ? 18 : 6,
          background: isUser ? t.primary : t.surface2,
          color: isUser ? '#fff' : t.text,
          fontSize: 15, lineHeight: '20px', letterSpacing: -0.2,
          fontFamily: SF_STACK,
          fontWeight: 500,
          border: isUser ? 'none' : '1px solid ' + t.separator,
          textWrap: 'pretty',
        }}>
          {children}
        </div>
        {attached}
        {time && (
          <div style={{ fontSize: 10, fontWeight: 600, color: t.textTer, letterSpacing: 0.3, padding: '0 4px' }}>{time}</div>
        )}
      </div>
    </div>
  );
}

// ─── Adaptive-target attachment (in-bubble proposal) ─────────────────
function TargetChangeAttachment({ mode }) {
  const t = mode === 'dark' ? BC_DARK : BC_LIGHT;
  return (
    <div style={{
      background: t.surface, border: '1px solid ' + t.separator, borderRadius: 14,
      padding: '12px 14px', width: '100%', maxWidth: 280,
    }}>
      <div style={{ fontSize: 11, fontWeight: 700, color: t.textTer, letterSpacing: 0.5, textTransform: 'uppercase' }}>
        Proposed change · daily kcal
      </div>
      <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginTop: 6 }}>
        <span style={{
          fontSize: 18, fontWeight: 700, color: t.textSec,
          textDecoration: 'line-through', fontVariantNumeric: 'tabular-nums',
        }}>2,000</span>
        <BCIcon name="chev" size={14} color={t.textSec} />
        <span style={{ fontSize: 22, fontWeight: 800, color: t.primary, letterSpacing: -0.3, fontVariantNumeric: 'tabular-nums' }}>1,920</span>
        <span style={{
          padding: '2px 6px', borderRadius: 6, background: t.warnSoft, color: t.warn,
          fontSize: 10, fontWeight: 700, letterSpacing: 0.3, textTransform: 'uppercase',
        }}>−80 kcal</span>
      </div>
      <div style={{ fontSize: 12, color: t.textSec, marginTop: 8, lineHeight: '16px' }}>
        Your weight stalled for 14 days — a small cut keeps the deficit honest without crushing energy.
      </div>
      <div style={{ display: 'flex', gap: 6, marginTop: 10 }}>
        <button style={{
          flex: 1, height: 32, borderRadius: 8, border: 'none',
          background: t.primary, color: '#fff',
          fontSize: 12, fontWeight: 700, fontFamily: SF_STACK, cursor: 'pointer',
        }}>Apply</button>
        <button style={{
          flex: 1, height: 32, borderRadius: 8, border: '1px solid ' + t.separator,
          background: 'transparent', color: t.text,
          fontSize: 12, fontWeight: 700, fontFamily: SF_STACK, cursor: 'pointer',
        }}>Not yet</button>
      </div>
    </div>
  );
}

// ─── Input bar ────────────────────────────────────────────────────────
function CoachInput({ mode, value, onChange, onSend }) {
  const t = mode === 'dark' ? BC_DARK : BC_LIGHT;
  return (
    <div style={{
      background: t.bg,
      borderTop: '0.5px solid ' + t.separator,
      padding: '10px 12px 22px',
      display: 'flex', alignItems: 'flex-end', gap: 8,
    }}>
      <button style={{
        width: 36, height: 36, borderRadius: 999, border: '1px solid ' + t.separator,
        background: t.surface, color: t.primary,
        display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer', flexShrink: 0,
      }} aria-label="Add">
        <BCIcon name="plus" size={18} color={t.primary} strokeWidth={2.4} />
      </button>
      <div style={{
        flex: 1, minHeight: 36,
        background: t.surface, border: '1px solid ' + t.separator, borderRadius: 18,
        padding: '8px 14px',
        display: 'flex', alignItems: 'center', gap: 8,
      }}>
        <input
          value={value} onChange={(e) => onChange(e.target.value)}
          onKeyDown={(e) => { if (e.key === 'Enter') onSend(); }}
          placeholder="Ask your coach anything…"
          style={{
            flex: 1, background: 'transparent', border: 'none', outline: 'none',
            fontSize: 15, color: t.text, fontFamily: SF_STACK, letterSpacing: -0.2,
          }}
        />
        <button style={{
          width: 26, height: 26, padding: 0, border: 'none', background: 'transparent',
          color: t.textSec, cursor: 'pointer',
        }} aria-label="Voice">
          <BCIcon name="mic" size={18} color={t.textSec} />
        </button>
      </div>
      <button onClick={onSend} style={{
        width: 36, height: 36, borderRadius: 999, border: 'none',
        background: value.trim() ? t.primary : t.surface2,
        color: value.trim() ? '#fff' : t.textTer,
        display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer', flexShrink: 0,
      }} aria-label="Send">
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round">
          <path d="M5 12h14M13 6l6 6-6 6"/>
        </svg>
      </button>
    </div>
  );
}

// ─── Tab bar ──────────────────────────────────────────────────────────
function CHTabBar({ mode, active }) {
  const t = mode === 'dark' ? BC_DARK : BC_LIGHT;
  const tabs = [
    { name: 'Today',  icon: 'flame' },
    { name: 'Trends', icon: 'chart' },
    { name: 'Meals',  icon: 'fork' },
    { name: 'Coach',  icon: 'spark' },
    { name: 'Profile',icon: 'user' },
  ];
  return (
    <div style={{
      background: t.surface,
      borderTop: '0.5px solid ' + t.separator,
      paddingTop: 8,
    }}>
      <div style={{ display: 'flex' }}>
        {tabs.map((tb, i) => {
          const isActive = i === active;
          const c = isActive ? t.primary : t.textTer;
          const inactive = '#8E8E93';
          return (
            <div key={tb.name} style={{
              flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 3,
            }}>
              {tb.name === 'Today' ? (
                <BluCalMark size={26} color={isActive ? t.primary : inactive} />
              ) : (
                <BCIcon name={tb.icon} size={26} color={c} strokeWidth={isActive ? 2.2 : 1.8} />
              )}
              <div style={{ fontSize: 10, fontWeight: 600, color: c, letterSpacing: 0.1 }}>{tb.name}</div>
            </div>
          );
        })}
      </div>
      <div style={{ height: 14, display: 'flex', justifyContent: 'center', alignItems: 'flex-end', paddingBottom: 6 }}>
        <div style={{ width: 134, height: 5, borderRadius: 999, background: mode === 'dark' ? 'rgba(255,255,255,0.6)' : 'rgba(0,0,0,0.3)' }} />
      </div>
    </div>
  );
}

// ─── Screen ──────────────────────────────────────────────────────────
function CoachScreen({ mode = 'light' }) {
  const t = mode === 'dark' ? BC_DARK : BC_LIGHT;
  const [input, setInput] = React.useState('');
  const onSend = () => { if (input.trim()) setInput(''); };

  return (
    <BCTheme mode={mode} padding={0} style={{ position: 'relative', overflow: 'hidden', height: '100%' }}>
      <CHStatusBar mode={mode} />

      <div style={{
        position: 'absolute', top: 54, left: 0, right: 0, bottom: 86,
        display: 'flex', flexDirection: 'column',
      }}>
        {/* Scrollable content */}
        <div style={{ flex: 1, overflowY: 'auto', overflowX: 'hidden', paddingBottom: 8 }}>
          {/* Title */}
          <div style={{ padding: '8px 20px 4px', display: 'flex', alignItems: 'flex-end', gap: 10 }}>
            <div style={{ flex: 1 }}>
              <div style={{ fontSize: 34, fontWeight: 800, color: t.text, letterSpacing: -0.8, lineHeight: '41px' }}>Coach</div>
              <div style={{ fontSize: 14, color: t.textSec, marginTop: 2, fontWeight: 500 }}>Your BluAI coach · always tuning</div>
            </div>
          </div>

          {/* Summary */}
          <div style={{ padding: '12px 16px 0' }}>
            <CoachSummary mode={mode} />
          </div>

          {/* Insight */}
          <div style={{ padding: '12px 16px 0' }}>
            <InsightCard mode={mode} />
          </div>

          {/* Chat */}
          <div style={{ padding: '22px 16px 0', display: 'flex', flexDirection: 'column', gap: 14 }}>
            <div style={{ fontSize: 11, fontWeight: 700, color: t.textTer, letterSpacing: 0.6, textTransform: 'uppercase', padding: '0 4px' }}>
              Conversation
            </div>

            {/* Adaptive target message */}
            <CoachBubble mode={mode} role="coach" time="Yesterday · 9:14 AM"
              attached={<TargetChangeAttachment mode={mode} />}
            >
              Quick update: your weight has been flat for two weeks despite logging cleanly. I'd like to nudge your daily calories down by 80. Apply this and I'll keep watching.
            </CoachBubble>

            <CoachBubble mode={mode} role="user" time="Yesterday · 9:18 AM">
              Why 80 and not more?
            </CoachBubble>

            {/* Pattern observation */}
            <CoachBubble mode={mode} role="coach" time="Today · 7:02 AM">
              I noticed something interesting: on days you log <b>before 9 AM</b>, you hit your protein target <b>91%</b> of the time. On days you log later, only <b>52%</b>. A small breakfast habit seems to anchor the whole day.
            </CoachBubble>

            {/* Motivational */}
            <CoachBubble mode={mode} role="coach" time="Today · 8:30 AM">
              You're <b>9 days into your streak</b> 🔥 — that's the longest yet. Whatever you're doing this week, it's working. Keep it light, keep it logged.
            </CoachBubble>

            <CoachBubble mode={mode} role="user" time="Now">
              Plan a high-protein dinner for tonight under 600 kcal.
            </CoachBubble>

            {/* Typing indicator */}
            <div style={{ display: 'flex', gap: 8, alignItems: 'flex-end' }}>
              <div style={{
                width: 30, height: 30, borderRadius: 999, flexShrink: 0,
                background: t.primary, color: '#fff',
                display: 'flex', alignItems: 'center', justifyContent: 'center',
              }}>
                <BluCalMark size={20} color="#fff" />
              </div>
              <div style={{
                padding: '12px 14px',
                borderRadius: 18, borderBottomLeftRadius: 6,
                background: t.surface2, border: '1px solid ' + t.separator,
                display: 'inline-flex', gap: 4,
              }}>
                {[0, 1, 2].map(i => (
                  <span key={i} style={{
                    width: 6, height: 6, borderRadius: 999, background: t.textTer,
                    animation: `ch-dot 1.2s ease-in-out ${i * 0.15}s infinite`,
                  }} />
                ))}
              </div>
            </div>
            <style>{`@keyframes ch-dot { 0%,100% { opacity: .25; transform: translateY(0)} 50% { opacity: 1; transform: translateY(-3px)} }`}</style>

            <div style={{ height: 4 }} />
          </div>
        </div>

        {/* Input bar */}
        <CoachInput mode={mode} value={input} onChange={setInput} onSend={onSend} />
      </div>

      {/* Tab bar */}
      <div style={{ position: 'absolute', left: 0, right: 0, bottom: 0 }}>
        <CHTabBar mode={mode} active={3} />
      </div>
    </BCTheme>
  );
}

Object.assign(window, { CoachScreen });
