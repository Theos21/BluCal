// custom-food-screen.jsx — Create custom food form
// Top → bottom:
//   • Nav bar (cancel / Create) — Create is disabled until name + kcal filled
//   • Basics: food name (required) · brand (optional)
//   • Serving size: numeric + unit dropdown
//   • Nutrition: kcal + 3 macros + fiber/sugar/sodium
//   • Add micronutrients (expandable): vitamins / minerals inputs
//   • Share toggle
//   • Save (primary) — sticky bottom

function CFStatusBar({ mode }) {
  const c = mode === 'dark' ? '#fff' : '#000';
  return (
    <div style={{
      height: 54, padding: '14px 28px 0',
      display: 'flex', alignItems: 'center', justifyContent: 'space-between',
      fontSize: 17, fontWeight: 600, letterSpacing: -0.41, color: c,
      fontFamily: SF_STACK,
    }}>
      <span style={{ fontVariantNumeric: 'tabular-nums' }}>9:41</span>
      <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
        <svg width="18" height="11" viewBox="0 0 18 11">
          <rect x="0" y="7" width="3" height="4" rx="0.6" fill={c}/>
          <rect x="5" y="5" width="3" height="6" rx="0.6" fill={c}/>
          <rect x="10" y="3" width="3" height="8" rx="0.6" fill={c}/>
          <rect x="15" y="0" width="3" height="11" rx="0.6" fill={c}/>
        </svg>
        <svg width="26" height="12" viewBox="0 0 26 12">
          <rect x="0.5" y="0.5" width="22" height="11" rx="3" stroke={c} strokeOpacity="0.4" fill="none"/>
          <rect x="2" y="2" width="19" height="8" rx="1.5" fill={c}/>
          <rect x="23.5" y="4" width="1.5" height="4" rx="0.7" fill={c} fillOpacity="0.4"/>
        </svg>
      </div>
    </div>
  );
}

function CFNavBar({ mode, onCancel, canSave, onSave }) {
  const t = mode === 'dark' ? BC_DARK : BC_LIGHT;
  return (
    <div style={{
      height: 52, padding: '0 16px',
      display: 'flex', alignItems: 'center',
      borderBottom: '0.5px solid ' + t.separator,
      background: t.bg,
      position: 'relative',
    }}>
      <button onClick={onCancel} style={{
        height: 32, padding: '0 4px', border: 'none', background: 'transparent',
        color: t.primary, fontSize: 17, fontWeight: 500, letterSpacing: -0.41,
        fontFamily: SF_STACK, cursor: 'pointer',
      }}>Cancel</button>
      <div style={{
        position: 'absolute', inset: 0,
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        pointerEvents: 'none',
        fontSize: 17, fontWeight: 600, letterSpacing: -0.41, color: t.text,
        lineHeight: '22px',
      }}>Create food</div>
      <div style={{ flex: 1 }} />
      <button disabled={!canSave} onClick={onSave} style={{
        height: 32, padding: '0 4px', border: 'none', background: 'transparent',
        color: canSave ? t.primary : t.textTer,
        fontSize: 17, fontWeight: 700, letterSpacing: -0.41,
        fontFamily: SF_STACK, cursor: canSave ? 'pointer' : 'not-allowed',
      }}>Create</button>
    </div>
  );
}

// ─── Section header ───────────────────────────────────────────────────
function CFSectionLabel({ mode, children, action }) {
  const t = mode === 'dark' ? BC_DARK : BC_LIGHT;
  return (
    <div style={{
      padding: '20px 4px 8px',
      display: 'flex', alignItems: 'baseline', justifyContent: 'space-between',
    }}>
      <div style={{
        fontSize: 11, fontWeight: 700, letterSpacing: 0.6, textTransform: 'uppercase', color: t.textTer,
      }}>{children}</div>
      {action}
    </div>
  );
}

// ─── Grouped form row ─────────────────────────────────────────────────
function CFRow({ mode, label, required, value, placeholder, onChange, unit, type = 'text',
                trailing, first, last, alone }) {
  const t = mode === 'dark' ? BC_DARK : BC_LIGHT;
  const radius = alone ? BC_RADIUS.lg : 0;
  const radiusTL = first ? BC_RADIUS.lg : 0;
  const radiusTR = first ? BC_RADIUS.lg : 0;
  const radiusBL = last ? BC_RADIUS.lg : 0;
  const radiusBR = last ? BC_RADIUS.lg : 0;
  return (
    <div style={{
      background: t.surface,
      borderTopLeftRadius: alone ? BC_RADIUS.lg : radiusTL,
      borderTopRightRadius: alone ? BC_RADIUS.lg : radiusTR,
      borderBottomLeftRadius: alone ? BC_RADIUS.lg : radiusBL,
      borderBottomRightRadius: alone ? BC_RADIUS.lg : radiusBR,
      borderTop: first || alone ? '1px solid ' + t.separator : 'none',
      borderBottom: last || alone ? '1px solid ' + t.separator : '0.5px solid ' + t.separator,
      borderLeft: '1px solid ' + t.separator,
      borderRight: '1px solid ' + t.separator,
      padding: '10px 14px',
      display: 'flex', alignItems: 'center', gap: 12,
    }}>
      <div style={{ width: 140, flexShrink: 0, fontSize: 14, fontWeight: 500, color: t.text, letterSpacing: -0.1 }}>
        {label}
        {required && <span style={{ color: t.danger, marginLeft: 4 }}>•</span>}
      </div>
      <input
        type={type}
        inputMode={type === 'number' ? 'decimal' : undefined}
        value={value}
        placeholder={placeholder}
        onChange={(e) => onChange && onChange(e.target.value)}
        style={{
          flex: 1, minWidth: 0,
          background: 'transparent', border: 'none', outline: 'none',
          fontSize: 16, fontWeight: 600, color: t.text,
          textAlign: 'right',
          fontFamily: SF_STACK, letterSpacing: -0.2,
          fontVariantNumeric: type === 'number' ? 'tabular-nums' : 'normal',
        }}
      />
      {unit && (
        <span style={{ width: 26, textAlign: 'left', fontSize: 13, color: t.textSec, fontWeight: 600, flexShrink: 0 }}>{unit}</span>
      )}
      {trailing}
    </div>
  );
}

// ─── Toggle row ───────────────────────────────────────────────────────
function CFToggleRow({ mode, label, sub, value, onChange }) {
  const t = mode === 'dark' ? BC_DARK : BC_LIGHT;
  return (
    <div style={{
      background: t.surface, border: '1px solid ' + t.separator,
      borderRadius: BC_RADIUS.lg,
      padding: '14px 16px',
      display: 'flex', alignItems: 'center', gap: 12,
    }}>
      <div style={{ flex: 1 }}>
        <div style={{ fontSize: 15, fontWeight: 600, color: t.text, letterSpacing: -0.2 }}>{label}</div>
        {sub && <div style={{ fontSize: 12, color: t.textSec, marginTop: 3, lineHeight: '16px' }}>{sub}</div>}
      </div>
      <BCSwitch on={value} />
      <div onClick={() => onChange(!value)} style={{ position: 'absolute', width: 51, height: 31, marginLeft: -51, cursor: 'pointer' }} />
    </div>
  );
}

// ─── Micronutrient row (compact) ──────────────────────────────────────
function MicroRow({ mode, label, value, onChange, unit }) {
  const t = mode === 'dark' ? BC_DARK : BC_LIGHT;
  return (
    <div style={{
      display: 'flex', alignItems: 'center', gap: 10,
      padding: '8px 0', borderBottom: '0.5px solid ' + t.separator,
    }}>
      <div style={{ flex: 1, fontSize: 14, fontWeight: 500, color: t.text, letterSpacing: -0.1 }}>{label}</div>
      <input
        type="text" inputMode="decimal" value={value} placeholder="0"
        onChange={(e) => onChange(e.target.value)}
        style={{
          width: 70, height: 32, padding: '0 10px',
          background: t.surface2, border: '1px solid ' + t.separator,
          borderRadius: 8, outline: 'none',
          fontFamily: SF_STACK, fontSize: 14, fontWeight: 600, color: t.text,
          textAlign: 'right', fontVariantNumeric: 'tabular-nums',
        }}
      />
      <span style={{ width: 30, fontSize: 11, color: t.textSec, fontWeight: 600 }}>{unit}</span>
    </div>
  );
}

// ─── Screen ───────────────────────────────────────────────────────────
function CustomFoodScreen({ mode = 'light', onCancel }) {
  const t = mode === 'dark' ? BC_DARK : BC_LIGHT;
  const [name, setName] = React.useState('');
  const [brand, setBrand] = React.useState('');
  const [serving, setServing] = React.useState('');
  const [unit, setUnit] = React.useState('g');
  const [kcal, setKcal] = React.useState('');
  const [p, setP] = React.useState('');
  const [c, setC] = React.useState('');
  const [f, setF] = React.useState('');
  const [fiber, setFiber] = React.useState('');
  const [sugar, setSugar] = React.useState('');
  const [sodium, setSodium] = React.useState('');
  const [microOpen, setMicroOpen] = React.useState(false);
  const [share, setShare] = React.useState(false);

  const [micros, setMicros] = React.useState({
    vitA: '', vitC: '', vitD: '', vitE: '', vitK: '',
    b12: '', folate: '',
    calcium: '', iron: '', magnesium: '', potassium: '', zinc: '',
  });
  const upd = (k, v) => setMicros(m => ({ ...m, [k]: v }));

  const canSave = name.trim().length > 0 && kcal !== '';

  return (
    <BCTheme mode={mode} padding={0} style={{ position: 'relative', overflow: 'hidden', height: '100%' }}>
      <CFStatusBar mode={mode} />
      <CFNavBar mode={mode} onCancel={onCancel} canSave={canSave} />

      <div style={{ position: 'absolute', top: 54 + 52, left: 0, right: 0, bottom: 86, overflowY: 'auto', overflowX: 'hidden' }}>
        <div style={{ padding: '12px 16px 24px' }}>

          {/* Basics */}
          <CFSectionLabel mode={mode}>Basics</CFSectionLabel>
          <div>
            <CFRow mode={mode} label="Food name" required first
              value={name} placeholder="e.g. Almond butter overnight oats"
              onChange={setName} />
            <CFRow mode={mode} label="Brand" last
              value={brand} placeholder="Optional"
              onChange={setBrand} />
          </div>

          {/* Serving size */}
          <CFSectionLabel mode={mode}>Serving size</CFSectionLabel>
          <div style={{
            background: t.surface, border: '1px solid ' + t.separator,
            borderRadius: BC_RADIUS.lg, padding: '10px 14px',
            display: 'flex', alignItems: 'center', gap: 12,
          }}>
            <div style={{ width: 140, fontSize: 14, fontWeight: 500, color: t.text, letterSpacing: -0.1 }}>
              Amount per serving
            </div>
            <input
              type="text" inputMode="decimal" value={serving} placeholder="0"
              onChange={(e) => setServing(e.target.value)}
              style={{
                flex: 1, minWidth: 0,
                height: 36, padding: '0 12px',
                background: t.surface2, border: '1px solid ' + t.separator, borderRadius: 8,
                outline: 'none',
                fontFamily: SF_STACK, fontSize: 16, fontWeight: 700, color: t.text,
                textAlign: 'right', fontVariantNumeric: 'tabular-nums',
              }}
            />
            <select value={unit} onChange={(e) => setUnit(e.target.value)} style={{
              width: 92, flexShrink: 0,
              height: 36, padding: '0 26px 0 10px',
              background: t.surface2, color: t.text,
              border: '1px solid ' + t.separator, borderRadius: 8,
              fontFamily: SF_STACK, fontSize: 14, fontWeight: 600,
              cursor: 'pointer',
              appearance: 'none', WebkitAppearance: 'none', MozAppearance: 'none',
              backgroundImage: `url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='12' height='12' viewBox='0 0 24 24' fill='none' stroke='${encodeURIComponent(t.textSec)}' stroke-width='2.2' stroke-linecap='round' stroke-linejoin='round'><path d='M6 9l6 6 6-6'/></svg>")`,
              backgroundRepeat: 'no-repeat', backgroundPosition: 'right 8px center',
            }}>
              {['g', 'oz', 'cup', 'tbsp', 'tsp', 'serving', 'piece', 'ml', 'fl oz'].map(o => (
                <option key={o} value={o}>{o}</option>
              ))}
            </select>
          </div>

          {/* Nutrition */}
          <CFSectionLabel mode={mode}>Nutrition · per serving</CFSectionLabel>
          <div>
            <CFRow mode={mode} label="Calories" required first
              type="number" placeholder="0" unit="kcal"
              value={kcal} onChange={setKcal} />
            <CFRow mode={mode} label="Protein"
              type="number" placeholder="0" unit="g"
              value={p} onChange={setP} />
            <CFRow mode={mode} label="Carbohydrates"
              type="number" placeholder="0" unit="g"
              value={c} onChange={setC} />
            <CFRow mode={mode} label="Fat"
              type="number" placeholder="0" unit="g"
              value={f} onChange={setF} />
            <CFRow mode={mode} label="Fiber"
              type="number" placeholder="0" unit="g"
              value={fiber} onChange={setFiber} />
            <CFRow mode={mode} label="Sugar"
              type="number" placeholder="0" unit="g"
              value={sugar} onChange={setSugar} />
            <CFRow mode={mode} label="Sodium" last
              type="number" placeholder="0" unit="mg"
              value={sodium} onChange={setSodium} />
          </div>

          {/* Micronutrients expandable */}
          <CFSectionLabel mode={mode}
            action={<span style={{ fontSize: 11, fontWeight: 700, color: t.textTer, letterSpacing: 0.4, textTransform: 'uppercase' }}>Optional</span>}
          >More</CFSectionLabel>
          <div style={{
            background: t.surface, border: '1px solid ' + t.separator, borderRadius: BC_RADIUS.lg,
            overflow: 'hidden',
          }}>
            <button onClick={() => setMicroOpen(o => !o)} style={{
              width: '100%', padding: '14px 16px', background: 'transparent', border: 'none',
              display: 'flex', alignItems: 'center', gap: 10, cursor: 'pointer',
              fontFamily: SF_STACK, textAlign: 'left',
            }}>
              <div style={{ flex: 1 }}>
                <div style={{ fontSize: 15, fontWeight: 700, color: t.text, letterSpacing: -0.2 }}>Add micronutrients</div>
                <div style={{ fontSize: 12, color: t.textSec, marginTop: 2 }}>
                  Vitamins, minerals — % of values you fill power your daily targets.
                </div>
              </div>
              <span style={{
                width: 22, height: 22, display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
                color: t.textSec, transform: microOpen ? 'rotate(180deg)' : 'rotate(0deg)', transition: 'transform .15s',
              }}>
                <BCIcon name="caret-down" size={18} color={t.textSec} />
              </span>
            </button>
            {microOpen && (
              <div style={{ padding: '4px 16px 14px', borderTop: '0.5px solid ' + t.separator }}>
                <div style={{
                  paddingTop: 6, marginBottom: 4,
                  fontSize: 11, fontWeight: 700, letterSpacing: 0.5, textTransform: 'uppercase', color: t.textTer,
                }}>Vitamins</div>
                <MicroRow mode={mode} label="Vitamin A"   unit="mcg" value={micros.vitA} onChange={(v) => upd('vitA', v)} />
                <MicroRow mode={mode} label="Vitamin C"   unit="mg"  value={micros.vitC} onChange={(v) => upd('vitC', v)} />
                <MicroRow mode={mode} label="Vitamin D"   unit="mcg" value={micros.vitD} onChange={(v) => upd('vitD', v)} />
                <MicroRow mode={mode} label="Vitamin E"   unit="mg"  value={micros.vitE} onChange={(v) => upd('vitE', v)} />
                <MicroRow mode={mode} label="Vitamin K"   unit="mcg" value={micros.vitK} onChange={(v) => upd('vitK', v)} />
                <MicroRow mode={mode} label="Vitamin B12" unit="mcg" value={micros.b12}  onChange={(v) => upd('b12', v)} />
                <MicroRow mode={mode} label="Folate"      unit="mcg" value={micros.folate} onChange={(v) => upd('folate', v)} />
                <div style={{
                  paddingTop: 12, marginBottom: 4,
                  fontSize: 11, fontWeight: 700, letterSpacing: 0.5, textTransform: 'uppercase', color: t.textTer,
                }}>Minerals</div>
                <MicroRow mode={mode} label="Calcium"   unit="mg" value={micros.calcium}   onChange={(v) => upd('calcium', v)} />
                <MicroRow mode={mode} label="Iron"      unit="mg" value={micros.iron}      onChange={(v) => upd('iron', v)} />
                <MicroRow mode={mode} label="Magnesium" unit="mg" value={micros.magnesium} onChange={(v) => upd('magnesium', v)} />
                <MicroRow mode={mode} label="Potassium" unit="mg" value={micros.potassium} onChange={(v) => upd('potassium', v)} />
                <MicroRow mode={mode} label="Zinc"      unit="mg" value={micros.zinc}      onChange={(v) => upd('zinc', v)} />
              </div>
            )}
          </div>

          {/* Share toggle */}
          <CFSectionLabel mode={mode}>Community</CFSectionLabel>
          <div onClick={() => setShare(s => !s)} style={{ cursor: 'pointer' }}>
            <div style={{
              background: t.surface, border: '1px solid ' + t.separator,
              borderRadius: BC_RADIUS.lg,
              padding: '14px 16px',
              display: 'flex', alignItems: 'center', gap: 12,
            }}>
              <div style={{ flex: 1 }}>
                <div style={{ fontSize: 15, fontWeight: 600, color: t.text, letterSpacing: -0.2 }}>
                  Share with BluCal community database
                </div>
                <div style={{ fontSize: 12, color: t.textSec, marginTop: 3, lineHeight: '16px' }}>
                  Anyone scanning the same barcode or searching this name can find it. We'll credit you anonymously.
                </div>
              </div>
              <div style={{ pointerEvents: 'none' }}>
                <BCSwitch on={share} />
              </div>
            </div>
          </div>

          {/* Validation hint */}
          {!canSave && (
            <div style={{ marginTop: 14, padding: '10px 14px', background: t.warnSoft, borderRadius: BC_RADIUS.md,
              display: 'flex', gap: 8, alignItems: 'flex-start',
              fontSize: 12, color: t.text, lineHeight: '17px' }}>
              <BCIcon name="info" size={14} color={t.warn} style={{ marginTop: 2, flexShrink: 0 }} />
              <span>Add a <b>food name</b> and <b>calories</b> to enable Create.</span>
            </div>
          )}
        </div>
      </div>

      {/* Sticky Save bar */}
      <div style={{
        position: 'absolute', left: 0, right: 0, bottom: 0,
        padding: '12px 16px 26px',
        background: t.bg,
        borderTop: '0.5px solid ' + t.separator,
      }}>
        <BCButton kind="primary" size="lg" block state={canSave ? undefined : 'disabled'}>
          Create food
        </BCButton>
      </div>
    </BCTheme>
  );
}

// Pre-filled variant for visualizing the populated state
function CustomFoodScreenFilled({ mode = 'light' }) {
  // Mirror of CustomFoodScreen but with state seeded so the artboard reads
  // as a completed form rather than a blank one.
  const t = mode === 'dark' ? BC_DARK : BC_LIGHT;
  const [name, setName] = React.useState('Almond butter overnight oats');
  const [brand, setBrand] = React.useState('Home');
  const [serving, setServing] = React.useState('250');
  const [unit, setUnit] = React.useState('g');
  const [kcal, setKcal] = React.useState('410');
  const [p, setP] = React.useState('16');
  const [c, setC] = React.useState('52');
  const [f, setF] = React.useState('14');
  const [fiber, setFiber] = React.useState('8');
  const [sugar, setSugar] = React.useState('12');
  const [sodium, setSodium] = React.useState('180');
  const [microOpen, setMicroOpen] = React.useState(true);
  const [share, setShare] = React.useState(true);
  const [micros, setMicros] = React.useState({
    vitA: '', vitC: '', vitD: '', vitE: '4.2', vitK: '',
    b12: '0.8', folate: '',
    calcium: '210', iron: '3.2', magnesium: '120', potassium: '480', zinc: '2.1',
  });
  const upd = (k, v) => setMicros(m => ({ ...m, [k]: v }));
  const canSave = name.trim().length > 0 && kcal !== '';

  return (
    <BCTheme mode={mode} padding={0} style={{ position: 'relative', overflow: 'hidden', height: '100%' }}>
      <CFStatusBar mode={mode} />
      <CFNavBar mode={mode} canSave={canSave} />

      <div style={{ position: 'absolute', top: 54 + 52, left: 0, right: 0, bottom: 86, overflowY: 'auto', overflowX: 'hidden' }}>
        <div style={{ padding: '12px 16px 24px' }}>
          <CFSectionLabel mode={mode}>Basics</CFSectionLabel>
          <CFRow mode={mode} label="Food name" required first value={name} onChange={setName} />
          <CFRow mode={mode} label="Brand" last value={brand} onChange={setBrand} />

          <CFSectionLabel mode={mode}>Serving size</CFSectionLabel>
          <div style={{
            background: t.surface, border: '1px solid ' + t.separator,
            borderRadius: BC_RADIUS.lg, padding: '10px 14px',
            display: 'flex', alignItems: 'center', gap: 12,
          }}>
            <div style={{ width: 140, fontSize: 14, fontWeight: 500, color: t.text }}>Amount per serving</div>
            <input value={serving} onChange={(e) => setServing(e.target.value)} style={{
              flex: 1, minWidth: 0, height: 36, padding: '0 12px',
              background: t.surface2, border: '1px solid ' + t.separator, borderRadius: 8, outline: 'none',
              fontFamily: SF_STACK, fontSize: 16, fontWeight: 700, color: t.text,
              textAlign: 'right', fontVariantNumeric: 'tabular-nums',
            }}/>
            <select value={unit} onChange={(e) => setUnit(e.target.value)} style={{
              width: 92, height: 36, padding: '0 26px 0 10px', flexShrink: 0,
              background: t.surface2, color: t.text,
              border: '1px solid ' + t.separator, borderRadius: 8,
              fontFamily: SF_STACK, fontSize: 14, fontWeight: 600, appearance: 'none',
              backgroundImage: `url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='12' height='12' viewBox='0 0 24 24' fill='none' stroke='${encodeURIComponent(t.textSec)}' stroke-width='2.2' stroke-linecap='round' stroke-linejoin='round'><path d='M6 9l6 6 6-6'/></svg>")`,
              backgroundRepeat: 'no-repeat', backgroundPosition: 'right 8px center',
            }}>
              {['g', 'oz', 'cup', 'tbsp', 'tsp', 'serving', 'piece', 'ml', 'fl oz'].map(o => <option key={o} value={o}>{o}</option>)}
            </select>
          </div>

          <CFSectionLabel mode={mode}>Nutrition · per serving</CFSectionLabel>
          <CFRow mode={mode} label="Calories" required first type="number" unit="kcal" value={kcal} onChange={setKcal} />
          <CFRow mode={mode} label="Protein" type="number" unit="g" value={p} onChange={setP} />
          <CFRow mode={mode} label="Carbohydrates" type="number" unit="g" value={c} onChange={setC} />
          <CFRow mode={mode} label="Fat" type="number" unit="g" value={f} onChange={setF} />
          <CFRow mode={mode} label="Fiber" type="number" unit="g" value={fiber} onChange={setFiber} />
          <CFRow mode={mode} label="Sugar" type="number" unit="g" value={sugar} onChange={setSugar} />
          <CFRow mode={mode} label="Sodium" last type="number" unit="mg" value={sodium} onChange={setSodium} />

          <CFSectionLabel mode={mode}
            action={<span style={{ fontSize: 11, fontWeight: 700, color: t.textTer, letterSpacing: 0.4, textTransform: 'uppercase' }}>Optional</span>}
          >More</CFSectionLabel>
          <div style={{
            background: t.surface, border: '1px solid ' + t.separator, borderRadius: BC_RADIUS.lg, overflow: 'hidden',
          }}>
            <button onClick={() => setMicroOpen(o => !o)} style={{
              width: '100%', padding: '14px 16px', background: 'transparent', border: 'none',
              display: 'flex', alignItems: 'center', gap: 10, cursor: 'pointer', fontFamily: SF_STACK, textAlign: 'left',
            }}>
              <div style={{ flex: 1 }}>
                <div style={{ fontSize: 15, fontWeight: 700, color: t.text, letterSpacing: -0.2 }}>Add micronutrients</div>
                <div style={{ fontSize: 12, color: t.textSec, marginTop: 2 }}>5 values added</div>
              </div>
              <span style={{
                width: 22, height: 22, display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
                color: t.textSec, transform: microOpen ? 'rotate(180deg)' : 'rotate(0deg)', transition: 'transform .15s',
              }}>
                <BCIcon name="caret-down" size={18} color={t.textSec} />
              </span>
            </button>
            {microOpen && (
              <div style={{ padding: '4px 16px 14px', borderTop: '0.5px solid ' + t.separator }}>
                <div style={{ paddingTop: 6, marginBottom: 4, fontSize: 11, fontWeight: 700, letterSpacing: 0.5, textTransform: 'uppercase', color: t.textTer }}>Vitamins</div>
                <MicroRow mode={mode} label="Vitamin E"   unit="mg"  value={micros.vitE} onChange={(v) => upd('vitE', v)} />
                <MicroRow mode={mode} label="Vitamin B12" unit="mcg" value={micros.b12} onChange={(v) => upd('b12', v)} />
                <div style={{ paddingTop: 12, marginBottom: 4, fontSize: 11, fontWeight: 700, letterSpacing: 0.5, textTransform: 'uppercase', color: t.textTer }}>Minerals</div>
                <MicroRow mode={mode} label="Calcium"   unit="mg" value={micros.calcium} onChange={(v) => upd('calcium', v)} />
                <MicroRow mode={mode} label="Iron"      unit="mg" value={micros.iron} onChange={(v) => upd('iron', v)} />
                <MicroRow mode={mode} label="Magnesium" unit="mg" value={micros.magnesium} onChange={(v) => upd('magnesium', v)} />
                <MicroRow mode={mode} label="Potassium" unit="mg" value={micros.potassium} onChange={(v) => upd('potassium', v)} />
                <MicroRow mode={mode} label="Zinc"      unit="mg" value={micros.zinc} onChange={(v) => upd('zinc', v)} />
              </div>
            )}
          </div>

          <CFSectionLabel mode={mode}>Community</CFSectionLabel>
          <div onClick={() => setShare(s => !s)} style={{ cursor: 'pointer' }}>
            <div style={{
              background: t.surface, border: '1px solid ' + t.separator,
              borderRadius: BC_RADIUS.lg, padding: '14px 16px',
              display: 'flex', alignItems: 'center', gap: 12,
            }}>
              <div style={{ flex: 1 }}>
                <div style={{ fontSize: 15, fontWeight: 600, color: t.text, letterSpacing: -0.2 }}>
                  Share with BluCal community database
                </div>
                <div style={{ fontSize: 12, color: t.textSec, marginTop: 3, lineHeight: '16px' }}>
                  Anyone scanning the same barcode or searching this name can find it. We'll credit you anonymously.
                </div>
              </div>
              <div style={{ pointerEvents: 'none' }}><BCSwitch on={share} /></div>
            </div>
          </div>
        </div>
      </div>

      <div style={{
        position: 'absolute', left: 0, right: 0, bottom: 0,
        padding: '12px 16px 26px', background: t.bg, borderTop: '0.5px solid ' + t.separator,
      }}>
        <BCButton kind="primary" size="lg" block>Create food</BCButton>
      </div>
    </BCTheme>
  );
}

Object.assign(window, { CustomFoodScreen, CustomFoodScreenFilled });
