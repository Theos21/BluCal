// ds-app.jsx — assemble the canvas

function Frame({ mode, padding = 22, children }) {
  return (
    <BCTheme mode={mode} padding={padding}>{children}</BCTheme>
  );
}

function App() {
  return (
    <DesignCanvas>
      <DCSection id="intro" title="BluCal — Design System" subtitle="iOS nutrition & macro tracking · light + dark · v0.1">
        <DCArtboard id="cover" label="Cover" width={580} height={620}>
          <BCTheme mode="light" padding={36}>
            <VStack gap={18} style={{ height: '100%' }}>
              <HStack gap={12}>
                <BluCalLogo size={56} />
                <VStack gap={2}>
                  <BCType scale="title2">BluCal</BCType>
                  <BCType scale="footnote" color="#5C5C63">Nutrition & macro tracking · iOS</BCType>
                </VStack>
              </HStack>
              <BCType scale="title3" color="#5C5C63" style={{ marginTop: 8 }}>
                A clean, calm tracking experience. Native iOS feel, generous whitespace, brand-driven moments.
              </BCType>

              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 14, marginTop: 8 }}>
                {[
                  ['Primary', '#185FA5', '#FFFFFF'],
                  ['Teal accent', '#0F6E56', '#FFFFFF'],
                  ['Surface', '#FFFFFF', '#0B0B0F'],
                  ['Dark surface', '#16161A', '#F2F2F4'],
                ].map(([n, bg, fg]) => (
                  <div key={n} style={{
                    background: bg, color: fg, borderRadius: 14, padding: 16, height: 84,
                    display: 'flex', flexDirection: 'column', justifyContent: 'space-between',
                    border: '1px solid rgba(0,0,0,0.06)',
                  }}>
                    <div style={{ fontSize: 12, fontWeight: 600, letterSpacing: 0.4, textTransform: 'uppercase', opacity: 0.7 }}>{n}</div>
                    <div style={{ fontFamily: 'ui-monospace, Menlo, monospace', fontSize: 13, fontWeight: 600 }}>{bg}</div>
                  </div>
                ))}
              </div>

              <div style={{ marginTop: 6, padding: 16, background: '#EEEEF1', borderRadius: 14 }}>
                <BCType scale="caption2" color="#5C5C63" weight={600}>SYSTEM PILLARS</BCType>
                <VStack gap={6} style={{ marginTop: 8 }}>
                  {[
                    'iOS Health-inspired hierarchy: large titles, grouped lists, system blur',
                    'BluCal blue carries identity; teal handles healthy / positive signals',
                    'Macro rings are the brand visual — used at every scale',
                    'No gradients on UI surfaces. Color comes from solid tinted fills.',
                    'Pure-black dark mode for OLED; brand lifts 2 steps for AA contrast',
                  ].map((s, i) => (
                    <HStack key={i} gap={8} align="flex-start">
                      <div style={{ width: 5, height: 5, borderRadius: 999, background: '#185FA5', marginTop: 8 }} />
                      <BCType scale="callout">{s}</BCType>
                    </HStack>
                  ))}
                </VStack>
              </div>
            </VStack>
          </BCTheme>
        </DCArtboard>
      </DCSection>

      <DCSection id="brand" title="00 · Brand" subtitle="Locked assets — do not modify">
        <DCArtboard id="brand-light" label="Logo system · Light" width={680} height={540}>
          <BCTheme mode="light" padding={28}>
            <VStack gap={22}>
              <div>
                <div style={{ fontSize: 11, fontWeight: 700, letterSpacing: 0.6, textTransform: 'uppercase', color: BC_LIGHT.textTer, marginBottom: 14 }}>App icon</div>
                <HStack gap={20} align="center">
                  {[40, 64, 96, 144].map(s => (
                    <VStack key={s} gap={8} style={{ alignItems: 'center' }}>
                      <BluCalAppIcon size={s} />
                      <div style={{ fontSize: 10, color: BC_LIGHT.textTer, fontFamily: 'ui-monospace, Menlo, monospace' }}>{s}px</div>
                    </VStack>
                  ))}
                </HStack>
              </div>
              <div>
                <div style={{ fontSize: 11, fontWeight: 700, letterSpacing: 0.6, textTransform: 'uppercase', color: BC_LIGHT.textTer, marginBottom: 14 }}>Wordmark</div>
                <VStack gap={14} style={{ alignItems: 'flex-start' }}>
                  <BluCalWordmark width={140} />
                  <BluCalWordmark width={180} />
                  <BluCalWordmark width={220} />
                </VStack>
              </div>
              <div>
                <div style={{ fontSize: 11, fontWeight: 700, letterSpacing: 0.6, textTransform: 'uppercase', color: BC_LIGHT.textTer, marginBottom: 14 }}>Icon mark · tab-bar states</div>
                <HStack gap={28} align="center">
                  <VStack gap={8} style={{ alignItems: 'center' }}>
                    <BluCalMark size={32} color="#185FA5" />
                    <div style={{ fontSize: 11, color: BC_LIGHT.textSec, fontWeight: 600 }}>Active</div>
                  </VStack>
                  <VStack gap={8} style={{ alignItems: 'center' }}>
                    <BluCalMark size={32} color="#8E8E93" />
                    <div style={{ fontSize: 11, color: BC_LIGHT.textSec, fontWeight: 600 }}>Inactive</div>
                  </VStack>
                  <VStack gap={8} style={{ alignItems: 'center' }}>
                    <BluCalMark size={48} color="#185FA5" />
                    <div style={{ fontSize: 11, color: BC_LIGHT.textSec, fontWeight: 600 }}>48px</div>
                  </VStack>
                </HStack>
              </div>
            </VStack>
          </BCTheme>
        </DCArtboard>
        <DCArtboard id="brand-dark" label="Logo system · Dark + on color" width={680} height={540}>
          <BCTheme mode="dark" padding={28}>
            <VStack gap={22}>
              <div>
                <div style={{ fontSize: 11, fontWeight: 700, letterSpacing: 0.6, textTransform: 'uppercase', color: BC_DARK.textTer, marginBottom: 14 }}>App icon on dark surfaces</div>
                <HStack gap={16}>
                  <div style={{ background: BC_DARK.bg, borderRadius: 16, padding: 20, display: 'flex', alignItems: 'center', justifyContent: 'center', width: 130, height: 130, border: '1px solid ' + BC_DARK.separator }}>
                    <BluCalAppIcon size={90} />
                  </div>
                  <div style={{ background: BC_DARK.surface, borderRadius: 16, padding: 20, display: 'flex', alignItems: 'center', justifyContent: 'center', width: 130, height: 130, border: '1px solid ' + BC_DARK.separator }}>
                    <BluCalAppIcon size={90} />
                  </div>
                  <div style={{ background: BC_DARK.teal, borderRadius: 16, padding: 20, display: 'flex', alignItems: 'center', justifyContent: 'center', width: 130, height: 130 }}>
                    <BluCalAppIcon size={90} />
                  </div>
                </HStack>
              </div>
              <div>
                <div style={{ fontSize: 11, fontWeight: 700, letterSpacing: 0.6, textTransform: 'uppercase', color: BC_DARK.textTer, marginBottom: 14 }}>Wordmark · dark mode</div>
                <VStack gap={14} style={{ alignItems: 'flex-start' }}>
                  <BluCalWordmark width={180} mode="dark" />
                  <BluCalWordmark width={220} mode="dark" />
                </VStack>
              </div>
              <div>
                <div style={{ fontSize: 11, fontWeight: 700, letterSpacing: 0.6, textTransform: 'uppercase', color: BC_DARK.textTer, marginBottom: 14 }}>Icon mark · dark tab bar</div>
                <HStack gap={28} align="center">
                  <VStack gap={8} style={{ alignItems: 'center' }}>
                    <BluCalMark size={32} color="#FFFFFF" />
                    <div style={{ fontSize: 11, color: BC_DARK.textSec, fontWeight: 600 }}>Active</div>
                  </VStack>
                  <VStack gap={8} style={{ alignItems: 'center' }}>
                    <BluCalMark size={32} color="#8E8E93" />
                    <div style={{ fontSize: 11, color: BC_DARK.textSec, fontWeight: 600 }}>Inactive</div>
                  </VStack>
                </HStack>
              </div>
            </VStack>
          </BCTheme>
        </DCArtboard>
      </DCSection>

      <DCSection id="colors" title="01 · Color" subtitle="Surfaces, text, brand, semantic — both modes">
        <DCArtboard id="colors-light" label="Light" width={620} height={620}>
          <Frame mode="light"><BCColorPalette /></Frame>
        </DCArtboard>
        <DCArtboard id="colors-dark" label="Dark" width={620} height={620}>
          <Frame mode="dark"><BCColorPalette /></Frame>
        </DCArtboard>
      </DCSection>

      <DCSection id="type" title="02 · Type & Spacing" subtitle="SF Pro Text/Display · 4px grid">
        <DCArtboard id="type-light" label="Type · Light" width={620} height={640}>
          <Frame mode="light"><BCTypeScale /></Frame>
        </DCArtboard>
        <DCArtboard id="type-dark" label="Type · Dark" width={620} height={640}>
          <Frame mode="dark"><BCTypeScale /></Frame>
        </DCArtboard>
        <DCArtboard id="spacing" label="Spacing & Radius" width={460} height={640}>
          <Frame mode="light"><BCSpacingScale /></Frame>
        </DCArtboard>
      </DCSection>

      <DCSection id="buttons" title="03 · Buttons" subtitle="Five kinds · three sizes · five states">
        <DCArtboard id="btn-light" label="Light" width={700} height={620}>
          <Frame mode="light"><BCButtonGallery /></Frame>
        </DCArtboard>
        <DCArtboard id="btn-dark" label="Dark" width={700} height={620}>
          <Frame mode="dark"><BCButtonGallery /></Frame>
        </DCArtboard>
      </DCSection>

      <DCSection id="inputs" title="04 · Inputs & Controls" subtitle="Text fields, search, segmented, switches, sliders">
        <DCArtboard id="in-light" label="Light" width={620} height={780}>
          <Frame mode="light"><BCInputsGallery /></Frame>
        </DCArtboard>
        <DCArtboard id="in-dark" label="Dark" width={620} height={780}>
          <Frame mode="dark"><BCInputsGallery /></Frame>
        </DCArtboard>
      </DCSection>

      <DCSection id="surfaces" title="05 · Cards, Rows & Badges" subtitle="Plus the BluCal macro ring — the brand visual">
        <DCArtboard id="sf-light" label="Light" width={680} height={820}>
          <Frame mode="light"><BCSurfacesGallery /></Frame>
        </DCArtboard>
        <DCArtboard id="sf-dark" label="Dark" width={680} height={820}>
          <Frame mode="dark"><BCSurfacesGallery /></Frame>
        </DCArtboard>
      </DCSection>

      <DCSection id="nav" title="06 · Navigation" subtitle="Bottom tabs (Today · Trends · Meals · Coach · Profile) + nav bars">
        <DCArtboard id="nav-light" label="Light" width={520} height={780}>
          <Frame mode="light"><BCTabBarGallery mode="light" /></Frame>
        </DCArtboard>
        <DCArtboard id="nav-dark" label="Dark" width={520} height={780}>
          <Frame mode="dark"><BCTabBarGallery mode="dark" /></Frame>
        </DCArtboard>
      </DCSection>

      <DCSection id="overlays" title="07 · Overlays" subtitle="Bottom sheets, alerts, action sheets, toasts, inline banners">
        <DCArtboard id="ov-light" label="Light" width={1080} height={820}>
          <Frame mode="light"><BCOverlaysGallery mode="light" /></Frame>
        </DCArtboard>
        <DCArtboard id="ov-dark" label="Dark" width={1080} height={820}>
          <Frame mode="dark"><BCOverlaysGallery mode="dark" /></Frame>
        </DCArtboard>
      </DCSection>
    </DesignCanvas>
  );
}

ReactDOM.createRoot(document.getElementById('root')).render(<App />);
