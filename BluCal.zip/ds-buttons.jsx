// ds-buttons.jsx — Button component + button gallery artboard

function BCButton({
  kind = 'primary',     // 'primary' | 'secondary' | 'tinted' | 'plain' | 'destructive'
  size = 'lg',          // 'lg' (50) | 'md' (40) | 'sm' (32)
  block = false,
  icon,
  iconRight,
  state,                // undefined | 'press' | 'disabled' | 'loading'
  children,
  style,
  onClick,
  ...rest
}) {
  const { t } = useBC();
  const disabled = state === 'disabled';
  const pressed = state === 'press';

  const h = size === 'lg' ? 50 : size === 'md' ? 40 : 32;
  const fs = size === 'lg' ? 17 : size === 'md' ? 15 : 13;
  const fw = size === 'sm' ? 600 : 600;
  const px = size === 'lg' ? 22 : size === 'md' ? 16 : 12;
  const radius = size === 'lg' ? BC_RADIUS.lg : size === 'md' ? BC_RADIUS.md : BC_RADIUS.sm;

  let bg, fg, border = 'none';

  if (kind === 'primary') {
    bg = pressed ? t.primaryPress : t.primary;
    fg = t.textOnPrim;
  } else if (kind === 'destructive') {
    bg = pressed ? t.dangerPress : t.danger;
    fg = '#FFFFFF';
  } else if (kind === 'secondary') {
    bg = pressed ? t.surface3 : t.surface2;
    fg = t.text;
    border = '1px solid ' + t.separator;
  } else if (kind === 'tinted') {
    bg = pressed ? t.primarySoftHi : t.primarySoft;
    fg = t.primary;
  } else if (kind === 'plain') {
    bg = pressed ? t.primarySoft : 'transparent';
    fg = t.primary;
  }

  return (
    <button disabled={disabled} onClick={onClick} {...rest} style={{
      height: h,
      padding: `0 ${px}px`,
      fontSize: fs,
      fontWeight: fw,
      letterSpacing: -0.32,
      fontFamily: SF_STACK,
      color: fg,
      background: bg,
      border,
      borderRadius: radius,
      display: 'inline-flex',
      alignItems: 'center',
      justifyContent: 'center',
      gap: 8,
      width: block ? '100%' : 'auto',
      opacity: disabled ? 0.4 : 1,
      cursor: disabled ? 'not-allowed' : 'pointer',
      WebkitTapHighlightColor: 'transparent',
      ...style,
    }}>
      {state === 'loading' ? (
        <span style={{
          width: 16, height: 16, borderRadius: 999,
          border: `2px solid ${fg}`, borderTopColor: 'transparent',
          animation: 'bc-spin 0.7s linear infinite',
        }} />
      ) : icon}
      {children && <span>{children}</span>}
      {iconRight}
    </button>
  );
}

// Icon-only round button (FAB-style)
function BCFab({ tone = 'primary', size = 56, icon, label, style }) {
  const { t } = useBC();
  const bg = tone === 'primary' ? t.primary : tone === 'teal' ? t.teal : t.surface;
  const fg = tone === 'primary' || tone === 'teal' ? '#FFFFFF' : t.text;
  return (
    <button style={{
      width: size, height: size, borderRadius: size / 2,
      background: bg, color: fg, border: 'none',
      display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
      cursor: 'pointer',
      boxShadow: '0 6px 20px rgba(24,95,165,0.25), 0 2px 4px rgba(0,0,0,0.06)',
      ...style,
    }} aria-label={label}>{icon}</button>
  );
}

function BCButtonGallery() {
  const { t } = useBC();
  const Row = ({ label, children }) => (
    <div style={{ display: 'grid', gridTemplateColumns: '90px 1fr', gap: 16, alignItems: 'center' }}>
      <div style={{ fontSize: 11, fontWeight: 600, letterSpacing: 0.6, textTransform: 'uppercase', color: t.textTer }}>{label}</div>
      <HStack gap={10} style={{ flexWrap: 'wrap' }}>{children}</HStack>
    </div>
  );
  return (
    <>
      <style>{`@keyframes bc-spin { to { transform: rotate(360deg) } }`}</style>
      <VStack gap={18}>
        <Row label="Primary">
          <BCButton kind="primary">Log meal</BCButton>
          <BCButton kind="primary" state="press">Pressed</BCButton>
          <BCButton kind="primary" state="loading">Saving</BCButton>
          <BCButton kind="primary" state="disabled">Disabled</BCButton>
          <BCButton kind="primary" icon={<BCIcon name="plus" size={18} />}>Add food</BCButton>
        </Row>
        <Row label="Secondary">
          <BCButton kind="secondary">Cancel</BCButton>
          <BCButton kind="secondary" state="press">Pressed</BCButton>
          <BCButton kind="secondary" icon={<BCIcon name="barcode" size={18} />}>Scan barcode</BCButton>
          <BCButton kind="secondary" state="disabled">Disabled</BCButton>
        </Row>
        <Row label="Tinted">
          <BCButton kind="tinted">View details</BCButton>
          <BCButton kind="tinted" state="press">Pressed</BCButton>
          <BCButton kind="tinted" icon={<BCIcon name="chart" size={18} />}>See trend</BCButton>
        </Row>
        <Row label="Plain">
          <BCButton kind="plain">Edit</BCButton>
          <BCButton kind="plain" state="press">Pressed</BCButton>
          <BCButton kind="plain" iconRight={<BCIcon name="chev" size={16} />}>See all</BCButton>
        </Row>
        <Row label="Destructive">
          <BCButton kind="destructive">Delete entry</BCButton>
          <BCButton kind="destructive" state="press">Pressed</BCButton>
          <BCButton kind="destructive" state="disabled">Disabled</BCButton>
        </Row>

        <div style={{ height: 1, background: t.separator, margin: '4px 0' }} />

        <Row label="Sizes">
          <BCButton kind="primary" size="lg">Large 50</BCButton>
          <BCButton kind="primary" size="md">Medium 40</BCButton>
          <BCButton kind="primary" size="sm">Small 32</BCButton>
        </Row>

        <Row label="Block">
          <div style={{ width: '100%' }}>
            <BCButton kind="primary" block icon={<BCIcon name="plus" size={20} />}>Log meal</BCButton>
          </div>
        </Row>

        <Row label="FAB">
          <BCFab tone="primary" icon={<BCIcon name="plus" size={26} />} label="Add" />
          <BCFab tone="teal" size={48} icon={<BCIcon name="mic" size={20} />} label="Voice" />
          <BCFab tone="surface" size={44} icon={<BCIcon name="barcode" size={20} />} label="Scan" />
        </Row>
      </VStack>
    </>
  );
}

Object.assign(window, { BCButton, BCFab, BCButtonGallery });
