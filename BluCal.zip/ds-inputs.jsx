// ds-inputs.jsx — Text fields, search field, stepper, segmented control, switch

function BCField({
  label, value, placeholder, unit, helper, error, focused, disabled,
  icon, trailing, type = 'text',
}) {
  const { t } = useBC();
  const showFocus = focused;
  const showError = !!error;
  const border = showError ? t.danger : showFocus ? t.primary : t.separator;
  const borderW = showFocus || showError ? 2 : 1;

  return (
    <VStack gap={6}>
      {label && <div style={{ fontSize: 13, fontWeight: 600, color: t.textSec }}>{label}</div>}
      <div style={{
        display: 'flex', alignItems: 'center', gap: 10,
        height: 48,
        padding: '0 14px',
        background: t.surface,
        border: `${borderW}px solid ${border}`,
        borderRadius: BC_RADIUS.md,
        opacity: disabled ? 0.5 : 1,
      }}>
        {icon && <span style={{ color: t.textTer, display: 'flex' }}>{icon}</span>}
        <div style={{
          flex: 1, fontSize: 17, color: value ? t.text : t.textTer,
          fontFamily: SF_STACK, letterSpacing: -0.41,
        }}>{value || placeholder}{showFocus && <span style={{ display: 'inline-block', width: 2, height: 20, marginLeft: 1, background: t.primary, verticalAlign: 'middle', animation: 'bc-blink 1s steps(2) infinite' }} />}</div>
        {unit && <span style={{ fontSize: 15, color: t.textSec, fontWeight: 500 }}>{unit}</span>}
        {trailing}
      </div>
      {(helper || error) && (
        <div style={{ fontSize: 12, color: showError ? t.danger : t.textSec, display: 'flex', gap: 6, alignItems: 'center' }}>
          {showError && <BCIcon name="warning" size={13} color={t.danger} />}
          {error || helper}
        </div>
      )}
    </VStack>
  );
}

function BCSearch({ value, placeholder = 'Search foods', focused }) {
  const { t } = useBC();
  return (
    <div style={{
      display: 'flex', alignItems: 'center', gap: 8,
      height: 40, padding: '0 12px',
      background: t.surface2, borderRadius: BC_RADIUS.sm,
      border: focused ? '2px solid ' + t.primary : '1px solid transparent',
    }}>
      <BCIcon name="search" size={18} color={t.textTer} />
      <div style={{ flex: 1, fontSize: 17, color: value ? t.text : t.textTer, letterSpacing: -0.41 }}>{value || placeholder}</div>
      <BCIcon name="mic" size={18} color={t.textTer} />
    </div>
  );
}

function BCStepper({ value = 1 }) {
  const { t } = useBC();
  return (
    <div style={{
      display: 'inline-flex', alignItems: 'center',
      background: t.surface2, borderRadius: BC_RADIUS.sm, overflow: 'hidden',
      height: 32, border: '1px solid ' + t.separator,
    }}>
      <button style={{ width: 36, height: '100%', background: 'transparent', border: 0, color: t.text, fontSize: 18, cursor: 'pointer' }}>−</button>
      <div style={{ width: 1, background: t.separator, alignSelf: 'stretch' }} />
      <div style={{ minWidth: 36, textAlign: 'center', fontSize: 15, fontWeight: 600, color: t.text }}>{value}</div>
      <div style={{ width: 1, background: t.separator, alignSelf: 'stretch' }} />
      <button style={{ width: 36, height: '100%', background: 'transparent', border: 0, color: t.text, fontSize: 18, cursor: 'pointer' }}>+</button>
    </div>
  );
}

function BCSegmented({ options, active = 0 }) {
  const { t } = useBC();
  return (
    <div style={{
      display: 'inline-flex', padding: 2,
      background: t.surface2, borderRadius: BC_RADIUS.sm,
      height: 32,
    }}>
      {options.map((o, i) => (
        <div key={i} style={{
          padding: '0 14px',
          height: 28,
          borderRadius: BC_RADIUS.xs,
          background: i === active ? t.surface : 'transparent',
          color: t.text,
          fontSize: 13, fontWeight: i === active ? 600 : 500,
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          boxShadow: i === active ? '0 1px 2px rgba(0,0,0,0.08)' : 'none',
          cursor: 'pointer',
        }}>{o}</div>
      ))}
    </div>
  );
}

function BCSwitch({ on = true, tone = 'primary' }) {
  const { t } = useBC();
  const trackOn = tone === 'teal' ? t.teal : t.primary;
  return (
    <div style={{
      width: 51, height: 31, borderRadius: 999,
      background: on ? trackOn : t.surface3,
      position: 'relative',
      transition: 'background .15s',
    }}>
      <div style={{
        position: 'absolute', top: 2, left: on ? 22 : 2,
        width: 27, height: 27, borderRadius: 999, background: '#fff',
        boxShadow: '0 2px 6px rgba(0,0,0,0.15), 0 0 1px rgba(0,0,0,0.1)',
        transition: 'left .18s cubic-bezier(.5,.2,.2,1)',
      }} />
    </div>
  );
}

function BCSlider({ value = 0.42, tone = 'primary' }) {
  const { t } = useBC();
  const c = tone === 'teal' ? t.teal : t.primary;
  return (
    <div style={{ height: 28, display: 'flex', alignItems: 'center', position: 'relative' }}>
      <div style={{ height: 4, borderRadius: 4, background: t.surface3, width: '100%', overflow: 'hidden' }}>
        <div style={{ height: '100%', width: (value * 100) + '%', background: c }} />
      </div>
      <div style={{
        position: 'absolute', left: `calc(${value * 100}% - 14px)`,
        width: 28, height: 28, borderRadius: 999, background: '#fff',
        boxShadow: '0 2px 8px rgba(0,0,0,0.18), 0 0 1px rgba(0,0,0,0.15)',
      }} />
    </div>
  );
}

function BCInputsGallery() {
  const { t } = useBC();
  const Row = ({ label, children }) => (
    <div style={{ display: 'grid', gridTemplateColumns: '90px 1fr', gap: 16, alignItems: 'start' }}>
      <div style={{ fontSize: 11, fontWeight: 600, letterSpacing: 0.6, textTransform: 'uppercase', color: t.textTer, paddingTop: 8 }}>{label}</div>
      <div>{children}</div>
    </div>
  );
  return (
    <>
      <style>{`@keyframes bc-blink { 50% { opacity: 0 } }`}</style>
      <VStack gap={18}>
        <Row label="Text Fields">
          <VStack gap={14}>
            <BCField label="Food name" value="Greek yogurt, plain" />
            <BCField label="Serving size" value="170" unit="g" focused />
            <BCField label="Calorie target" placeholder="Enter target" helper="Recommended: 2,000–2,400 / day" />
            <BCField label="Email" value="alex@email" error="Enter a valid email address" />
            <BCField label="Notes" value="" placeholder="Optional" disabled />
          </VStack>
        </Row>
        <Row label="Search"><BCSearch focused /></Row>
        <Row label="Segmented">
          <VStack gap={10}>
            <BCSegmented options={['Day','Week','Month','6M']} active={1} />
            <BCSegmented options={['Calories','Macros','Weight']} active={0} />
          </VStack>
        </Row>
        <Row label="Stepper">
          <HStack gap={14}>
            <BCStepper value={1} />
            <span style={{ fontSize: 13, color: t.textSec }}>Servings</span>
          </HStack>
        </Row>
        <Row label="Switch">
          <HStack gap={20}>
            <HStack gap={8}><BCSwitch on={true} /><span style={{ fontSize: 13, color: t.textSec }}>On</span></HStack>
            <HStack gap={8}><BCSwitch on={false} /><span style={{ fontSize: 13, color: t.textSec }}>Off</span></HStack>
            <HStack gap={8}><BCSwitch on={true} tone="teal" /><span style={{ fontSize: 13, color: t.textSec }}>Teal</span></HStack>
          </HStack>
        </Row>
        <Row label="Slider">
          <VStack gap={12} style={{ maxWidth: 320 }}>
            <BCSlider value={0.42} />
            <BCSlider value={0.72} tone="teal" />
          </VStack>
        </Row>
      </VStack>
    </>
  );
}

Object.assign(window, { BCField, BCSearch, BCStepper, BCSegmented, BCSwitch, BCSlider, BCInputsGallery });
