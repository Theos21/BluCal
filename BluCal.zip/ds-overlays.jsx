// ds-overlays.jsx — bottom sheet, modal, action sheet, toast / alert banner

// Static phone-shaped frame for showing overlays in context. Not an ios_frame —
// we're displaying components in a context-free spec environment.
function BCPhoneFrame({ width = 280, height = 540, children, mode }) {
  const { t } = useBC();
  return (
    <div style={{
      width, height, position: 'relative',
      borderRadius: 36,
      background: t.bg,
      border: '1px solid ' + t.hairline,
      overflow: 'hidden',
      boxShadow: mode === 'dark'
        ? '0 30px 60px -20px rgba(0,0,0,0.5), 0 0 0 6px #1a1a1d'
        : '0 30px 60px -20px rgba(20,30,40,0.18), 0 0 0 6px #d4d2cd',
    }}>{children}</div>
  );
}

function BCBottomSheet({ title, dismiss, children, height = 360 }) {
  const { t } = useBC();
  return (
    <>
      <div style={{ position: 'absolute', inset: 0, background: t.scrim, backdropFilter: 'blur(2px)' }} />
      <div style={{
        position: 'absolute', left: 0, right: 0, bottom: 0,
        background: t.surface,
        borderTopLeftRadius: 22, borderTopRightRadius: 22,
        boxShadow: '0 -8px 32px rgba(0,0,0,0.15)',
        maxHeight: height,
        display: 'flex', flexDirection: 'column',
      }}>
        <div style={{ display: 'flex', justifyContent: 'center', padding: '8px 0 4px' }}>
          <div style={{ width: 38, height: 5, background: t.hairline, borderRadius: 999 }} />
        </div>
        {title && (
          <div style={{ padding: '8px 18px 12px', display: 'flex', alignItems: 'center' }}>
            <div style={{ fontSize: 17, fontWeight: 600, color: t.text, letterSpacing: -0.41, flex: 1 }}>{title}</div>
            {dismiss && (
              <div style={{
                width: 30, height: 30, borderRadius: 999, background: t.surface2,
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                color: t.textSec,
              }}><BCIcon name="close" size={16} /></div>
            )}
          </div>
        )}
        <div style={{ padding: '0 18px 18px', overflowY: 'auto', flex: 1 }}>{children}</div>
      </div>
    </>
  );
}

function BCModal({ title, body, actions }) {
  const { t } = useBC();
  return (
    <>
      <div style={{ position: 'absolute', inset: 0, background: t.scrim }} />
      <div style={{
        position: 'absolute', inset: 0,
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        padding: 24,
      }}>
        <div style={{
          width: 270,
          background: t.surface,
          borderRadius: 14,
          overflow: 'hidden',
          boxShadow: '0 18px 50px rgba(0,0,0,0.25)',
        }}>
          <div style={{ padding: '20px 18px 14px', textAlign: 'center' }}>
            {title && <div style={{ fontSize: 17, fontWeight: 700, color: t.text, letterSpacing: -0.41 }}>{title}</div>}
            {body && <div style={{ fontSize: 13, color: t.textSec, marginTop: 6, lineHeight: 1.4 }}>{body}</div>}
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: `repeat(${actions.length}, 1fr)`, borderTop: '0.5px solid ' + t.separator }}>
            {actions.map((a, i) => (
              <React.Fragment key={i}>
                {i > 0 && <div style={{ width: 0.5, background: t.separator }} />}
                <div style={{
                  height: 44, display: 'flex', alignItems: 'center', justifyContent: 'center',
                  fontSize: 17,
                  fontWeight: a.emphasis ? 600 : 400,
                  color: a.destructive ? t.danger : t.primary,
                }}>{a.label}</div>
              </React.Fragment>
            ))}
          </div>
        </div>
      </div>
    </>
  );
}

function BCActionSheet({ items, cancel = 'Cancel' }) {
  const { t } = useBC();
  return (
    <>
      <div style={{ position: 'absolute', inset: 0, background: t.scrim }} />
      <div style={{
        position: 'absolute', left: 10, right: 10, bottom: 10,
        display: 'flex', flexDirection: 'column', gap: 8,
      }}>
        <div style={{ background: t.surface, borderRadius: 14, overflow: 'hidden' }}>
          {items.map((it, i) => (
            <div key={i} style={{
              padding: '15px 16px',
              borderBottom: i < items.length - 1 ? '0.5px solid ' + t.separator : 'none',
              display: 'flex', alignItems: 'center', gap: 12,
              color: it.destructive ? t.danger : t.primary,
              fontSize: 17,
              fontWeight: it.emphasis ? 600 : 500,
              letterSpacing: -0.41,
            }}>
              {it.icon}
              <span style={{ flex: 1 }}>{it.label}</span>
              {it.detail && <span style={{ fontSize: 13, color: t.textTer }}>{it.detail}</span>}
            </div>
          ))}
        </div>
        <div style={{
          background: t.surface, borderRadius: 14,
          padding: '15px 16px', textAlign: 'center',
          color: t.primary, fontSize: 17, fontWeight: 700, letterSpacing: -0.41,
        }}>{cancel}</div>
      </div>
    </>
  );
}

function BCToast({ icon, title, body, tone = 'primary' }) {
  const { t } = useBC();
  const c = tone === 'success' ? t.success : tone === 'danger' ? t.danger : tone === 'teal' ? t.teal : t.primary;
  return (
    <div style={{
      display: 'flex', alignItems: 'center', gap: 12,
      padding: '12px 14px',
      background: t.surface,
      borderRadius: BC_RADIUS.md,
      border: '1px solid ' + t.separator,
      boxShadow: '0 10px 30px rgba(0,0,0,0.10), 0 2px 4px rgba(0,0,0,0.05)',
      minWidth: 260,
    }}>
      <div style={{
        width: 32, height: 32, borderRadius: 999,
        background: c,
        color: '#fff',
        display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0,
      }}>{icon || <BCIcon name="check" size={18} />}</div>
      <div style={{ flex: 1 }}>
        <div style={{ fontSize: 15, fontWeight: 600, color: t.text }}>{title}</div>
        {body && <div style={{ fontSize: 13, color: t.textSec, marginTop: 1 }}>{body}</div>}
      </div>
    </div>
  );
}

function BCBanner({ tone = 'warn', title, body }) {
  const { t } = useBC();
  const palette = {
    warn: [t.warnSoft, t.warn],
    danger: [t.dangerSoft, t.danger],
    primary: [t.primarySoft, t.primary],
    success: [t.successSoft, t.success],
  }[tone];
  return (
    <div style={{
      display: 'flex', gap: 12, padding: 14,
      background: palette[0],
      borderRadius: BC_RADIUS.md,
    }}>
      <div style={{ color: palette[1], flexShrink: 0, paddingTop: 1 }}>
        <BCIcon name={tone === 'success' ? 'check' : tone === 'primary' ? 'info' : 'warning'} size={20} />
      </div>
      <div>
        <div style={{ fontSize: 14, fontWeight: 600, color: t.text }}>{title}</div>
        {body && <div style={{ fontSize: 13, color: t.textSec, marginTop: 2 }}>{body}</div>}
      </div>
    </div>
  );
}

function BCOverlaysGallery({ mode }) {
  const { t } = useBC();
  return (
    <VStack gap={18}>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, auto)', gap: 22, justifyContent: 'start' }}>
        {/* Bottom sheet */}
        <VStack gap={8}>
          <div style={{ fontSize: 11, fontWeight: 600, letterSpacing: 0.6, textTransform: 'uppercase', color: t.textTer }}>Bottom Sheet</div>
          <BCPhoneFrame mode={mode}>
            <BCBottomSheet title="Log meal" dismiss height={320}>
              <VStack gap={10}>
                {[
                  ['Search foods', <BCIcon name="search" size={20} color={t.primary} />],
                  ['Scan barcode', <BCIcon name="barcode" size={20} color={t.primary} />],
                  ['Voice log', <BCIcon name="mic" size={20} color={t.primary} />],
                  ['Quick add calories', <BCIcon name="plus" size={20} color={t.primary} />],
                ].map(([label, icon], i) => (
                  <BCRow key={i}
                    thumb={<div style={{
                      width: 40, height: 40, borderRadius: BC_RADIUS.sm,
                      background: t.primarySoft, display: 'flex', alignItems: 'center', justifyContent: 'center',
                    }}>{icon}</div>}
                    title={label}
                    chev
                    divider={i < 3}
                    style={{ padding: '10px 0' }}
                  />
                ))}
              </VStack>
            </BCBottomSheet>
          </BCPhoneFrame>
        </VStack>

        {/* Modal */}
        <VStack gap={8}>
          <div style={{ fontSize: 11, fontWeight: 600, letterSpacing: 0.6, textTransform: 'uppercase', color: t.textTer }}>Alert / Modal</div>
          <BCPhoneFrame mode={mode}>
            <BCModal
              title="Delete this entry?"
              body="Oatmeal with berries (340 kcal) will be removed from today's log."
              actions={[
                { label: 'Cancel' },
                { label: 'Delete', destructive: true, emphasis: true },
              ]}
            />
          </BCPhoneFrame>
        </VStack>

        {/* Action sheet */}
        <VStack gap={8}>
          <div style={{ fontSize: 11, fontWeight: 600, letterSpacing: 0.6, textTransform: 'uppercase', color: t.textTer }}>Action Sheet</div>
          <BCPhoneFrame mode={mode}>
            <BCActionSheet
              items={[
                { label: 'Edit serving size', emphasis: true },
                { label: 'Move to dinner' },
                { label: 'Save as favorite' },
                { label: 'Delete entry', destructive: true },
              ]}
            />
          </BCPhoneFrame>
        </VStack>
      </div>

      <div style={{ height: 1, background: t.separator }} />

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16 }}>
        <VStack gap={8}>
          <div style={{ fontSize: 11, fontWeight: 600, letterSpacing: 0.6, textTransform: 'uppercase', color: t.textTer }}>Toasts</div>
          <VStack gap={10}>
            <BCToast tone="success" title="Logged · 340 kcal" body="Oatmeal with berries · breakfast" />
            <BCToast tone="danger" icon={<BCIcon name="close" size={18} />} title="Couldn't sync" body="We'll retry when you're online" />
          </VStack>
        </VStack>
        <VStack gap={8}>
          <div style={{ fontSize: 11, fontWeight: 600, letterSpacing: 0.6, textTransform: 'uppercase', color: t.textTer }}>Inline Banners</div>
          <VStack gap={10}>
            <BCBanner tone="warn" title="Carbs over target" body="You're 32g above your daily carb goal" />
            <BCBanner tone="primary" title="Try weekly summaries" body="Get a Sunday recap of your week" />
            <BCBanner tone="success" title="6-day streak" body="Logged every meal this week" />
          </VStack>
        </VStack>
      </div>
    </VStack>
  );
}

Object.assign(window, { BCPhoneFrame, BCBottomSheet, BCModal, BCActionSheet, BCToast, BCBanner, BCOverlaysGallery });
