// ds-primitives.jsx — tiny shared bits used across every artboard

// Section header inside an artboard (component label + caption)
function BCSpec({ label, caption, children, style }) {
  const { t } = useBC();
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 12, ...style }}>
      <div>
        <div style={{
          fontSize: 11, fontWeight: 600, letterSpacing: 0.6,
          textTransform: 'uppercase', color: t.textTer,
        }}>{label}</div>
        {caption && (
          <div style={{ fontSize: 13, color: t.textSec, marginTop: 2 }}>{caption}</div>
        )}
      </div>
      {children}
    </div>
  );
}

// Stack helpers
function VStack({ gap = 12, children, style }) {
  return <div style={{ display: 'flex', flexDirection: 'column', gap, ...style }}>{children}</div>;
}
function HStack({ gap = 12, align = 'center', children, style }) {
  return <div style={{ display: 'flex', flexDirection: 'row', gap, alignItems: align, ...style }}>{children}</div>;
}

// Tiny SF-style symbol set — drawn inline with raw SVG primitives only.
// 24px viewBox. stroke-based so they look right at any size.
function BCIcon({ name, size = 22, color = 'currentColor', strokeWidth = 1.8, style }) {
  const common = {
    width: size, height: size, viewBox: '0 0 24 24',
    fill: 'none', stroke: color, strokeWidth, strokeLinecap: 'round', strokeLinejoin: 'round',
    style,
  };
  switch (name) {
    case 'flame':
      return (<svg {...common}><path d="M12 3.5c1.5 3 4.5 4.5 4.5 8.5a4.5 4.5 0 1 1-9 0c0-1.5.5-2.5 1.5-3.5C9.5 9.5 10 8 10 6.5c0-1 .5-2 2-3z"/><path d="M12 13c.8 1.2 1.6 2 1.6 3.4A1.8 1.8 0 0 1 12 18.2"/></svg>);
    case 'chart':
      return (<svg {...common}><path d="M4 19V5"/><path d="M4 19h16"/><path d="M8 15l3-4 3 2 4-6"/></svg>);
    case 'fork':
      return (<svg {...common}><path d="M7 3v8a2 2 0 0 0 4 0V3"/><path d="M9 11v10"/><path d="M16 3c-1.5 0-2.5 1.5-2.5 4s1 4 2.5 4"/><path d="M16 11v10"/></svg>);
    case 'spark':
      return (<svg {...common}><path d="M12 3v3"/><path d="M12 18v3"/><path d="M3 12h3"/><path d="M18 12h3"/><path d="M5.5 5.5l2 2"/><path d="M16.5 16.5l2 2"/><path d="M5.5 18.5l2-2"/><path d="M16.5 7.5l2-2"/></svg>);
    case 'user':
      return (<svg {...common}><circle cx="12" cy="8" r="3.5"/><path d="M5 20c0-3.5 3.1-6 7-6s7 2.5 7 6"/></svg>);
    case 'plus':
      return (<svg {...common}><path d="M12 5v14"/><path d="M5 12h14"/></svg>);
    case 'check':
      return (<svg {...common}><path d="M4.5 12.5l5 5L20 7"/></svg>);
    case 'close':
      return (<svg {...common}><path d="M6 6l12 12"/><path d="M18 6L6 18"/></svg>);
    case 'chev':
      return (<svg {...common}><path d="M9 6l6 6-6 6"/></svg>);
    case 'caret-down':
      return (<svg {...common}><path d="M6 9l6 6 6-6"/></svg>);
    case 'search':
      return (<svg {...common}><circle cx="11" cy="11" r="6.5"/><path d="M20 20l-4-4"/></svg>);
    case 'barcode':
      return (<svg {...common}><path d="M5 6v12"/><path d="M8 6v12"/><path d="M10.5 6v12"/><path d="M13 6v12"/><path d="M15.5 6v12"/><path d="M19 6v12"/></svg>);
    case 'mic':
      return (<svg {...common}><rect x="9" y="3" width="6" height="11" rx="3"/><path d="M5.5 12a6.5 6.5 0 0 0 13 0"/><path d="M12 18.5V21"/></svg>);
    case 'info':
      return (<svg {...common}><circle cx="12" cy="12" r="8.5"/><path d="M12 11v5"/><circle cx="12" cy="8" r=".6" fill={color} stroke="none"/></svg>);
    case 'warning':
      return (<svg {...common}><path d="M12 3.5L21 19H3z"/><path d="M12 10v4"/><circle cx="12" cy="16.5" r=".6" fill={color} stroke="none"/></svg>);
    default:
      return null;
  }
}

Object.assign(window, { BCSpec, VStack, HStack, BCIcon });
