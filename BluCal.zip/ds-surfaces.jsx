// ds-surfaces.jsx — Cards, list rows, badges, macro ring

function BCCard({ padding = 16, radius = BC_RADIUS.lg, children, style, onSurface = 'surface' }) {
  const { t } = useBC();
  return (
    <div style={{
      background: onSurface === 'surface2' ? t.surface2 : t.surface,
      borderRadius: radius,
      padding,
      border: '1px solid ' + t.separator,
      ...style,
    }}>{children}</div>
  );
}

function BCBadge({ tone = 'neutral', children, size = 'md', dot, style }) {
  const { t } = useBC();
  const palette = {
    neutral: [t.surface2, t.textSec],
    primary: [t.primarySoft, t.primary],
    teal:    [t.tealSoft, t.teal],
    danger:  [t.dangerSoft, t.danger],
    warn:    [t.warnSoft, t.warn],
    success: [t.successSoft, t.success],
    solid:   [t.primary, t.textOnPrim],
  }[tone] || [t.surface2, t.textSec];
  const fs = size === 'sm' ? 11 : 12;
  const py = size === 'sm' ? 3 : 4;
  const px = size === 'sm' ? 8 : 10;
  return (
    <span style={{
      display: 'inline-flex', alignItems: 'center', gap: 6,
      padding: `${py}px ${px}px`,
      background: palette[0], color: palette[1],
      fontSize: fs, fontWeight: 600, letterSpacing: 0.1,
      borderRadius: 999,
      ...style,
    }}>
      {dot && <span style={{ width: 6, height: 6, borderRadius: 999, background: palette[1] }} />}
      {children}
    </span>
  );
}

// Macro ring — Apple-Activity-style stacked rings
function BCMacroRing({ size = 96, stroke = 10, values = { c: 0.62, p: 0.48, f: 0.78 }, showCenter = true, kcal = 1420, target = 2100 }) {
  const { t } = useBC();
  const cx = size / 2, cy = size / 2;
  const radii = [
    cx - stroke / 2 - 2,
    cx - stroke - stroke / 2 - 4,
    cx - stroke * 2 - stroke / 2 - 6,
  ];
  const tracks = ['carbs', 'protein', 'fat'];
  const colors = [t.carbs, t.protein, t.fat];
  const keys = ['c','p','f'];
  return (
    <div style={{ position: 'relative', width: size, height: size }}>
      <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`}>
        {radii.map((r, i) => {
          const C = 2 * Math.PI * r;
          const v = Math.min(1, values[keys[i]]);
          return (
            <g key={i} transform={`rotate(-90 ${cx} ${cy})`}>
              <circle cx={cx} cy={cy} r={r} stroke={colors[i]} strokeOpacity={0.18} strokeWidth={stroke} fill="none" />
              <circle cx={cx} cy={cy} r={r} stroke={colors[i]} strokeWidth={stroke} fill="none"
                strokeDasharray={C} strokeDashoffset={C * (1 - v)} strokeLinecap="round" />
            </g>
          );
        })}
      </svg>
      {showCenter && (
        <div style={{
          position: 'absolute', inset: 0,
          display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center',
        }}>
          <div style={{ fontSize: size >= 130 ? 28 : 20, fontWeight: 700, color: t.text, letterSpacing: -0.5, lineHeight: 1 }}>{kcal.toLocaleString()}</div>
          <div style={{ fontSize: 10, color: t.textSec, marginTop: 2, fontWeight: 500 }}>/ {target.toLocaleString()} kcal</div>
        </div>
      )}
    </div>
  );
}

// List row — iOS-style with leading thumb, title/subtitle, trailing value & chev
function BCRow({ thumb, title, sub, value, valueSub, chev, accessory, divider = true, style }) {
  const { t } = useBC();
  return (
    <div style={{
      display: 'flex', alignItems: 'center', gap: 12,
      padding: '12px 16px',
      borderBottom: divider ? '1px solid ' + t.separator : 'none',
      background: 'transparent',
      ...style,
    }}>
      {thumb}
      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{ fontSize: 17, fontWeight: 500, color: t.text, letterSpacing: -0.41, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{title}</div>
        {sub && <div style={{ fontSize: 13, color: t.textSec, marginTop: 2, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{sub}</div>}
      </div>
      {accessory}
      {(value || valueSub) && (
        <div style={{ textAlign: 'right' }}>
          {value && <div style={{ fontSize: 17, fontWeight: 600, color: t.text, letterSpacing: -0.41 }}>{value}</div>}
          {valueSub && <div style={{ fontSize: 12, color: t.textSec, marginTop: 1 }}>{valueSub}</div>}
        </div>
      )}
      {chev && <BCIcon name="chev" size={16} color={t.textTer} />}
    </div>
  );
}

// Thumb component — color-tinted square with an icon/letter
function BCThumb({ color, icon, letter, size = 40 }) {
  const { t } = useBC();
  const bg = color || t.primarySoft;
  const fg = color ? '#fff' : t.primary;
  return (
    <div style={{
      width: size, height: size, borderRadius: BC_RADIUS.sm,
      background: bg, color: fg,
      display: 'flex', alignItems: 'center', justifyContent: 'center',
      fontWeight: 700, fontSize: 14, flexShrink: 0,
    }}>{icon || letter}</div>
  );
}

function BCSurfacesGallery() {
  const { t } = useBC();
  const Row = ({ label, children }) => (
    <div style={{ display: 'grid', gridTemplateColumns: '90px 1fr', gap: 16, alignItems: 'start' }}>
      <div style={{ fontSize: 11, fontWeight: 600, letterSpacing: 0.6, textTransform: 'uppercase', color: t.textTer, paddingTop: 6 }}>{label}</div>
      <div>{children}</div>
    </div>
  );
  return (
    <VStack gap={18}>
      <Row label="Cards">
        <VStack gap={12}>
          <BCCard>
            <HStack gap={14}>
              <BCMacroRing size={80} stroke={9} kcal={1420} target={2100} />
              <VStack gap={6} style={{ flex: 1 }}>
                <div style={{ fontSize: 13, color: t.textSec, fontWeight: 600 }}>TODAY</div>
                <div style={{ fontSize: 22, fontWeight: 700, color: t.text, letterSpacing: -0.4 }}>680 kcal left</div>
                <HStack gap={6} style={{ flexWrap: 'wrap' }}>
                  <BCBadge tone="warn" size="sm" dot>Carbs 62%</BCBadge>
                  <BCBadge tone="primary" size="sm" dot>Protein 48%</BCBadge>
                  <BCBadge tone="teal" size="sm" dot>Fat 78%</BCBadge>
                </HStack>
              </VStack>
            </HStack>
          </BCCard>

          <BCCard onSurface="surface2" padding={14}>
            <HStack gap={12}>
              <div style={{
                width: 36, height: 36, borderRadius: 999,
                background: t.primarySoft, color: t.primary,
                display: 'flex', alignItems: 'center', justifyContent: 'center',
              }}><BCIcon name="info" size={20} /></div>
              <div style={{ flex: 1 }}>
                <div style={{ fontSize: 15, fontWeight: 600, color: t.text }}>You're 12g under on protein</div>
                <div style={{ fontSize: 13, color: t.textSec, marginTop: 2 }}>Try adding a scoop of yogurt or cottage cheese</div>
              </div>
            </HStack>
          </BCCard>
        </VStack>
      </Row>

      <Row label="Badges">
        <HStack gap={8} style={{ flexWrap: 'wrap' }}>
          <BCBadge tone="neutral">Default</BCBadge>
          <BCBadge tone="primary">Logged</BCBadge>
          <BCBadge tone="teal">Healthy</BCBadge>
          <BCBadge tone="success" dot>On track</BCBadge>
          <BCBadge tone="warn" dot>Over carbs</BCBadge>
          <BCBadge tone="danger">Missed</BCBadge>
          <BCBadge tone="solid">Pro</BCBadge>
          <BCBadge tone="primary" size="sm">sm</BCBadge>
        </HStack>
      </Row>

      <Row label="List Rows">
        <BCCard padding={0} style={{ overflow: 'hidden' }}>
          <BCRow
            thumb={<BCThumb color={t.warn} letter="🥣" />}
            title="Oatmeal with berries"
            sub="1 cup · Breakfast · 7:42 AM"
            value="340"
            valueSub="kcal"
            chev
          />
          <BCRow
            thumb={<BCThumb color={t.protein} letter="🥚" />}
            title="Eggs, scrambled"
            sub="2 large · Breakfast"
            value="180"
            valueSub="kcal"
            chev
          />
          <BCRow
            thumb={<BCThumb color={t.teal} letter="🥗" />}
            title="Quinoa bowl, chicken"
            sub="1 bowl · Lunch · 12:15 PM"
            value="540"
            valueSub="kcal"
            chev
            divider={false}
          />
        </BCCard>
      </Row>

      <Row label="Macro Ring">
        <HStack gap={20}>
          <BCMacroRing size={140} stroke={14} values={{ c: 0.62, p: 0.48, f: 0.78 }} kcal={1420} target={2100} />
          <VStack gap={10}>
            {[
              ['Carbs', t.carbs, '186 / 260g', 0.72],
              ['Protein', t.protein, '78 / 140g', 0.56],
              ['Fat', t.fat, '52 / 70g', 0.74],
            ].map(([name, c, val, p]) => (
              <VStack key={name} gap={4} style={{ width: 180 }}>
                <HStack gap={8}>
                  <span style={{ width: 8, height: 8, borderRadius: 999, background: c }} />
                  <span style={{ fontSize: 13, fontWeight: 600, color: t.text }}>{name}</span>
                  <span style={{ marginLeft: 'auto', fontSize: 12, color: t.textSec, fontFamily: 'ui-monospace, Menlo, monospace' }}>{val}</span>
                </HStack>
                <div style={{ height: 6, background: t.surface2, borderRadius: 6, overflow: 'hidden' }}>
                  <div style={{ height: '100%', width: (p * 100) + '%', background: c, borderRadius: 6 }} />
                </div>
              </VStack>
            ))}
          </VStack>
        </HStack>
      </Row>
    </VStack>
  );
}

Object.assign(window, { BCCard, BCBadge, BCMacroRing, BCRow, BCThumb, BCSurfacesGallery });
