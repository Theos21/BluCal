// ds-tabbar.jsx — Bottom tab bar + nav bar + nav specs

function BCTabBar({ active = 0, withFab = false }) {
  const { t } = useBC();
  const tabs = [
    { name: 'Today',  icon: 'flame' },
    { name: 'Trends', icon: 'chart' },
    { name: 'Meals',  icon: 'fork' },
    { name: 'Coach',  icon: 'spark' },
    { name: 'Profile',icon: 'user' },
  ];
  return (
    <div style={{
      position: 'relative',
      background: t.surface,
      borderTop: '0.5px solid ' + t.separator,
      paddingTop: 8, paddingBottom: 22,
      display: 'flex', alignItems: 'flex-end',
    }}>
      {tabs.map((tb, i) => {
        const isActive = i === active;
        const c = isActive ? t.primary : t.textTer;
        const inactiveTabColor = '#8E8E93';
        return (
          <div key={tb.name} style={{
            flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 3,
          }}>
            {tb.name === 'Today' ? (
              <BluCalMark size={26} color={isActive ? t.primary : inactiveTabColor} />
            ) : (
              <BCIcon name={tb.icon} size={26} color={c} strokeWidth={isActive ? 2.2 : 1.8} />
            )}
            <div style={{ fontSize: 10, fontWeight: 600, color: c, letterSpacing: 0.1 }}>{tb.name}</div>
          </div>
        );
      })}
      {withFab && (
        <div style={{
          position: 'absolute', left: '50%', top: -22, transform: 'translateX(-50%)',
        }}>
          <BCFab tone="primary" size={56} icon={<BCIcon name="plus" size={28} color="#fff" />} label="Add" />
        </div>
      )}
    </div>
  );
}

function BCNavBar({ title, large, leading = 'back', trailing }) {
  const { t } = useBC();
  return (
    <div style={{ background: t.bg }}>
      <div style={{
        height: 44, padding: '0 12px',
        display: 'flex', alignItems: 'center', gap: 8,
      }}>
        <div style={{ flex: 1, display: 'flex', alignItems: 'center', minWidth: 0 }}>
          {leading === 'back' && (
            <HStack gap={4}>
              <BCIcon name="chev" size={20} color={t.primary} style={{ transform: 'scaleX(-1)' }} />
              <span style={{ fontSize: 17, color: t.primary, letterSpacing: -0.41 }}>Back</span>
            </HStack>
          )}
          {leading === 'close' && <BCIcon name="close" size={22} color={t.primary} />}
        </div>
        {!large && <div style={{ fontSize: 17, fontWeight: 600, color: t.text, letterSpacing: -0.41 }}>{title}</div>}
        <div style={{ flex: 1, display: 'flex', justifyContent: 'flex-end', minWidth: 0 }}>
          {trailing}
        </div>
      </div>
      {large && (
        <div style={{ padding: '4px 16px 8px' }}>
          <BCType scale="largeTitle">{title}</BCType>
        </div>
      )}
    </div>
  );
}

function BCTabBarGallery({ mode }) {
  const { t } = useBC();
  return (
    <VStack gap={18}>
      <div>
        <div style={{ fontSize: 11, fontWeight: 600, letterSpacing: 0.6, textTransform: 'uppercase', color: t.textTer, marginBottom: 10 }}>Bottom Tab Bar — all states</div>
        <VStack gap={14}>
          {[0,1,2,3,4].map(i => (
            <div key={i} style={{
              width: '100%', borderRadius: BC_RADIUS.md, overflow: 'hidden',
              border: '1px solid ' + t.separator,
            }}>
              <BCTabBar active={i} />
            </div>
          ))}
        </VStack>
      </div>
      <div>
        <div style={{ fontSize: 11, fontWeight: 600, letterSpacing: 0.6, textTransform: 'uppercase', color: t.textTer, marginBottom: 10 }}>With center "Log" FAB (alt)</div>
        <div style={{ width: '100%', borderRadius: BC_RADIUS.md, overflow: 'hidden', border: '1px solid ' + t.separator, paddingTop: 22 }}>
          <BCTabBar active={0} withFab />
        </div>
      </div>
      <div>
        <div style={{ fontSize: 11, fontWeight: 600, letterSpacing: 0.6, textTransform: 'uppercase', color: t.textTer, marginBottom: 10 }}>Nav Bars</div>
        <VStack gap={14}>
          <div style={{ border: '1px solid ' + t.separator, borderRadius: BC_RADIUS.md, overflow: 'hidden' }}>
            <BCNavBar title="Today" large trailing={<BCIcon name="user" size={22} color={t.primary} />} />
          </div>
          <div style={{ border: '1px solid ' + t.separator, borderRadius: BC_RADIUS.md, overflow: 'hidden' }}>
            <BCNavBar title="Edit entry" trailing={<span style={{ fontSize: 17, fontWeight: 600, color: t.primary }}>Save</span>} />
          </div>
          <div style={{ border: '1px solid ' + t.separator, borderRadius: BC_RADIUS.md, overflow: 'hidden' }}>
            <BCNavBar title="Add food" leading="close" trailing={<span style={{ fontSize: 17, color: t.primary }}>Done</span>} />
          </div>
        </VStack>
      </div>
    </VStack>
  );
}

Object.assign(window, { BCTabBar, BCNavBar, BCTabBarGallery });
