// ds-tokens.jsx — single source of truth for BluCal tokens (light + dark)

const BC_LIGHT = {
  mode: 'light',
  // surfaces
  bg:        '#F4F4F6',
  surface:   '#FFFFFF',
  surface2:  '#EEEEF1',  // recessed / grouped
  surface3:  '#E5E5E9',  // pressed states for surface2
  separator: 'rgba(60,60,67,0.14)',
  hairline:  'rgba(60,60,67,0.22)',
  scrim:     'rgba(0,0,0,0.36)',

  // text
  text:        '#0B0B0F',
  textSec:     '#5C5C63',
  textTer:     '#9A9AA0',
  textOnPrim:  '#FFFFFF',

  // brand
  primary:        '#185FA5',
  primaryPress:   '#134B82',
  primarySoft:    'rgba(24,95,165,0.10)',
  primarySoftHi:  'rgba(24,95,165,0.18)',

  // secondary accent (teal)
  teal:        '#0F6E56',
  tealPress:   '#0B5644',
  tealSoft:    'rgba(15,110,86,0.10)',

  // semantic
  danger:      '#D8362F',
  dangerPress: '#B22822',
  dangerSoft:  'rgba(216,54,47,0.10)',
  warn:        '#C8801C',
  warnSoft:    'rgba(200,128,28,0.14)',
  success:     '#1F8E54',
  successSoft: 'rgba(31,142,84,0.12)',

  // macro pills (consistent across modes; teal/blue + warm neutrals so we don't crowd brand)
  carbs:   '#C8801C',  // amber
  protein: '#185FA5',  // brand blue
  fat:     '#0F6E56',  // teal
};

const BC_DARK = {
  mode: 'dark',
  // Lifted grey palette — not pure black; subtle cool undertone for a
  // MacroFactor-like calm dark mode while keeping clear surface layering.
  bg:        '#18191D',
  surface:   '#23262B',
  surface2:  '#2D3035',
  surface3:  '#383B42',
  separator: 'rgba(170,175,185,0.16)',
  hairline:  'rgba(170,175,185,0.24)',
  scrim:     'rgba(0,0,0,0.58)',

  text:        '#F2F3F5',
  textSec:     '#A2A6AE',
  textTer:     '#6E727A',
  textOnPrim:  '#FFFFFF',

  // brand lifted ~2 steps lighter for AA on the cool navy bg
  primary:        '#4F95DC',
  primaryPress:   '#6FAAE5',
  primarySoft:    'rgba(79,149,220,0.18)',
  primarySoftHi:  'rgba(79,149,220,0.28)',

  teal:        '#3DB593',
  tealPress:   '#5AC4A6',
  tealSoft:    'rgba(61,181,147,0.18)',

  danger:      '#FF6058',
  dangerPress: '#FF8A84',
  dangerSoft:  'rgba(255,96,88,0.18)',
  warn:        '#F0A040',
  warnSoft:    'rgba(240,160,64,0.18)',
  success:     '#3DC57A',
  successSoft: 'rgba(61,197,122,0.18)',

  carbs:   '#F0A040',
  protein: '#4F95DC',
  fat:     '#3DB593',
};

// Type scale — Apple HIG-ish, named so it reads like SF
const BC_TYPE = {
  largeTitle: { size: 34, line: 41, weight: 700, tracking: 0.37 },
  title1:     { size: 28, line: 34, weight: 700, tracking: 0.36 },
  title2:     { size: 22, line: 28, weight: 700, tracking: 0.35 },
  title3:     { size: 20, line: 25, weight: 600, tracking: 0.38 },
  headline:   { size: 17, line: 22, weight: 600, tracking: -0.41 },
  body:       { size: 17, line: 22, weight: 400, tracking: -0.41 },
  bodyEm:     { size: 17, line: 22, weight: 600, tracking: -0.41 },
  callout:    { size: 16, line: 21, weight: 400, tracking: -0.32 },
  subhead:    { size: 15, line: 20, weight: 400, tracking: -0.24 },
  subheadEm:  { size: 15, line: 20, weight: 600, tracking: -0.24 },
  footnote:   { size: 13, line: 18, weight: 400, tracking: -0.08 },
  caption1:   { size: 12, line: 16, weight: 400, tracking: 0 },
  caption2:   { size: 11, line: 13, weight: 500, tracking: 0.07 },
};

// Spacing scale — multiples of 4
const BC_SPACE = { xxs: 2, xs: 4, sm: 8, md: 12, lg: 16, xl: 20, xxl: 24, xxxl: 32 };

// Radius scale
const BC_RADIUS = { xs: 6, sm: 8, md: 12, lg: 16, xl: 22, pill: 999 };

const SF_STACK = '-apple-system, BlinkMacSystemFont, "SF Pro Text", "SF Pro", "Helvetica Neue", system-ui, sans-serif';

// Theme context — every artboard wraps children in <BCTheme mode>; primitives
// read tokens via useBC(). Pass `surfaceBg` override when the artboard's frame
// background should differ from the canonical bg (e.g. component artboards
// that sit on a plain surface to keep the focus on the component).
const BCContext = React.createContext({ t: BC_LIGHT, mode: 'light' });
const useBC = () => React.useContext(BCContext);

function BCTheme({ mode = 'light', bg, padding = 20, children, style }) {
  const t = mode === 'dark' ? BC_DARK : BC_LIGHT;
  return (
    <BCContext.Provider value={{ t, mode }}>
      <div style={{
        background: bg || t.bg,
        color: t.text,
        fontFamily: SF_STACK,
        WebkitFontSmoothing: 'antialiased',
        MozOsxFontSmoothing: 'grayscale',
        padding,
        width: '100%',
        height: '100%',
        boxSizing: 'border-box',
        ...style,
      }}>{children}</div>
    </BCContext.Provider>
  );
}

// Type helper — pass scale name + optional weight/color override.
function BCType({ scale = 'body', as = 'div', weight, color, children, style }) {
  const { t } = useBC();
  const s = BC_TYPE[scale];
  const El = as;
  return (
    <El style={{
      fontSize: s.size,
      lineHeight: s.line + 'px',
      fontWeight: weight ?? s.weight,
      letterSpacing: s.tracking + 'px',
      color: color || t.text,
      margin: 0,
      ...style,
    }}>{children}</El>
  );
}

Object.assign(window, { BC_LIGHT, BC_DARK, BC_TYPE, BC_SPACE, BC_RADIUS, SF_STACK, BCContext, useBC, BCTheme, BCType });
