// ds-typography.jsx — Colors and Type artboards

function BCColorPalette() {
  const { t } = useBC();
  const groups = [
    { title: 'Surfaces', items: [
      ['Background', t.bg], ['Surface', t.surface], ['Surface 2', t.surface2], ['Surface 3', t.surface3],
    ]},
    { title: 'Text', items: [
      ['Primary', t.text], ['Secondary', t.textSec], ['Tertiary', t.textTer], ['On Brand', t.textOnPrim],
    ]},
    { title: 'Brand', items: [
      ['Primary', t.primary], ['Pressed', t.primaryPress], ['Soft', t.primarySoft, 'fill'],
      ['Teal', t.teal], ['Teal Pressed', t.tealPress], ['Teal Soft', t.tealSoft, 'fill'],
    ]},
    { title: 'Semantic', items: [
      ['Danger', t.danger], ['Danger Soft', t.dangerSoft, 'fill'],
      ['Warn', t.warn], ['Warn Soft', t.warnSoft, 'fill'],
      ['Success', t.success], ['Success Soft', t.successSoft, 'fill'],
    ]},
    { title: 'Macro Pills', items: [
      ['Carbs', t.carbs], ['Protein', t.protein], ['Fat', t.fat],
    ]},
  ];

  return (
    <VStack gap={20}>
      {groups.map(g => (
        <div key={g.title}>
          <div style={{ fontSize: 11, fontWeight: 600, letterSpacing: 0.6, textTransform: 'uppercase', color: t.textTer, marginBottom: 10 }}>{g.title}</div>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 10 }}>
            {g.items.map(([name, c, kind], i) => (
              <div key={i} style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
                <div style={{
                  height: 56, borderRadius: BC_RADIUS.md, background: c,
                  border: '1px solid ' + t.separator,
                }} />
                <div style={{ fontSize: 11, fontWeight: 600, color: t.text, lineHeight: '14px' }}>{name}</div>
                <div style={{ fontSize: 10, color: t.textSec, fontFamily: 'ui-monospace, SFMono-Regular, Menlo, monospace' }}>
                  {typeof c === 'string' && c.startsWith('#') ? c.toUpperCase() : 'token'}
                </div>
              </div>
            ))}
          </div>
        </div>
      ))}
    </VStack>
  );
}

function BCTypeScale() {
  const { t } = useBC();
  const rows = [
    ['largeTitle', 'Large Title', 'Aa'],
    ['title1',     'Title 1',     'Aa'],
    ['title2',     'Title 2',     'Aa'],
    ['title3',     'Title 3',     'Aa'],
    ['headline',   'Headline',    'Aa'],
    ['body',       'Body',        'The quick brown fox'],
    ['callout',    'Callout',     'The quick brown fox'],
    ['subhead',    'Subhead',     'The quick brown fox'],
    ['footnote',   'Footnote',    'The quick brown fox'],
    ['caption1',   'Caption 1',   'The quick brown fox'],
    ['caption2',   'Caption 2',   'THE QUICK BROWN FOX'],
  ];
  return (
    <VStack gap={0}>
      {rows.map(([scale, name, sample], i) => {
        const s = BC_TYPE[scale];
        return (
          <div key={scale} style={{
            display: 'grid',
            gridTemplateColumns: '110px 1fr 80px',
            alignItems: 'baseline',
            gap: 16,
            padding: '14px 0',
            borderBottom: i < rows.length - 1 ? '1px solid ' + t.separator : 'none',
          }}>
            <div>
              <div style={{ fontSize: 13, fontWeight: 600, color: t.text }}>{name}</div>
              <div style={{ fontSize: 11, color: t.textTer, fontFamily: 'ui-monospace, SFMono-Regular, Menlo, monospace', marginTop: 2 }}>
                {s.size}/{s.line} · {s.weight}
              </div>
            </div>
            <BCType scale={scale}>{sample}</BCType>
            <div style={{ fontSize: 11, color: t.textTer, fontFamily: 'ui-monospace, SFMono-Regular, Menlo, monospace', textAlign: 'right' }}>
              {s.tracking >= 0 ? '+' : ''}{s.tracking.toFixed(2)}
            </div>
          </div>
        );
      })}
    </VStack>
  );
}

function BCSpacingScale() {
  const { t } = useBC();
  const items = Object.entries(BC_SPACE);
  return (
    <VStack gap={14}>
      <div style={{ fontSize: 13, color: t.textSec }}>4px base grid. Use space tokens for padding, gaps, and inset values.</div>
      <VStack gap={8}>
        {items.map(([k, v]) => (
          <HStack key={k} gap={14}>
            <div style={{ width: 48, fontSize: 12, fontWeight: 600, color: t.text, fontFamily: 'ui-monospace, SFMono-Regular, Menlo, monospace' }}>{k}</div>
            <div style={{ width: 40, fontSize: 11, color: t.textSec, fontFamily: 'ui-monospace, SFMono-Regular, Menlo, monospace' }}>{v}px</div>
            <div style={{ height: 14, width: v * 4, background: t.primary, borderRadius: 2 }} />
          </HStack>
        ))}
      </VStack>

      <div style={{ height: 1, background: t.separator, margin: '6px 0' }} />

      <div style={{ fontSize: 11, fontWeight: 600, letterSpacing: 0.6, textTransform: 'uppercase', color: t.textTer }}>Radius</div>
      <HStack gap={14}>
        {Object.entries(BC_RADIUS).map(([k, v]) => (
          <VStack key={k} gap={6}>
            <div style={{
              width: 56, height: 56, background: t.surface,
              borderRadius: Math.min(v, 28), border: '1px solid ' + t.separator,
            }} />
            <div style={{ fontSize: 11, fontWeight: 600, color: t.text, fontFamily: 'ui-monospace, SFMono-Regular, Menlo, monospace' }}>{k}</div>
            <div style={{ fontSize: 10, color: t.textSec, fontFamily: 'ui-monospace, SFMono-Regular, Menlo, monospace', marginTop: -4 }}>{v === 999 ? '∞' : v + 'px'}</div>
          </VStack>
        ))}
      </HStack>
    </VStack>
  );
}

Object.assign(window, { BCColorPalette, BCTypeScale, BCSpacingScale });
