// edit-macros-screen.jsx — Edit macro targets (Recommended / Custom)

function EMStatusBar({ mode }) {
  const c = mode === 'dark' ? '#fff' : '#000';
  return (
    <div style={{
      height: 54, padding: '14px 28px 0',
      display: 'flex', alignItems: 'center', justifyContent: 'space-between',
      fontSize: 17, fontWeight: 600, letterSpacing: -0.41, color: c, fontFamily: SF_STACK,
    }}>
      <span style={{ fontVariantNumeric: 'tabular-nums' }}>9:41</span>
      <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
        <svg width="18" height="11" viewBox="0 0 18 11">
          <rect x="0" y="7" width="3" height="4" rx="0.6" fill={c}/>
          <rect x="5" y="5" width="3" height="6" rx="0.6" fill={c}/>
          <rect x="10" y="3" width="3" height="8" rx="0.6" fill={c}/>
          <rect x="15" y="0" width="3" height="11" rx="0.6" fill={c}/>
        </svg>
        <svg width="26" height="12" viewBox="0 0 26 12">
          <rect x="0.5" y="0.5" width="22" height="11" rx="3" stroke={c} strokeOpacity="0.4" fill="none"/>
          <rect x="2" y="2" width="19" height="8" rx="1.5" fill={c}/>
          <rect x="23.5" y="4" width="1.5" height="4" rx="0.7" fill={c} fillOpacity="0.4"/>
        </svg>
      </div>
    </div>
  );
}

function EMNavBar({ mode, dirty, onCancel, onSave }) {
  const t = mode === 'dark' ? BC_DARK : BC_LIGHT;
  return (
    <div style={{
      height: 52, padding: '0 16px',
      display: 'flex', alignItems: 'center',
      borderBottom: '0.5px solid ' + t.separator, background: t.bg, position: 'relative',
    }}>
      <button onClick={onCancel} style={{
        height: 32, padding: '0 4px', border: 'none', background: 'transparent',
        color: t.primary, fontSize: 17, letterSpacing: -0.41, fontFamily: SF_STACK, cursor: 'pointer',
      }}>Cancel</button>
      <div style={{
        position: 'absolute', inset: 0, display: 'flex', alignItems: 'center', justifyContent: 'center',
        pointerEvents: 'none', fontSize: 17, fontWeight: 600, color: t.text, lineHeight: '22px',
      }}>Macro targets</div>
      <div style={{ flex: 1 }} />
      <button onClick={onSave} style={{
        height: 32, padding: '0 4px', border: 'none', background: 'transparent',
        color: dirty ? t.primary : t.textTer,
        fontSize: 17, fontWeight: 700, letterSpacing: -0.41,
        fontFamily: SF_STACK, cursor: dirty ? 'pointer' : 'not-allowed',
      }}>Save</button>
    </div>
  );
}

// ─── Live donut ──────────────────────────────────────────────────────
function MacroDonutLive({ mode, p, c, f, kcal, size = 130 }) {
  const t = mode === 'dark' ? BC_DARK : BC_LIGHT;
  const stroke = 22, r = (size - stroke) / 2;
  const C = 2 * Math.PI * r;
  const total = (p * 4) + (c * 4) + (f * 9);
  const pPct = total > 0 ? (p * 4) / total : 0;
  const cPct = total > 0 ? (c * 4) / total : 0;
  const fPct = total > 0 ? (f * 9) / total : 0;

  let start = 0;
  const seg = (frac, color, key) => {
    const len = C * frac;
    const out = (
      <circle key={key} cx={size / 2} cy={size / 2} r={r}
        stroke={color} strokeWidth={stroke} fill="none"
        strokeDasharray={`${len} ${C - len}`}
        strokeDashoffset={-C * start}
        transform={`rotate(-90 ${size / 2} ${size / 2})`}
        style={{ transition: 'stroke-dasharray .25s, stroke-dashoffset .25s' }}
      />
    );
    start += frac;
    return out;
  };

  return (
    <div style={{ position: 'relative', width: size, height: size, flexShrink: 0 }}>
      <svg width={size} height={size}>
        <circle cx={size / 2} cy={size / 2} r={r} stroke={t.surface2} strokeWidth={stroke} fill="none" />
        {seg(pPct, t.protein, 'p')}
        {seg(cPct, t.carbs,   'c')}
        {seg(fPct, t.fat,     'f')}
      </svg>
      <div style={{
        position: 'absolute', inset: 0, display: 'flex', flexDirection: 'column',
        alignItems: 'center', justifyContent: 'center',
      }}>
        <div style={{
          fontSize: Math.max(13, Math.round(size * 0.17)),
          fontWeight: 800, color: t.text, letterSpacing: -0.4,
          fontVariantNumeric: 'tabular-nums', lineHeight: 1,
        }}>
          {kcal.toLocaleString()}
        </div>
        <div style={{
          fontSize: Math.max(8, Math.round(size * 0.075)),
          fontWeight: 700, color: t.textTer,
          letterSpacing: 0.4, textTransform: 'uppercase',
          marginTop: 3,
        }}>
          kcal
        </div>
      </div>
    </div>
  );
}

// ─── Recommended panel ───────────────────────────────────────────────
function RecommendedPanel({ mode }) {
  const t = mode === 'dark' ? BC_DARK : BC_LIGHT;
  const REC = { kcal: 1830, p: 150, c: 172, f: 60 };
  return (
    <div>
      <div style={{
        background: t.surface, border: '1px solid ' + t.separator, borderRadius: BC_RADIUS.lg,
        padding: '16px',
      }}>
        <div style={{ display: 'flex', gap: 16, alignItems: 'center' }}>
          <MacroDonutLive mode={mode} {...REC} size={130} />
          <div style={{ flex: 1, minWidth: 0 }}>
            <div style={{ fontSize: 11, fontWeight: 700, color: t.textTer, letterSpacing: 0.6, textTransform: 'uppercase' }}>
              Daily target
            </div>
            <div style={{ fontSize: 32, fontWeight: 800, color: t.text, letterSpacing: -0.6, lineHeight: 1, fontVariantNumeric: 'tabular-nums', marginTop: 4 }}>
              {REC.kcal.toLocaleString()}
              <span style={{ fontSize: 13, color: t.textSec, fontWeight: 600, marginLeft: 4 }}>kcal</span>
            </div>
            <div style={{ marginTop: 10, display: 'flex', flexDirection: 'column', gap: 6 }}>
              {[
                ['Protein', t.protein, REC.p, Math.round((REC.p * 4 / REC.kcal) * 100)],
                ['Carbs',   t.carbs,   REC.c, Math.round((REC.c * 4 / REC.kcal) * 100)],
                ['Fat',     t.fat,     REC.f, Math.round((REC.f * 9 / REC.kcal) * 100)],
              ].map(([name, color, g, pct]) => (
                <div key={name} style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                  <span style={{ width: 8, height: 8, borderRadius: 999, background: color }} />
                  <span style={{ fontSize: 13, fontWeight: 700, color: t.text }}>{name}</span>
                  <span style={{ marginLeft: 'auto', fontSize: 13, fontWeight: 700, color: t.text, fontVariantNumeric: 'tabular-nums' }}>{g}g</span>
                  <span style={{ fontSize: 11, color: t.textTer, fontWeight: 600, width: 32, textAlign: 'right' }}>{pct}%</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Explanation card */}
      <div style={{
        marginTop: 12, padding: '14px 16px',
        background: t.primarySoft, borderRadius: BC_RADIUS.lg,
        display: 'flex', gap: 12, alignItems: 'flex-start',
      }}>
        <div style={{
          width: 32, height: 32, borderRadius: 8, flexShrink: 0,
          background: t.primary, color: '#fff',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
        }}>
          <BCIcon name="spark" size={18} color="#fff" />
        </div>
        <div>
          <div style={{ fontSize: 14, fontWeight: 700, color: t.text, letterSpacing: -0.2 }}>How we set this</div>
          <div style={{ fontSize: 13, color: t.textSec, marginTop: 4, lineHeight: '19px' }}>
            From your goal (<b style={{ color: t.text }}>lose fat</b>), stats (<b style={{ color: t.text }}>5′7″ · 178 lbs · 32</b>), and activity
            (<b style={{ color: t.text }}>moderately active</b>), we estimate <b style={{ color: t.text }}>~2,330 kcal/day</b> of maintenance and apply a <b style={{ color: t.text }}>500 kcal deficit</b>. Protein scales with goal weight; fat covers hormones; carbs fill the rest.
          </div>
        </div>
      </div>

      {/* What changes the targets */}
      <div style={{
        marginTop: 12, padding: '14px 16px',
        background: t.surface, border: '1px solid ' + t.separator, borderRadius: BC_RADIUS.lg,
      }}>
        <div style={{ fontSize: 11, fontWeight: 700, color: t.textTer, letterSpacing: 0.6, textTransform: 'uppercase' }}>
          Coach tunes these as you go
        </div>
        <div style={{ marginTop: 10, display: 'flex', flexDirection: 'column', gap: 8 }}>
          {[
            'If your weight stalls 2+ weeks, kcal nudges down ~80',
            'If energy/hunger ratings tank, kcal nudges up',
            'Protein recalculates when your weight changes',
          ].map((s, i) => (
            <div key={i} style={{ display: 'flex', gap: 8, alignItems: 'flex-start' }}>
              <span style={{ width: 5, height: 5, borderRadius: 999, background: t.primary, marginTop: 8, flexShrink: 0 }} />
              <span style={{ fontSize: 13, color: t.text, lineHeight: '18px' }}>{s}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

// ─── Custom panel (live, editable) ───────────────────────────────────
function CustomPanel({ mode }) {
  const t = mode === 'dark' ? BC_DARK : BC_LIGHT;
  const [kcal, setKcal] = React.useState(2000);
  const [p, setP] = React.useState(170);
  const [c, setC] = React.useState(190);
  const [f, setF] = React.useState(65);
  const [netCarbs, setNetCarbs] = React.useState(false);
  const [fiber] = React.useState(28); // grams of planned fiber for net-carb calc

  // Derived: kcal from macros, % of kcal each
  const macroKcal = (p * 4) + (c * 4) + (f * 9);
  const pPct = macroKcal > 0 ? Math.round((p * 4 / macroKcal) * 100) : 0;
  const cPct = macroKcal > 0 ? Math.round((c * 4 / macroKcal) * 100) : 0;
  const fPct = macroKcal > 0 ? Math.round((f * 9 / macroKcal) * 100) : 0;
  const drift = macroKcal - kcal;
  const driftAbs = Math.abs(drift);

  const Field = ({ label, value, onChange, color, pct, unit = 'g', step = 5 }) => (
    <div style={{
      background: t.surface, border: '1px solid ' + t.separator, borderRadius: BC_RADIUS.md,
      padding: '12px 14px',
      display: 'flex', alignItems: 'center', gap: 10,
    }}>
      <span style={{ width: 8, height: 8, borderRadius: 999, background: color, flexShrink: 0 }} />
      <div style={{ flex: 1 }}>
        <div style={{ fontSize: 13, fontWeight: 600, color: t.text, letterSpacing: -0.1 }}>{label}</div>
        <div style={{ fontSize: 11, color: t.textTer, fontWeight: 600, marginTop: 1 }}>{pct}% of calories</div>
      </div>
      <div style={{
        display: 'flex', alignItems: 'center',
        background: t.surface2, borderRadius: 10,
        height: 38, padding: '0 4px',
      }}>
        <button onClick={() => onChange(Math.max(0, value - step))} style={{
          width: 30, height: 30, borderRadius: 999, border: 'none', background: 'transparent',
          color: t.text, fontSize: 18, cursor: 'pointer',
        }}>−</button>
        <input
          value={value}
          onChange={(e) => { const v = parseInt(e.target.value || '0', 10); if (!isNaN(v)) onChange(Math.max(0, v)); }}
          style={{
            width: 56, background: 'transparent', border: 'none', outline: 'none',
            fontSize: 17, fontWeight: 800, color: t.text, textAlign: 'center',
            fontFamily: SF_STACK, fontVariantNumeric: 'tabular-nums',
          }}
        />
        <button onClick={() => onChange(value + step)} style={{
          width: 30, height: 30, borderRadius: 999, border: 'none', background: 'transparent',
          color: t.text, fontSize: 18, cursor: 'pointer',
        }}>+</button>
      </div>
      <span style={{ width: 16, fontSize: 12, color: t.textSec, fontWeight: 600 }}>{unit}</span>
    </div>
  );

  return (
    <div>
      {/* Live donut + kcal header */}
      <div style={{
        background: t.surface, border: '1px solid ' + t.separator, borderRadius: BC_RADIUS.lg,
        padding: '16px',
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 14 }}>
          <MacroDonutLive mode={mode} p={p} c={c} f={f} kcal={kcal} size={120} />
          <div style={{ flex: 1, minWidth: 0 }}>
            <div style={{ fontSize: 11, fontWeight: 700, color: t.textTer, letterSpacing: 0.6, textTransform: 'uppercase' }}>
              Daily calories
            </div>
            <div style={{ display: 'flex', alignItems: 'baseline', gap: 5, marginTop: 4 }}>
              <span style={{
                fontSize: 36, fontWeight: 800, color: t.text, letterSpacing: -0.8, lineHeight: 1,
                fontVariantNumeric: 'tabular-nums',
              }}>{kcal.toLocaleString()}</span>
              <span style={{ fontSize: 14, color: t.textSec, fontWeight: 600 }}>kcal</span>
            </div>
            <div style={{ fontSize: 12, color: t.textSec, marginTop: 6, fontWeight: 500 }}>
              Maintenance ~2,330 · 500 deficit
            </div>
          </div>
        </div>

        {/* Full-width 4-button stepper */}
        <div style={{
          marginTop: 14, display: 'flex', alignItems: 'center', gap: 6,
        }}>
          {[-50, -10, +10, +50].map(d => (
            <button key={d} onClick={() => setKcal(k => Math.max(800, k + d))} style={{
              flex: 1, height: 40, borderRadius: 10,
              background: t.surface2, border: '1px solid ' + t.separator,
              color: t.text, fontSize: 14, fontWeight: 700,
              fontFamily: SF_STACK, fontVariantNumeric: 'tabular-nums',
              cursor: 'pointer',
              letterSpacing: -0.1,
            }}>{d > 0 ? '+' : ''}{d}</button>
          ))}
        </div>

        {/* Drift warning chip */}
        {driftAbs > 0 && (
          <div style={{
            marginTop: 12, padding: '8px 12px', borderRadius: 10,
            background: driftAbs > 50 ? t.warnSoft : t.surface2,
            color: driftAbs > 50 ? t.warn : t.textSec,
            fontSize: 12, fontWeight: 600, lineHeight: '16px',
            display: 'flex', alignItems: 'center', gap: 8,
          }}>
            <BCIcon name="info" size={14} color="currentColor" />
            <span>
              Macros total <b style={{ fontVariantNumeric: 'tabular-nums' }}>{macroKcal.toLocaleString()} kcal</b>
              {' '}— {driftAbs} {drift > 0 ? 'over' : 'under'} target
            </span>
          </div>
        )}
      </div>

      {/* Macro inputs */}
      <div style={{ marginTop: 14, display: 'flex', flexDirection: 'column', gap: 8 }}>
        <Field label="Protein"       value={p} onChange={setP} color={t.protein} pct={pPct} />
        <Field label={netCarbs ? `Carbs · net (−${fiber}g fiber)` : 'Carbohydrates'} value={c} onChange={setC} color={t.carbs} pct={cPct} />
        <Field label="Fat"           value={f} onChange={setF} color={t.fat}     pct={fPct} />
      </div>

      {/* Net carbs toggle */}
      <div onClick={() => setNetCarbs(n => !n)} style={{
        cursor: 'pointer', marginTop: 12,
      }}>
        <div style={{
          background: t.surface, border: '1px solid ' + t.separator, borderRadius: BC_RADIUS.lg,
          padding: '14px 16px',
          display: 'flex', alignItems: 'center', gap: 12,
        }}>
          <div style={{
            width: 32, height: 32, borderRadius: 8, background: t.tealSoft, color: t.teal,
            display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0,
          }}>
            <BCIcon name="spark" size={18} color={t.teal} />
          </div>
          <div style={{ flex: 1 }}>
            <div style={{ fontSize: 15, fontWeight: 600, color: t.text, letterSpacing: -0.2 }}>Track net carbs</div>
            <div style={{ fontSize: 12, color: t.textSec, marginTop: 2, lineHeight: '16px' }}>
              Subtracts fiber from total carbs in your daily count — useful for keto.
            </div>
          </div>
          <div style={{ pointerEvents: 'none' }}>
            <BCSwitch on={netCarbs} tone="teal" />
          </div>
        </div>
      </div>

      {/* Reset link */}
      <div style={{ marginTop: 18, textAlign: 'center' }}>
        <button style={{
          padding: '8px 14px', background: 'transparent', border: 'none',
          color: t.primary, fontSize: 14, fontWeight: 700, letterSpacing: -0.2,
          cursor: 'pointer', fontFamily: SF_STACK,
        }}>
          Reset to recommended
        </button>
      </div>
    </div>
  );
}

// ─── Mode segmented ──────────────────────────────────────────────────
function ModeSegmented({ mode, value, onChange }) {
  const t = mode === 'dark' ? BC_DARK : BC_LIGHT;
  return (
    <div style={{
      display: 'flex', padding: 3,
      background: t.surface2, borderRadius: 10, height: 38,
    }}>
      {['Recommended', 'Custom'].map(o => {
        const active = o === value;
        return (
          <button key={o} onClick={() => onChange(o)} style={{
            flex: 1, height: 32, border: 'none',
            background: active ? t.surface : 'transparent',
            color: t.text, fontSize: 13, fontWeight: active ? 700 : 500,
            borderRadius: 7,
            boxShadow: active ? '0 1px 3px rgba(0,0,0,0.1)' : 'none',
            cursor: 'pointer', fontFamily: SF_STACK,
          }}>{o}</button>
        );
      })}
    </div>
  );
}

// ─── Screen ──────────────────────────────────────────────────────────
function EditMacrosScreen({ mode = 'light', initial = 'Recommended' }) {
  const [mtype, setMtype] = React.useState(initial);
  const t = mode === 'dark' ? BC_DARK : BC_LIGHT;
  return (
    <BCTheme mode={mode} padding={0} style={{ position: 'relative', overflow: 'hidden', height: '100%' }}>
      <EMStatusBar mode={mode} />
      <EMNavBar mode={mode} dirty={mtype === 'Custom'} />

      <div style={{ position: 'absolute', top: 54 + 52, left: 0, right: 0, bottom: 0, overflowY: 'auto', overflowX: 'hidden' }}>
        <div style={{ padding: '14px 16px 24px' }}>
          <ModeSegmented mode={mode} value={mtype} onChange={setMtype} />
          <div style={{ marginTop: 14 }}>
            {mtype === 'Recommended' ? <RecommendedPanel mode={mode} /> : <CustomPanel mode={mode} />}
          </div>
        </div>
      </div>
    </BCTheme>
  );
}

Object.assign(window, { EditMacrosScreen });
