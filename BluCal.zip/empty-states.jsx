// empty-states.jsx — Empty states for Today, Trends, Meals, Coach

function ESStatusBar({ mode }) {
  const c = mode === 'dark' ? '#fff' : '#000';
  return (
    <div style={{
      height: 54, padding: '14px 28px 0',
      display: 'flex', alignItems: 'center', justifyContent: 'space-between',
      fontSize: 17, fontWeight: 600, letterSpacing: -0.41, color: c, fontFamily: SF_STACK,
    }}>
      <span style={{ fontVariantNumeric: 'tabular-nums' }}>9:41</span>
      <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
        <svg width="18" height="11" viewBox="0 0 18 11">
          <rect x="0" y="7" width="3" height="4" rx="0.6" fill={c}/>
          <rect x="5" y="5" width="3" height="6" rx="0.6" fill={c}/>
          <rect x="10" y="3" width="3" height="8" rx="0.6" fill={c}/>
          <rect x="15" y="0" width="3" height="11" rx="0.6" fill={c}/>
        </svg>
        <svg width="26" height="12" viewBox="0 0 26 12">
          <rect x="0.5" y="0.5" width="22" height="11" rx="3" stroke={c} strokeOpacity="0.4" fill="none"/>
          <rect x="2" y="2" width="19" height="8" rx="1.5" fill={c}/>
          <rect x="23.5" y="4" width="1.5" height="4" rx="0.7" fill={c} fillOpacity="0.4"/>
        </svg>
      </div>
    </div>
  );
}

function ESTabBar({ mode, active }) {
  const t = mode === 'dark' ? BC_DARK : BC_LIGHT;
  const tabs = [
    { name: 'Today',  icon: 'flame' },
    { name: 'Trends', icon: 'chart' },
    { name: 'Meals',  icon: 'fork' },
    { name: 'Coach',  icon: 'spark' },
    { name: 'Profile',icon: 'user' },
  ];
  return (
    <div style={{
      background: t.surface, borderTop: '0.5px solid ' + t.separator, paddingTop: 8,
    }}>
      <div style={{ display: 'flex' }}>
        {tabs.map((tb, i) => {
          const isActive = i === active;
          const c = isActive ? t.primary : t.textTer;
          const inactive = '#8E8E93';
          return (
            <div key={tb.name} style={{
              flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 3,
            }}>
              {tb.name === 'Today' ? (
                <BluCalMark size={26} color={isActive ? t.primary : inactive} />
              ) : (
                <BCIcon name={tb.icon} size={26} color={c} strokeWidth={isActive ? 2.2 : 1.8} />
              )}
              <div style={{ fontSize: 10, fontWeight: 600, color: c, letterSpacing: 0.1 }}>{tb.name}</div>
            </div>
          );
        })}
      </div>
      <div style={{ height: 14, display: 'flex', justifyContent: 'center', alignItems: 'flex-end', paddingBottom: 6 }}>
        <div style={{ width: 134, height: 5, borderRadius: 999, background: mode === 'dark' ? 'rgba(255,255,255,0.6)' : 'rgba(0,0,0,0.3)' }} />
      </div>
    </div>
  );
}

// ─── Empty plate illustration ────────────────────────────────────────
function EmptyPlate({ mode, size = 140 }) {
  const t = mode === 'dark' ? BC_DARK : BC_LIGHT;
  return (
    <svg width={size} height={size} viewBox="0 0 140 140" fill="none">
      <ellipse cx="70" cy="125" rx="50" ry="6" fill={t.surface2} />
      {/* Plate outer ring */}
      <circle cx="70" cy="70" r="56" stroke={t.hairline} strokeWidth="2" fill={t.surface} />
      {/* Inner well */}
      <circle cx="70" cy="70" r="44" stroke={t.separator} strokeWidth="1.4" fill="none" />
      {/* Soft sparkle in center */}
      <circle cx="70" cy="70" r="5" fill={t.primarySoft} />
      <circle cx="70" cy="70" r="2.2" fill={t.primary} />
      {/* Fork + knife icons floating */}
      <g transform="translate(28,30) rotate(-22)" opacity="0.7">
        <path d="M2 0 V 18 M5 0 V 18 M8 0 V 18 M5 18 V 38" stroke={t.textTer} strokeWidth="1.4" strokeLinecap="round" fill="none"/>
      </g>
      <g transform="translate(108,28) rotate(20)" opacity="0.7">
        <path d="M2 0 q 4 4 0 14 q -4 -4 0 -14 M2 14 V 38" stroke={t.textTer} strokeWidth="1.4" strokeLinecap="round" fill="none"/>
      </g>
    </svg>
  );
}

// ─── Today empty state ───────────────────────────────────────────────
function TodayEmpty({ mode }) {
  const t = mode === 'dark' ? BC_DARK : BC_LIGHT;
  return (
    <BCTheme mode={mode} padding={0} style={{ position: 'relative', overflow: 'hidden', height: '100%' }}>
      <ESStatusBar mode={mode} />
      <div style={{ position: 'absolute', top: 54, left: 0, right: 0, bottom: 86, overflow: 'hidden' }}>
        {/* Title bar with avatar */}
        <div style={{ padding: '8px 20px 0', display: 'flex', alignItems: 'flex-start' }}>
          <div style={{ flex: 1 }}>
            <div style={{ fontSize: 34, fontWeight: 800, color: t.text, letterSpacing: -0.8, lineHeight: '41px' }}>Today</div>
            <div style={{ fontSize: 14, color: t.textSec, marginTop: 2, fontWeight: 500 }}>Tuesday, May 12</div>
          </div>
          <div style={{
            width: 38, height: 38, borderRadius: 999,
            background: t.teal, color: '#fff',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            fontSize: 14, fontWeight: 700,
          }}>AM</div>
        </div>

        {/* Empty content */}
        <div style={{
          padding: '32px 24px',
          display: 'flex', flexDirection: 'column', alignItems: 'center', textAlign: 'center',
          gap: 8, marginTop: 20,
        }}>
          <EmptyPlate mode={mode} size={150} />
          <div style={{ fontSize: 22, fontWeight: 800, color: t.text, letterSpacing: -0.4, marginTop: 8 }}>
            Nothing logged yet
          </div>
          <div style={{ fontSize: 15, color: t.textSec, marginTop: 4, lineHeight: '21px', maxWidth: 260 }}>
            Tap the <b style={{ color: t.text }}>+</b> button to log your first meal of the day.
          </div>

          {/* Curved arrow pointing to FAB */}
          <div style={{ position: 'absolute', right: 80, bottom: 12 }}>
            <svg width="120" height="100" viewBox="0 0 120 100" fill="none">
              <path d="M 10 18 Q 60 30 92 76"
                stroke={t.primary} strokeWidth="2.2" strokeDasharray="5 5"
                strokeLinecap="round" fill="none"/>
              <path d="M 84 70 L 92 76 L 86 84"
                stroke={t.primary} strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round" fill="none"/>
              <text x="20" y="12" fontFamily={SF_STACK} fontSize="13" fontWeight="700" fill={t.primary} letterSpacing="-0.2">
                Tap here
              </text>
            </svg>
          </div>

          {/* Quick suggestions */}
          <div style={{ marginTop: 14, display: 'flex', gap: 8, flexWrap: 'wrap', justifyContent: 'center' }}>
            {['Scan barcode', 'Photo AI', 'Quick add'].map(s => (
              <span key={s} style={{
                padding: '7px 12px', borderRadius: 999,
                background: t.surface, border: '1px solid ' + t.separator,
                fontSize: 12, fontWeight: 600, color: t.text,
              }}>{s}</span>
            ))}
          </div>
        </div>

        {/* FAB */}
        <div style={{ position: 'absolute', right: 18, bottom: 14, zIndex: 8 }}>
          <button style={{
            width: 56, height: 56, borderRadius: 28,
            background: t.primary, color: '#fff', border: 'none',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            cursor: 'pointer',
            boxShadow: '0 8px 22px rgba(24,95,165,0.45), 0 2px 6px rgba(0,0,0,0.12)',
          }}>
            <BCIcon name="plus" size={28} color="#fff" strokeWidth={2.4} />
          </button>
        </div>
      </div>
      <div style={{ position: 'absolute', left: 0, right: 0, bottom: 0 }}>
        <ESTabBar mode={mode} active={0} />
      </div>
    </BCTheme>
  );
}

// ─── Trends empty state (ghosted preview) ────────────────────────────
function TrendsEmpty({ mode }) {
  const t = mode === 'dark' ? BC_DARK : BC_LIGHT;
  const Ghost = ({ children }) => (
    <div style={{
      background: t.surface, border: '1px solid ' + t.separator, borderRadius: BC_RADIUS.lg,
      padding: '14px 16px',
      filter: 'blur(2px) saturate(0.5)',
      opacity: 0.6,
      pointerEvents: 'none',
    }}>{children}</div>
  );

  return (
    <BCTheme mode={mode} padding={0} style={{ position: 'relative', overflow: 'hidden', height: '100%' }}>
      <ESStatusBar mode={mode} />
      <div style={{ position: 'absolute', top: 54, left: 0, right: 0, bottom: 86, overflowY: 'auto', overflowX: 'hidden' }}>
        <div style={{ padding: '8px 20px 4px' }}>
          <div style={{ fontSize: 34, fontWeight: 800, color: t.text, letterSpacing: -0.8, lineHeight: '41px' }}>Trends</div>
        </div>

        {/* Hero message */}
        <div style={{ padding: '12px 16px 0' }}>
          <div style={{
            background: t.primarySoft, borderRadius: BC_RADIUS.lg,
            padding: '18px 18px',
          }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
              <div style={{
                width: 42, height: 42, borderRadius: 12,
                background: t.primary, color: '#fff', flexShrink: 0,
                display: 'flex', alignItems: 'center', justifyContent: 'center',
              }}>
                <BCIcon name="chart" size={22} color="#fff" />
              </div>
              <div>
                <div style={{ fontSize: 17, fontWeight: 800, color: t.text, letterSpacing: -0.3 }}>
                  Keep logging
                </div>
                <div style={{ fontSize: 13, color: t.text, marginTop: 2 }}>
                  Trends appear after 7 days of data.
                </div>
              </div>
            </div>
            <div style={{
              marginTop: 14, display: 'flex', alignItems: 'center', gap: 8,
              fontSize: 12, fontWeight: 700, color: t.text,
            }}>
              <div style={{ flex: 1, height: 8, background: 'rgba(255,255,255,0.5)', borderRadius: 8, overflow: 'hidden' }}>
                <div style={{ width: (4/7 * 100) + '%', height: '100%', background: t.primary, borderRadius: 8 }} />
              </div>
              <span style={{ fontVariantNumeric: 'tabular-nums' }}>4 / 7 days</span>
            </div>
          </div>
        </div>

        {/* Ghost previews */}
        <div style={{ padding: '14px 16px 24px', display: 'flex', flexDirection: 'column', gap: 12 }}>
          <Ghost>
            <div style={{ fontSize: 11, fontWeight: 700, color: t.textTer, letterSpacing: 0.6, textTransform: 'uppercase' }}>Calories</div>
            <svg viewBox="0 0 320 100" style={{ marginTop: 10, width: '100%', height: 100 }}>
              <path d="M 0 60 L 30 50 L 60 70 L 90 40 L 120 55 L 150 30 L 180 50 L 210 35 L 240 60 L 270 45 L 300 55 L 320 40"
                fill="none" stroke={t.primary} strokeWidth="3" strokeLinecap="round" strokeLinejoin="round"/>
              <line x1="0" y1="50" x2="320" y2="50" stroke={t.teal} strokeWidth="1.6" strokeDasharray="6 4"/>
            </svg>
          </Ghost>
          <Ghost>
            <div style={{ fontSize: 11, fontWeight: 700, color: t.textTer, letterSpacing: 0.6, textTransform: 'uppercase' }}>Weight</div>
            <svg viewBox="0 0 320 80" style={{ marginTop: 10, width: '100%', height: 80 }}>
              {[10, 40, 70, 100, 130, 160, 190, 220, 250, 280, 310].map((x, i) => (
                <circle key={i} cx={x} cy={40 + Math.sin(i * 0.6) * 12} r="2.4" fill={t.primary} opacity="0.7"/>
              ))}
              <line x1="0" y1="42" x2="320" y2="32" stroke={t.primary} strokeWidth="2.4"/>
            </svg>
          </Ghost>
          <Ghost>
            <div style={{ fontSize: 11, fontWeight: 700, color: t.textTer, letterSpacing: 0.6, textTransform: 'uppercase' }}>Momentum</div>
            <svg viewBox="0 0 320 70" style={{ marginTop: 10, width: '100%', height: 70 }}>
              {[50, 30, 60, 40, 55, 65, 45].map((h, i) => (
                <rect key={i} x={20 + i * 42} y={70 - h} width="26" height={h} rx="3" fill={t.success} opacity={0.7}/>
              ))}
            </svg>
          </Ghost>
        </div>
      </div>
      <div style={{ position: 'absolute', left: 0, right: 0, bottom: 0 }}>
        <ESTabBar mode={mode} active={1} />
      </div>
    </BCTheme>
  );
}

// ─── Meals empty state ───────────────────────────────────────────────
function MealsEmpty({ mode }) {
  const t = mode === 'dark' ? BC_DARK : BC_LIGHT;
  return (
    <BCTheme mode={mode} padding={0} style={{ position: 'relative', overflow: 'hidden', height: '100%' }}>
      <ESStatusBar mode={mode} />
      <div style={{ position: 'absolute', top: 54, left: 0, right: 0, bottom: 86, overflow: 'hidden' }}>
        <div style={{ padding: '8px 20px 4px' }}>
          <div style={{ fontSize: 34, fontWeight: 800, color: t.text, letterSpacing: -0.8, lineHeight: '41px' }}>Plan</div>
          <div style={{ fontSize: 14, color: t.textSec, marginTop: 2, fontWeight: 500 }}>This week · May 12 – 18</div>
        </div>

        {/* Empty week strip (greyed) */}
        <div style={{ padding: '14px 16px 0', display: 'flex', gap: 6 }}>
          {['M','T','W','T','F','S','S'].map((d, i) => (
            <div key={i} style={{
              flex: 1, padding: '8px 0 10px',
              background: t.surface, border: '1px solid ' + t.separator, borderRadius: 14,
              display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 2,
              opacity: 0.5,
            }}>
              <span style={{ fontSize: 10, fontWeight: 700, letterSpacing: 0.4, color: t.textTer }}>{d}</span>
              <span style={{ fontSize: 17, fontWeight: 700, color: t.textSec, letterSpacing: -0.3, fontVariantNumeric: 'tabular-nums' }}>{12 + i}</span>
            </div>
          ))}
        </div>

        {/* Empty content */}
        <div style={{
          padding: '36px 24px 0', textAlign: 'center',
          display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 6,
        }}>
          {/* Calendar-with-fork illustration */}
          <svg width="120" height="120" viewBox="0 0 120 120" fill="none">
            <ellipse cx="60" cy="108" rx="42" ry="5" fill={t.surface2} />
            <rect x="18" y="20" width="84" height="76" rx="14" fill={t.surface} stroke={t.separator} strokeWidth="2"/>
            <rect x="18" y="20" width="84" height="20" rx="14" fill={t.primarySoft}/>
            <path d="M 32 14 V 26 M 88 14 V 26" stroke={t.primary} strokeWidth="3" strokeLinecap="round"/>
            <path d="M 30 32 H 90" stroke={t.primary} strokeWidth="0" opacity="0"/>
            {/* dotted grid */}
            {[44, 56, 68, 80].map(y => (
              <line key={y} x1="28" y1={y} x2="92" y2={y} stroke={t.hairline} strokeWidth="0.5" strokeDasharray="3 3"/>
            ))}
            {/* fork floating */}
            <g transform="translate(50, 50) rotate(-15)">
              <path d="M2 0 V 18 M5 0 V 18 M8 0 V 18 M5 18 V 38" stroke={t.primary} strokeWidth="1.8" strokeLinecap="round" fill="none"/>
            </g>
          </svg>
          <div style={{ fontSize: 22, fontWeight: 800, color: t.text, letterSpacing: -0.4, marginTop: 4 }}>
            No meals planned this week
          </div>
          <div style={{ fontSize: 14, color: t.textSec, marginTop: 4, lineHeight: '20px', maxWidth: 280 }}>
            Plan ahead and you'll always know what to eat — even when life gets busy.
          </div>
          <div style={{ marginTop: 18, width: '100%', maxWidth: 280, display: 'flex', flexDirection: 'column', gap: 10 }}>
            <BCButton kind="primary" size="lg" block
              icon={<BCIcon name="spark" size={18} color="#fff" />}>
              Start planning
            </BCButton>
            <BCButton kind="plain" size="md" block>Use a template instead</BCButton>
          </div>
        </div>
      </div>
      <div style={{ position: 'absolute', left: 0, right: 0, bottom: 0 }}>
        <ESTabBar mode={mode} active={2} />
      </div>
    </BCTheme>
  );
}

// ─── Coach empty state ───────────────────────────────────────────────
function CoachEmpty({ mode }) {
  const t = mode === 'dark' ? BC_DARK : BC_LIGHT;
  const progress = 4 / 7;
  return (
    <BCTheme mode={mode} padding={0} style={{ position: 'relative', overflow: 'hidden', height: '100%' }}>
      <ESStatusBar mode={mode} />
      <div style={{ position: 'absolute', top: 54, left: 0, right: 0, bottom: 86, overflow: 'auto' }}>
        <div style={{ padding: '8px 20px 4px' }}>
          <div style={{ fontSize: 34, fontWeight: 800, color: t.text, letterSpacing: -0.8, lineHeight: '41px' }}>Coach</div>
        </div>

        <div style={{ padding: '12px 16px 0' }}>
          <div style={{
            background: t.surface, border: '1px solid ' + t.separator, borderRadius: BC_RADIUS.lg,
            padding: '22px 18px', textAlign: 'center',
            display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 8,
          }}>
            {/* Locked sparkle ring */}
            <div style={{ position: 'relative', width: 96, height: 96 }}>
              <svg width="96" height="96" viewBox="0 0 96 96">
                <circle cx="48" cy="48" r="40" stroke={t.surface2} strokeWidth="9" fill="none"/>
                <circle cx="48" cy="48" r="40"
                  stroke={t.primary} strokeWidth="9" fill="none"
                  strokeDasharray={2 * Math.PI * 40}
                  strokeDashoffset={2 * Math.PI * 40 * (1 - progress)}
                  strokeLinecap="round"
                  transform="rotate(-90 48 48)"
                />
              </svg>
              <div style={{
                position: 'absolute', inset: 0,
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                color: t.primary,
              }}>
                {/* Lock icon */}
                <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke={t.primary} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <rect x="5" y="11" width="14" height="10" rx="2"/>
                  <path d="M8 11V8a4 4 0 018 0v3"/>
                </svg>
              </div>
            </div>

            <div style={{ fontSize: 22, fontWeight: 800, color: t.text, letterSpacing: -0.4, marginTop: 4 }}>
              Insights unlock soon
            </div>
            <div style={{ fontSize: 14, color: t.textSec, marginTop: 4, lineHeight: '20px', maxWidth: 280 }}>
              Log <b style={{ color: t.text }}>3 more days</b> and your coach will start spotting patterns and tuning your targets.
            </div>

            {/* Progress dots */}
            <div style={{ marginTop: 14, display: 'flex', gap: 8 }}>
              {[1,2,3,4,5,6,7].map(n => {
                const done = n <= 4;
                return (
                  <div key={n} style={{
                    width: 26, height: 26, borderRadius: 999,
                    background: done ? t.primary : t.surface2,
                    border: done ? 'none' : '1px solid ' + t.separator,
                    color: '#fff',
                    display: 'flex', alignItems: 'center', justifyContent: 'center',
                    fontSize: 11, fontWeight: 700,
                  }}>
                    {done ? <BCIcon name="check" size={13} color="#fff" strokeWidth={3} /> : <span style={{ color: t.textTer }}>{n}</span>}
                  </div>
                );
              })}
            </div>
            <div style={{ fontSize: 12, color: t.textSec, marginTop: 6, fontVariantNumeric: 'tabular-nums', fontWeight: 600 }}>
              4 / 7 days logged
            </div>
          </div>
        </div>

        {/* What unlocks */}
        <div style={{ padding: '14px 16px 24px' }}>
          <div style={{
            fontSize: 11, fontWeight: 700, color: t.textTer, letterSpacing: 0.6, textTransform: 'uppercase',
            padding: '0 4px 8px',
          }}>What unlocks</div>
          <div style={{
            background: t.surface, border: '1px solid ' + t.separator, borderRadius: BC_RADIUS.lg,
            overflow: 'hidden',
          }}>
            {[
              { icon: 'spark', title: 'Personalized weekly insights',  sub: 'Spot patterns the eye misses' },
              { icon: 'chart', title: 'Adaptive macro targets',         sub: 'Stays in sync as your weight changes' },
              { icon: 'flame', title: 'Coach chat',                     sub: 'Ask your coach anything' },
            ].map((it, i) => (
              <div key={i} style={{
                display: 'flex', alignItems: 'center', gap: 12,
                padding: '12px 14px',
                borderBottom: i < 2 ? '0.5px solid ' + t.separator : 'none',
                opacity: 0.7,
              }}>
                <div style={{
                  width: 32, height: 32, borderRadius: 8, flexShrink: 0,
                  background: t.surface2, color: t.textSec,
                  display: 'flex', alignItems: 'center', justifyContent: 'center',
                }}>
                  <BCIcon name={it.icon} size={18} color={t.textSec} />
                </div>
                <div style={{ flex: 1 }}>
                  <div style={{ fontSize: 14, fontWeight: 700, color: t.text }}>{it.title}</div>
                  <div style={{ fontSize: 12, color: t.textSec, marginTop: 2 }}>{it.sub}</div>
                </div>
                <BCIcon name="check" size={14} color={t.textTer} strokeWidth={2.4} style={{ opacity: 0 }} />
              </div>
            ))}
          </div>
        </div>
      </div>
      <div style={{ position: 'absolute', left: 0, right: 0, bottom: 0 }}>
        <ESTabBar mode={mode} active={3} />
      </div>
    </BCTheme>
  );
}

Object.assign(window, { TodayEmpty, TrendsEmpty, MealsEmpty, CoachEmpty });
