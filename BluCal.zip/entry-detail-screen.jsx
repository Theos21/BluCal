// entry-detail-screen.jsx — Food entry detail / edit
// Sections (top→bottom):
//   • Status + nav bar (back, title, subtitle)
//   • Hero card: big kcal + 3 macro tiles
//   • Portion editor (live-recalculating)
//   • Hunger rating (1–5 dots)
//   • Expandable "Nutrition details"
//   • Expandable "Micronutrients" (% DV bars)
//   • Delete entry (destructive)

// ─── Status bar / nav ─────────────────────────────────────────────────
function EDStatusBar({ mode }) {
  const c = mode === 'dark' ? '#fff' : '#000';
  return (
    <div style={{
      height: 54, padding: '14px 28px 0',
      display: 'flex', alignItems: 'center', justifyContent: 'space-between',
      fontSize: 17, fontWeight: 600, letterSpacing: -0.41, color: c,
      fontFamily: SF_STACK,
    }}>
      <span style={{ fontVariantNumeric: 'tabular-nums' }}>9:41</span>
      <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
        <svg width="18" height="11" viewBox="0 0 18 11">
          <rect x="0" y="7" width="3" height="4" rx="0.6" fill={c}/>
          <rect x="5" y="5" width="3" height="6" rx="0.6" fill={c}/>
          <rect x="10" y="3" width="3" height="8" rx="0.6" fill={c}/>
          <rect x="15" y="0" width="3" height="11" rx="0.6" fill={c}/>
        </svg>
        <svg width="26" height="12" viewBox="0 0 26 12">
          <rect x="0.5" y="0.5" width="22" height="11" rx="3" stroke={c} strokeOpacity="0.4" fill="none"/>
          <rect x="2" y="2" width="19" height="8" rx="1.5" fill={c}/>
          <rect x="23.5" y="4" width="1.5" height="4" rx="0.7" fill={c} fillOpacity="0.4"/>
        </svg>
      </div>
    </div>
  );
}

function EDNavBar({ mode, onBack }) {
  const t = mode === 'dark' ? BC_DARK : BC_LIGHT;
  return (
    <div style={{ height: 44, padding: '0 8px', display: 'flex', alignItems: 'center' }}>
      <button onClick={onBack} style={{
        height: 32, padding: '0 8px 0 4px', border: 'none', background: 'transparent',
        display: 'inline-flex', alignItems: 'center', gap: 2,
        color: t.primary, fontSize: 17, letterSpacing: -0.41,
        fontFamily: SF_STACK, cursor: 'pointer',
      }}>
        <BCIcon name="chev" size={20} color={t.primary} style={{ transform: 'scaleX(-1)' }} />
        <span>Today</span>
      </button>
      <div style={{ flex: 1 }} />
      <button style={{
        height: 32, padding: '0 12px', border: 'none', background: 'transparent',
        color: t.primary, fontSize: 17, fontWeight: 600, letterSpacing: -0.41,
        cursor: 'pointer',
      }}>Save</button>
    </div>
  );
}

// ─── Reusable expander section ────────────────────────────────────────
function EDExpander({ mode, title, defaultOpen = false, children, right }) {
  const [open, setOpen] = React.useState(defaultOpen);
  const t = mode === 'dark' ? BC_DARK : BC_LIGHT;
  return (
    <div style={{
      background: t.surface, border: '1px solid ' + t.separator, borderRadius: BC_RADIUS.lg,
      overflow: 'hidden',
    }}>
      <button onClick={() => setOpen(o => !o)} style={{
        width: '100%', padding: '14px 16px', background: 'transparent', border: 'none',
        display: 'flex', alignItems: 'center', gap: 10, cursor: 'pointer',
        fontFamily: SF_STACK, textAlign: 'left',
      }}>
        <span style={{ flex: 1, fontSize: 16, fontWeight: 700, color: t.text, letterSpacing: -0.2 }}>{title}</span>
        {right}
        <span style={{
          display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
          width: 22, height: 22, color: t.textSec,
          transform: open ? 'rotate(180deg)' : 'rotate(0deg)',
          transition: 'transform .15s',
        }}>
          <BCIcon name="caret-down" size={18} color={t.textSec} />
        </span>
      </button>
      {open && (
        <div style={{ padding: '0 16px 14px', borderTop: '0.5px solid ' + t.separator }}>{children}</div>
      )}
    </div>
  );
}

// ─── Hunger rating ────────────────────────────────────────────────────
function HungerRating({ mode, value, onChange }) {
  const t = mode === 'dark' ? BC_DARK : BC_LIGHT;
  const labels = ['Not hungry', 'Slightly', 'Moderate', 'Very', 'Ravenous'];
  return (
    <div style={{
      background: t.surface, border: '1px solid ' + t.separator, borderRadius: BC_RADIUS.lg,
      padding: '14px 16px',
    }}>
      <div style={{ display: 'flex', alignItems: 'baseline', justifyContent: 'space-between', marginBottom: 12 }}>
        <span style={{ fontSize: 16, fontWeight: 700, color: t.text, letterSpacing: -0.2 }}>Hunger when eating</span>
        {value == null ? (
          <span style={{ fontSize: 13, color: t.textTer, fontWeight: 500 }}>Add hunger rating</span>
        ) : (
          <span style={{ fontSize: 13, color: t.textSec, fontWeight: 600 }}>{labels[value - 1]}</span>
        )}
      </div>
      <div style={{ display: 'flex', gap: 10, alignItems: 'center' }}>
        {[1, 2, 3, 4, 5].map(n => {
          const filled = value != null && n <= value;
          return (
            <button key={n} onClick={() => onChange(n)} style={{
              flex: 1, height: 36, borderRadius: 999, border: 'none',
              background: filled ? t.primarySoft : t.surface2,
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              cursor: 'pointer', WebkitTapHighlightColor: 'transparent',
            }}>
              <span style={{
                width: 12, height: 12, borderRadius: 999,
                background: filled ? t.primary : t.hairline,
              }} />
            </button>
          );
        })}
      </div>
    </div>
  );
}

// ─── Daily-value bar ──────────────────────────────────────────────────
function DVBar({ mode, label, pct, value, color }) {
  const t = mode === 'dark' ? BC_DARK : BC_LIGHT;
  const c = color || t.primary;
  const w = Math.min(100, pct);
  return (
    <div style={{ padding: '10px 0', borderBottom: '0.5px solid ' + t.separator }}>
      <div style={{ display: 'flex', alignItems: 'baseline', justifyContent: 'space-between', marginBottom: 6 }}>
        <span style={{ fontSize: 14, fontWeight: 600, color: t.text, letterSpacing: -0.1 }}>{label}</span>
        <span style={{ fontSize: 12, color: t.textSec, fontVariantNumeric: 'tabular-nums' }}>
          <span style={{ color: t.text, fontWeight: 700 }}>{value}</span>
          <span style={{ marginLeft: 8 }}>{pct}% DV</span>
        </span>
      </div>
      <div style={{ height: 6, background: t.surface2, borderRadius: 6, overflow: 'hidden' }}>
        <div style={{ height: '100%', width: w + '%', background: c, borderRadius: 6,
          transition: 'width .25s' }} />
      </div>
    </div>
  );
}

// ─── Nutrition row ────────────────────────────────────────────────────
function NutriRow({ mode, label, value, unit, indent }) {
  const t = mode === 'dark' ? BC_DARK : BC_LIGHT;
  return (
    <div style={{
      display: 'flex', justifyContent: 'space-between', alignItems: 'baseline',
      padding: '10px 0', borderBottom: '0.5px solid ' + t.separator,
      paddingLeft: indent ? 16 : 0,
    }}>
      <span style={{ fontSize: 14, fontWeight: indent ? 500 : 600, color: indent ? t.textSec : t.text, letterSpacing: -0.1 }}>{label}</span>
      <span style={{ fontSize: 14, fontWeight: 700, color: t.text, fontVariantNumeric: 'tabular-nums' }}>
        {value}<span style={{ fontSize: 12, color: t.textSec, fontWeight: 500, marginLeft: 3 }}>{unit}</span>
      </span>
    </div>
  );
}

// ─── Screen ───────────────────────────────────────────────────────────
// Source of truth: per-100g nutrition values. Portion edits scale everything.
const ENTRY = {
  name: 'Greek yogurt + granola',
  timestamp: 'Today · 7:18 AM · Breakfast',
  per100g: {
    kcal: 152, p: 8.5, c: 19.8, f: 3.8,
    fiber: 2.6, sugar: 9.4, sat: 0.9, sodium: 58, chol: 9,
    vitA: 4, vitC: 1, vitD: 8, b12: 30, iron: 6, calcium: 12,
  },
};

function EntryDetailScreen({ mode = 'light', onBack }) {
  const t = mode === 'dark' ? BC_DARK : BC_LIGHT;
  const [grams, setGrams] = React.useState(225);   // 1 cup + 1/4 cup ≈ 225g
  const [unit, setUnit] = React.useState('g');
  const [hunger, setHunger] = React.useState(3);

  // Scale per-100g values by portion in grams
  const scale = grams / 100;
  const s = (v, prec = 0) => +(v * scale).toFixed(prec);
  const macros = ENTRY.per100g;
  const kcal = s(macros.kcal);
  const p = s(macros.p, 1), c = s(macros.c, 1), f = s(macros.f, 1);

  // Compute % daily values (FDA refs)
  const dv = {
    vitA: { v: s(macros.vitA, 0) + '%', pct: s(macros.vitA, 0) },
    vitC: { v: s(macros.vitC, 0) + '%', pct: s(macros.vitC, 0) },
    vitD: { v: s(macros.vitD, 0) + '%', pct: s(macros.vitD, 0) },
    b12:  { v: s(macros.b12,  0) + '%', pct: s(macros.b12,  0) },
    iron: { v: s(macros.iron, 0) + '%', pct: s(macros.iron, 0) },
    calc: { v: s(macros.calcium, 0) + '%', pct: s(macros.calcium, 0) },
  };

  const macroTiles = [
    { label: 'Calories', value: kcal, unit: 'kcal', color: t.text, bg: t.surface, big: true },
    { label: 'Protein',  value: p, unit: 'g', color: t.protein, bg: t.primarySoft },
    { label: 'Carbs',    value: c, unit: 'g', color: t.carbs,   bg: t.warnSoft },
    { label: 'Fat',      value: f, unit: 'g', color: t.fat,     bg: t.tealSoft },
  ];

  return (
    <BCTheme mode={mode} padding={0} style={{ position: 'relative', overflow: 'hidden', height: '100%' }}>
      <EDStatusBar mode={mode} />
      <EDNavBar mode={mode} onBack={onBack} />

      <div style={{ position: 'absolute', top: 54 + 44, left: 0, right: 0, bottom: 0, overflowY: 'auto', overflowX: 'hidden' }}>
        {/* Title */}
        <div style={{ padding: '4px 20px 12px' }}>
          <div style={{ fontSize: 28, fontWeight: 800, color: t.text, letterSpacing: -0.6, lineHeight: '34px' }}>
            {ENTRY.name}
          </div>
          <div style={{ fontSize: 14, color: t.textSec, marginTop: 4, fontWeight: 500 }}>{ENTRY.timestamp}</div>
        </div>

        {/* 2×2 macro grid — calories big, three colored tiles */}
        <div style={{ padding: '0 16px' }}>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10 }}>
            {/* Calories — spans both columns? Actually 2×2 means kcal is one of 4. */}
            {macroTiles.map((m, i) => (
              <div key={m.label} style={{
                background: m.bg,
                border: '1px solid ' + t.separator,
                borderRadius: BC_RADIUS.lg,
                padding: '14px 16px',
                minHeight: m.big ? 96 : 84,
                display: 'flex', flexDirection: 'column', justifyContent: 'space-between',
              }}>
                <div style={{ fontSize: 11, fontWeight: 700, letterSpacing: 0.6, textTransform: 'uppercase', color: t.textTer }}>{m.label}</div>
                <div style={{ display: 'flex', alignItems: 'baseline', gap: 4 }}>
                  <span style={{
                    fontSize: m.big ? 32 : 24,
                    fontWeight: 800,
                    color: m.color,
                    letterSpacing: -0.6,
                    fontVariantNumeric: 'tabular-nums',
                    lineHeight: 1,
                  }}>{m.value}</span>
                  <span style={{ fontSize: m.big ? 14 : 13, color: t.textSec, fontWeight: 600 }}>{m.unit}</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Portion editor */}
        <div style={{ padding: '14px 16px 0' }}>
          <div style={{
            background: t.surface, border: '1px solid ' + t.separator, borderRadius: BC_RADIUS.lg,
            padding: '14px 16px',
          }}>
            <div style={{ fontSize: 11, fontWeight: 700, letterSpacing: 0.6, textTransform: 'uppercase', color: t.textTer, marginBottom: 10 }}>Portion</div>
            <div style={{ display: 'flex', gap: 10, alignItems: 'stretch' }}>
              {/* Stepper-style numeric */}
              <div style={{
                flex: 1, minWidth: 0,
                display: 'flex', alignItems: 'center',
                background: t.surface2, borderRadius: 12,
                border: '1px solid ' + t.separator,
                height: 48, padding: '0 4px',
              }}>
                <button onClick={() => setGrams(g => Math.max(5, g - 5))} style={{
                  width: 36, height: 40, borderRadius: 999, border: 'none', background: 'transparent',
                  color: t.text, fontSize: 22, cursor: 'pointer', flexShrink: 0,
                }}>−</button>
                <input
                  value={grams}
                  onChange={(e) => { const v = parseFloat(e.target.value || '0'); if (!isNaN(v)) setGrams(Math.max(0, v)); }}
                  style={{
                    flex: 1, minWidth: 0, width: '100%',
                    background: 'transparent', border: 'none', outline: 'none',
                    fontSize: 22, fontWeight: 800, color: t.text, textAlign: 'center',
                    fontFamily: SF_STACK, fontVariantNumeric: 'tabular-nums',
                  }}
                />
                <button onClick={() => setGrams(g => g + 5)} style={{
                  width: 36, height: 40, borderRadius: 999, border: 'none', background: 'transparent',
                  color: t.text, fontSize: 22, cursor: 'pointer', flexShrink: 0,
                }}>+</button>
              </div>
              {/* Unit dropdown */}
              <select value={unit} onChange={(e) => setUnit(e.target.value)} style={{
                width: 84, flexShrink: 0,
                height: 48, padding: '0 28px 0 14px',
                background: t.surface2, color: t.text,
                border: '1px solid ' + t.separator, borderRadius: 12,
                fontFamily: SF_STACK, fontSize: 15, fontWeight: 700,
                cursor: 'pointer',
                appearance: 'none', WebkitAppearance: 'none', MozAppearance: 'none',
                backgroundImage: `url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='14' height='14' viewBox='0 0 24 24' fill='none' stroke='${encodeURIComponent(t.textSec)}' stroke-width='2.2' stroke-linecap='round' stroke-linejoin='round'><path d='M6 9l6 6 6-6'/></svg>")`,
                backgroundRepeat: 'no-repeat',
                backgroundPosition: 'right 10px center',
              }}>
                <option value="g">g</option>
                <option value="oz">oz</option>
                <option value="cups">cups</option>
                <option value="tbsp">tbsp</option>
                <option value="serving">serving</option>
                <option value="piece">piece</option>
              </select>
            </div>
            <div style={{ fontSize: 12, color: t.textSec, marginTop: 10 }}>
              Macros update live as you change the portion.
            </div>
          </div>
        </div>

        {/* Hunger rating */}
        <div style={{ padding: '14px 16px 0' }}>
          <HungerRating mode={mode} value={hunger} onChange={setHunger} />
        </div>

        {/* Nutrition details (expandable) */}
        <div style={{ padding: '14px 16px 0' }}>
          <EDExpander mode={mode} title="Nutrition details" defaultOpen>
            <div style={{ paddingTop: 6 }}>
              <NutriRow mode={mode} label="Fiber"          value={s(macros.fiber, 1)} unit="g" />
              <NutriRow mode={mode} label="Sugars"         value={s(macros.sugar, 1)} unit="g" />
              <NutriRow mode={mode} label="Saturated fat"  value={s(macros.sat, 1)}   unit="g" indent />
              <NutriRow mode={mode} label="Cholesterol"    value={s(macros.chol)}     unit="mg" />
              <NutriRow mode={mode} label="Sodium"         value={s(macros.sodium)}   unit="mg" />
            </div>
          </EDExpander>
        </div>

        {/* Micronutrients (expandable) */}
        <div style={{ padding: '14px 16px 0' }}>
          <EDExpander mode={mode} title="Micronutrients"
            right={
              <span style={{
                fontSize: 11, fontWeight: 700, color: t.textTer,
                letterSpacing: 0.4, textTransform: 'uppercase',
              }}>% Daily value</span>
            }
          >
            <div style={{ paddingTop: 6 }}>
              <DVBar mode={mode} label="Vitamin A"   pct={dv.vitA.pct} value={dv.vitA.v} />
              <DVBar mode={mode} label="Vitamin C"   pct={dv.vitC.pct} value={dv.vitC.v} color={t.carbs} />
              <DVBar mode={mode} label="Vitamin D"   pct={dv.vitD.pct} value={dv.vitD.v} color={t.warn} />
              <DVBar mode={mode} label="Vitamin B12" pct={dv.b12.pct}  value={dv.b12.v}  color={t.teal} />
              <DVBar mode={mode} label="Iron"        pct={dv.iron.pct} value={dv.iron.v} color={t.danger} />
              <DVBar mode={mode} label="Calcium"     pct={dv.calc.pct} value={dv.calc.v} />
            </div>
          </EDExpander>
        </div>

        {/* Delete */}
        <div style={{ padding: '24px 16px 36px' }}>
          <BCButton kind="destructive" size="lg" block>Delete entry</BCButton>
        </div>
      </div>
    </BCTheme>
  );
}

Object.assign(window, { EntryDetailScreen });
