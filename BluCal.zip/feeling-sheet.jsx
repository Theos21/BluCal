// feeling-sheet.jsx — "How are you feeling?" bottom sheet
// Three compact rating sections: hunger · energy · mood

function FLStatusBar({ mode }) {
  const c = mode === 'dark' ? '#fff' : '#000';
  return (
    <div style={{
      height: 54, padding: '14px 28px 0',
      display: 'flex', alignItems: 'center', justifyContent: 'space-between',
      fontSize: 17, fontWeight: 600, letterSpacing: -0.41, color: c, fontFamily: SF_STACK,
    }}>
      <span style={{ fontVariantNumeric: 'tabular-nums' }}>9:41</span>
      <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
        <svg width="18" height="11" viewBox="0 0 18 11">
          <rect x="0" y="7" width="3" height="4" rx="0.6" fill={c}/>
          <rect x="5" y="5" width="3" height="6" rx="0.6" fill={c}/>
          <rect x="10" y="3" width="3" height="8" rx="0.6" fill={c}/>
          <rect x="15" y="0" width="3" height="11" rx="0.6" fill={c}/>
        </svg>
        <svg width="26" height="12" viewBox="0 0 26 12">
          <rect x="0.5" y="0.5" width="22" height="11" rx="3" stroke={c} strokeOpacity="0.4" fill="none"/>
          <rect x="2" y="2" width="19" height="8" rx="1.5" fill={c}/>
          <rect x="23.5" y="4" width="1.5" height="4" rx="0.7" fill={c} fillOpacity="0.4"/>
        </svg>
      </div>
    </div>
  );
}

// ─── Stomach-fill icon (1→5 fullness) ────────────────────────────────
function StomachIcon({ level, size = 30, color = '#fff', strokeColor = 'currentColor' }) {
  // Bowl outline + a fill that grows with level (1..5)
  const fillPct = (level - 1) / 4; // 0 → 1
  return (
    <svg width={size} height={size} viewBox="0 0 32 32" fill="none">
      <defs>
        <clipPath id={`bowl-${level}`}>
          <path d="M 4 12 A 12 12 0 0 0 28 12 L 26 26 A 4 4 0 0 1 22 28 L 10 28 A 4 4 0 0 1 6 26 Z" />
        </clipPath>
      </defs>
      {/* fill */}
      <g clipPath={`url(#bowl-${level})`}>
        <rect x="0" y={28 - 16 * fillPct} width="32" height={16 * fillPct + 2} fill={color} />
      </g>
      {/* bowl outline */}
      <path d="M 4 12 A 12 12 0 0 0 28 12 L 26 26 A 4 4 0 0 1 22 28 L 10 28 A 4 4 0 0 1 6 26 Z"
        stroke={strokeColor} strokeWidth="1.8" strokeLinejoin="round" fill="none"/>
      {/* rim cap */}
      <path d="M 4 12 H 28" stroke={strokeColor} strokeWidth="1.8" strokeLinecap="round"/>
    </svg>
  );
}

// ─── Mood face icon ──────────────────────────────────────────────────
function MoodFace({ kind, size = 30, color = 'currentColor' }) {
  const s = { width: size, height: size, viewBox: '0 0 32 32', fill: 'none',
    stroke: color, strokeWidth: 1.8, strokeLinecap: 'round', strokeLinejoin: 'round' };
  const eyes = (<>
    <circle cx="11" cy="13" r="1.3" fill={color} stroke="none"/>
    <circle cx="21" cy="13" r="1.3" fill={color} stroke="none"/>
  </>);
  switch (kind) {
    case 'great':
      return (<svg {...s}>
        <circle cx="16" cy="16" r="12" />
        <path d="M 10 13 q 1 -2 3 0" /><path d="M 19 13 q 1 -2 3 0" />
        <path d="M 9 19 q 7 8 14 0" fill={color} />
      </svg>);
    case 'good':
      return (<svg {...s}>
        <circle cx="16" cy="16" r="12" />
        {eyes}
        <path d="M 10 20 q 6 5 12 0" />
      </svg>);
    case 'okay':
      return (<svg {...s}>
        <circle cx="16" cy="16" r="12" />
        {eyes}
        <path d="M 10 21 h 12" />
      </svg>);
    case 'low':
      return (<svg {...s}>
        <circle cx="16" cy="16" r="12" />
        {eyes}
        <path d="M 10 22 q 6 -5 12 0" />
      </svg>);
    case 'stressed':
      return (<svg {...s}>
        <circle cx="16" cy="16" r="12" />
        {/* squinty eyes */}
        <path d="M 9 13 l 4 1.5" /><path d="M 19 14.5 l 4 -1.5" />
        <path d="M 10 21 q 6 -3 12 0" />
        <path d="M 12 7 l 1.5 2 M 19 7 l -1.5 2" />
      </svg>);
  }
  return null;
}

// ─── Pickable cell ───────────────────────────────────────────────────
function PickCell({ mode, active, children, onClick, label }) {
  const t = mode === 'dark' ? BC_DARK : BC_LIGHT;
  return (
    <button onClick={onClick} style={{
      flex: 1, padding: 0, border: 'none', background: 'transparent',
      cursor: 'pointer', display: 'flex', flexDirection: 'column',
      alignItems: 'center', gap: 6, fontFamily: SF_STACK,
      WebkitTapHighlightColor: 'transparent',
    }}>
      <div style={{
        width: 52, height: 52, borderRadius: 14,
        background: active ? t.primary : t.surface2,
        border: active ? '1px solid ' + t.primary : '1px solid ' + t.separator,
        color: active ? '#fff' : t.text,
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        transition: 'background .12s',
      }}>
        {children}
      </div>
      <span style={{ fontSize: 10, fontWeight: 700, color: active ? t.primary : t.textTer, letterSpacing: 0.2 }}>
        {label}
      </span>
    </button>
  );
}

// ─── The sheet ───────────────────────────────────────────────────────
function FeelingSheet({ mode, onClose }) {
  const t = mode === 'dark' ? BC_DARK : BC_LIGHT;
  const [hunger, setHunger] = React.useState(3);
  const [energy, setEnergy] = React.useState(4);
  const [mood, setMood]     = React.useState('good');

  const hungerLabels = ['Empty', 'Hungry', 'Some', 'Satisfied', 'Stuffed'];
  const energyLabels = ['Exhausted', 'Tired',   'OK',      'Good',    'Great'];
  const moods = [
    { k: 'great',    label: 'Great'   },
    { k: 'good',     label: 'Good'    },
    { k: 'okay',     label: 'Okay'    },
    { k: 'low',      label: 'Low'     },
    { k: 'stressed', label: 'Stressed'},
  ];

  return (
    <>
      <div onClick={onClose} style={{
        position: 'absolute', inset: 0, background: t.scrim, zIndex: 20, backdropFilter: 'blur(2px)',
      }} />
      <div style={{
        position: 'absolute', left: 0, right: 0, bottom: 0, zIndex: 21,
        background: t.surface,
        borderTopLeftRadius: 24, borderTopRightRadius: 24,
        boxShadow: '0 -10px 40px rgba(0,0,0,0.30)',
        padding: '8px 20px 26px',
      }}>
        <div style={{ display: 'flex', justifyContent: 'center', padding: '4px 0 10px' }}>
          <div style={{ width: 38, height: 5, borderRadius: 999, background: t.hairline }} />
        </div>

        <div style={{ textAlign: 'center', marginBottom: 4 }}>
          <div style={{ fontSize: 19, fontWeight: 800, color: t.text, letterSpacing: -0.3 }}>How are you feeling?</div>
          <div style={{ fontSize: 13, color: t.textSec, marginTop: 4 }}>
            Three quick ratings help your coach learn what's working.
          </div>
        </div>

        {/* Hunger */}
        <div style={{ marginTop: 18 }}>
          <div style={{
            display: 'flex', alignItems: 'baseline', justifyContent: 'space-between', marginBottom: 8,
          }}>
            <span style={{ fontSize: 12, fontWeight: 700, color: t.text, letterSpacing: -0.1 }}>Hunger right now</span>
            <span style={{ fontSize: 12, fontWeight: 700, color: t.primary }}>{hungerLabels[hunger - 1]}</span>
          </div>
          <div style={{ display: 'flex', gap: 8 }}>
            {[1, 2, 3, 4, 5].map(n => (
              <PickCell key={n} mode={mode} active={hunger === n} onClick={() => setHunger(n)} label={n}>
                <StomachIcon level={n} size={28} color={hunger === n ? '#fff' : t.primary} strokeColor={hunger === n ? '#fff' : t.text} />
              </PickCell>
            ))}
          </div>
        </div>

        {/* Energy */}
        <div style={{ marginTop: 16 }}>
          <div style={{
            display: 'flex', alignItems: 'baseline', justifyContent: 'space-between', marginBottom: 8,
          }}>
            <span style={{ fontSize: 12, fontWeight: 700, color: t.text, letterSpacing: -0.1 }}>Energy level</span>
            <span style={{ fontSize: 12, fontWeight: 700, color: t.primary }}>{energyLabels[energy - 1]}</span>
          </div>
          <div style={{ display: 'flex', gap: 8 }}>
            {[1, 2, 3, 4, 5].map(n => (
              <PickCell key={n} mode={mode} active={energy === n} onClick={() => setEnergy(n)} label={n}>
                {/* dot scale — n filled dots stacked horizontally */}
                <span style={{ display: 'inline-flex', gap: 3 }}>
                  {[1, 2, 3, 4, 5].map(i => (
                    <span key={i} style={{
                      width: 5, height: 5, borderRadius: 999,
                      background: i <= n ? (energy === n ? '#fff' : t.primary) : (energy === n ? 'rgba(255,255,255,0.4)' : t.hairline),
                    }} />
                  ))}
                </span>
              </PickCell>
            ))}
          </div>
        </div>

        {/* Mood */}
        <div style={{ marginTop: 16 }}>
          <div style={{
            display: 'flex', alignItems: 'baseline', justifyContent: 'space-between', marginBottom: 8,
          }}>
            <span style={{ fontSize: 12, fontWeight: 700, color: t.text, letterSpacing: -0.1 }}>
              Mood <span style={{ color: t.textTer, fontWeight: 600, marginLeft: 4 }}>· optional</span>
            </span>
            <span style={{ fontSize: 12, fontWeight: 700, color: t.primary, textTransform: 'capitalize' }}>
              {mood && (moods.find(m => m.k === mood)?.label)}
            </span>
          </div>
          <div style={{ display: 'flex', gap: 8 }}>
            {moods.map(m => (
              <PickCell key={m.k} mode={mode} active={mood === m.k} onClick={() => setMood(m.k)} label={m.label}>
                <MoodFace kind={m.k} size={30} color={mood === m.k ? '#fff' : t.text} />
              </PickCell>
            ))}
          </div>
        </div>

        {/* CTAs */}
        <div style={{ marginTop: 22, display: 'flex', gap: 10 }}>
          <BCButton kind="secondary" size="lg" style={{ flex: 1 }} onClick={onClose}>Skip</BCButton>
          <BCButton kind="primary" size="lg" style={{ flex: 1.5 }} onClick={onClose}>Save</BCButton>
        </div>
      </div>
    </>
  );
}

// ─── Background host ─────────────────────────────────────────────────
function FeelingHost({ mode = 'light' }) {
  const t = mode === 'dark' ? BC_DARK : BC_LIGHT;
  return (
    <BCTheme mode={mode} padding={0} style={{ position: 'relative', overflow: 'hidden', height: '100%' }}>
      <FLStatusBar mode={mode} />
      {/* Faux background — Today fragment */}
      <div style={{ padding: '8px 20px 0', opacity: 0.95 }}>
        <div style={{ fontSize: 34, fontWeight: 800, color: t.text, letterSpacing: -0.8, lineHeight: '41px' }}>Today</div>
        <div style={{ fontSize: 14, color: t.textSec, marginTop: 2, fontWeight: 500 }}>Tuesday, May 13</div>
        <div style={{
          marginTop: 16, padding: '14px 16px',
          background: t.surface, border: '1px solid ' + t.separator, borderRadius: 16,
          opacity: 0.7,
        }}>
          <div style={{ fontSize: 11, fontWeight: 700, color: t.textTer, letterSpacing: 0.6, textTransform: 'uppercase' }}>
            Just logged
          </div>
          <div style={{ fontSize: 15, fontWeight: 700, color: t.text, marginTop: 4 }}>Chipotle bowl · 715 kcal</div>
        </div>
      </div>
      <FeelingSheet mode={mode} onClose={() => {}} />
    </BCTheme>
  );
}

Object.assign(window, { FeelingSheet, FeelingHost });
