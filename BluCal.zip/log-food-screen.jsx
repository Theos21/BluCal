// log-food-screen.jsx — Log food search modal
// Two states managed by `query` prop / local state:
//   idle    → quick actions + recents/my foods/my recipes sections
//   search  → flat results list (name + brand + serving + kcal + add)

// ─── Status bar (reuse layout from other screens) ─────────────────────

function LFStatusBar({ mode }) {
  const c = mode === 'dark' ? '#fff' : '#000';
  return (
    <div style={{
      height: 54, padding: '14px 28px 0',
      display: 'flex', alignItems: 'center', justifyContent: 'space-between',
      fontSize: 17, fontWeight: 600, letterSpacing: -0.41, color: c,
      fontFamily: SF_STACK,
    }}>
      <span style={{ fontVariantNumeric: 'tabular-nums' }}>9:41</span>
      <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
        <svg width="18" height="11" viewBox="0 0 18 11">
          <rect x="0" y="7" width="3" height="4" rx="0.6" fill={c}/>
          <rect x="5" y="5" width="3" height="6" rx="0.6" fill={c}/>
          <rect x="10" y="3" width="3" height="8" rx="0.6" fill={c}/>
          <rect x="15" y="0" width="3" height="11" rx="0.6" fill={c}/>
        </svg>
        <svg width="26" height="12" viewBox="0 0 26 12">
          <rect x="0.5" y="0.5" width="22" height="11" rx="3" stroke={c} strokeOpacity="0.4" fill="none"/>
          <rect x="2" y="2" width="19" height="8" rx="1.5" fill={c}/>
          <rect x="23.5" y="4" width="1.5" height="4" rx="0.7" fill={c} fillOpacity="0.4"/>
        </svg>
      </div>
    </div>
  );
}

// ─── Photo AI camera + sparkle inline SVG ──────────────────────────────
function PhotoAIIcon({ size = 22, color = 'currentColor' }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none">
      <path d="M3 8a2 2 0 0 1 2-2h2l1.5-2h7L17 6h2a2 2 0 0 1 2 2v9a2 2 0 0 1-2 2h-7"
        stroke={color} strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"/>
      <circle cx="14" cy="13" r="3.5" stroke={color} strokeWidth="1.8"/>
      {/* sparkle */}
      <path d="M5.5 16.5l.6 1.4 1.4.6-1.4.6-.6 1.4-.6-1.4-1.4-.6 1.4-.6z"
        fill={color}/>
    </svg>
  );
}

// ─── Header ────────────────────────────────────────────────────────────
function LFHeader({ mode, onDismiss }) {
  const t = mode === 'dark' ? BC_DARK : BC_LIGHT;
  return (
    <div style={{
      height: 56, padding: '0 16px',
      display: 'flex', alignItems: 'center',
      borderBottom: '0.5px solid ' + t.separator,
      background: t.bg,
      position: 'relative',
    }}>
      <button onClick={onDismiss} style={{
        width: 32, height: 32, borderRadius: 999,
        background: t.surface2, border: 'none',
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        cursor: 'pointer', WebkitTapHighlightColor: 'transparent',
        position: 'relative', zIndex: 1,
      }}>
        <BCIcon name="close" size={16} color={t.text} strokeWidth={2.2} />
      </button>
      <div style={{
        position: 'absolute', inset: 0,
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        pointerEvents: 'none',
        fontSize: 17, fontWeight: 600, letterSpacing: -0.41, color: t.text,
        lineHeight: '22px',
      }}>Log food</div>
    </div>
  );
}

// ─── Search bar ────────────────────────────────────────────────────────
function LFSearchBar({ mode, query, setQuery, focused, setFocused }) {
  const t = mode === 'dark' ? BC_DARK : BC_LIGHT;
  return (
    <div style={{
      display: 'flex', alignItems: 'center', gap: 8,
      height: 44, padding: '0 12px',
      background: t.surface2, borderRadius: 12,
      border: focused ? `2px solid ${t.primary}` : '2px solid transparent',
    }}>
      <BCIcon name="search" size={18} color={t.textTer} />
      <input
        value={query}
        onChange={e => setQuery(e.target.value)}
        onFocus={() => setFocused(true)}
        onBlur={() => setFocused(false)}
        placeholder="Search foods, brands or restaurants"
        style={{
          flex: 1, minWidth: 0,
          background: 'transparent', border: 'none', outline: 'none',
          color: t.text, fontSize: 16, fontFamily: SF_STACK, letterSpacing: -0.32,
        }}
      />
      {query ? (
        <button onClick={() => setQuery('')} style={{
          width: 22, height: 22, borderRadius: 999, background: t.hairline,
          color: t.bg, border: 'none', display: 'flex',
          alignItems: 'center', justifyContent: 'center', cursor: 'pointer', padding: 0,
        }}>
          <BCIcon name="close" size={12} color={t.textSec} strokeWidth={2.4} />
        </button>
      ) : (
        <>
          <button style={{
            width: 28, height: 28, background: 'transparent', border: 'none', cursor: 'pointer',
            display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 0,
          }}>
            <BCIcon name="barcode" size={20} color={t.textSec} />
          </button>
          <div style={{ width: 1, height: 18, background: t.separator }} />
          <button style={{
            width: 28, height: 28, background: 'transparent', border: 'none', cursor: 'pointer',
            display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 0,
          }}>
            <BCIcon name="mic" size={18} color={t.textSec} />
          </button>
        </>
      )}
    </div>
  );
}

// ─── Quick action card (scan barcode / photo AI) ───────────────────────
function LFQuickCard({ mode, icon, label, sub, accent }) {
  const t = mode === 'dark' ? BC_DARK : BC_LIGHT;
  return (
    <button style={{
      flex: 1, padding: 14,
      background: t.surface, border: '1px solid ' + t.separator, borderRadius: BC_RADIUS.lg,
      display: 'flex', flexDirection: 'column', gap: 10,
      cursor: 'pointer', textAlign: 'left',
      fontFamily: SF_STACK,
      WebkitTapHighlightColor: 'transparent',
    }}>
      <div style={{
        width: 36, height: 36, borderRadius: 10,
        background: accent === 'teal' ? t.tealSoft : t.primarySoft,
        color: accent === 'teal' ? t.teal : t.primary,
        display: 'flex', alignItems: 'center', justifyContent: 'center',
      }}>{icon}</div>
      <div>
        <div style={{ fontSize: 15, fontWeight: 700, color: t.text, letterSpacing: -0.2 }}>{label}</div>
        <div style={{ fontSize: 12, color: t.textSec, marginTop: 1, letterSpacing: -0.1 }}>{sub}</div>
      </div>
    </button>
  );
}

// ─── Food row (Recents / My foods / My recipes) ────────────────────────
function LFFoodRow({ mode, name, kcal, p, c, f, sub, divider }) {
  const t = mode === 'dark' ? BC_DARK : BC_LIGHT;
  return (
    <div style={{
      display: 'flex', alignItems: 'center', gap: 12,
      padding: '12px 0',
      borderBottom: divider ? '0.5px solid ' + t.separator : 'none',
    }}>
      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{
          fontSize: 15, fontWeight: 600, color: t.text, letterSpacing: -0.24,
          whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis',
        }}>{name}</div>
        <div style={{
          fontSize: 12, color: t.textSec, marginTop: 2, display: 'flex', alignItems: 'center', gap: 8,
          whiteSpace: 'nowrap', overflow: 'hidden',
          fontVariantNumeric: 'tabular-nums',
        }}>
          <span style={{ fontWeight: 700, color: t.text }}>{kcal}</span>
          <span style={{ color: t.textTer }}>kcal</span>
          <span style={{ color: t.textTer, opacity: 0.5 }}>·</span>
          {sub ? (
            <span style={{ whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{sub}</span>
          ) : (
            <span style={{ fontFamily: 'ui-monospace, SFMono-Regular, Menlo, monospace', fontSize: 11 }}>
              <span style={{ color: t.protein, fontWeight: 600 }}>{p}p</span>
              <span style={{ margin: '0 3px', opacity: 0.4 }}>·</span>
              <span style={{ color: t.carbs, fontWeight: 600 }}>{c}c</span>
              <span style={{ margin: '0 3px', opacity: 0.4 }}>·</span>
              <span style={{ color: t.fat, fontWeight: 600 }}>{f}f</span>
            </span>
          )}
        </div>
      </div>
      <button style={{
        width: 32, height: 32, borderRadius: 999,
        background: t.primary, color: '#fff', border: 'none',
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        cursor: 'pointer', flexShrink: 0,
        boxShadow: '0 2px 6px rgba(24,95,165,0.30)',
      }}>
        <BCIcon name="plus" size={18} color="#fff" strokeWidth={2.6} />
      </button>
    </div>
  );
}

// ─── Section header w/ "See all" ───────────────────────────────────────
function LFSection({ mode, label, count, children }) {
  const t = mode === 'dark' ? BC_DARK : BC_LIGHT;
  return (
    <div style={{ paddingTop: 18 }}>
      <div style={{ display: 'flex', alignItems: 'center', padding: '0 0 6px' }}>
        <div style={{ flex: 1, display: 'flex', alignItems: 'baseline', gap: 8 }}>
          <span style={{
            fontSize: 11, fontWeight: 700, letterSpacing: 0.8, textTransform: 'uppercase',
            color: t.textTer,
          }}>{label}</span>
          {count != null && (
            <span style={{
              fontSize: 11, fontWeight: 600, color: t.textTer,
              fontVariantNumeric: 'tabular-nums', opacity: 0.7,
            }}>{count}</span>
          )}
        </div>
        <span style={{ fontSize: 13, fontWeight: 600, color: t.primary, letterSpacing: -0.1 }}>See all</span>
      </div>
      {children}
    </div>
  );
}

// ─── Result row (active search state) ──────────────────────────────────
function LFResultRow({ mode, name, brand, serving, kcal, highlight, divider, badge }) {
  const t = mode === 'dark' ? BC_DARK : BC_LIGHT;
  // Bold-highlight the matched substring inline
  const renderName = () => {
    if (!highlight) return name;
    const idx = name.toLowerCase().indexOf(highlight.toLowerCase());
    if (idx < 0) return name;
    return (
      <>
        {name.slice(0, idx)}
        <span style={{ background: t.primarySoft, color: t.primary, fontWeight: 700, borderRadius: 3 }}>
          {name.slice(idx, idx + highlight.length)}
        </span>
        {name.slice(idx + highlight.length)}
      </>
    );
  };
  return (
    <div style={{
      display: 'flex', alignItems: 'center', gap: 12,
      padding: '12px 0',
      borderBottom: divider ? '0.5px solid ' + t.separator : 'none',
    }}>
      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{
          fontSize: 15, fontWeight: 600, color: t.text, letterSpacing: -0.24,
          display: 'flex', alignItems: 'center', gap: 8,
          whiteSpace: 'nowrap', overflow: 'hidden',
        }}>
          <span style={{ overflow: 'hidden', textOverflow: 'ellipsis', minWidth: 0 }}>{renderName()}</span>
          {badge && (
            <span style={{
              fontSize: 10, fontWeight: 700, letterSpacing: 0.4, textTransform: 'uppercase',
              padding: '2px 6px', borderRadius: 4,
              background: t.tealSoft, color: t.teal, flexShrink: 0,
            }}>{badge}</span>
          )}
        </div>
        <div style={{
          fontSize: 12, color: t.textSec, marginTop: 2,
          whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis',
        }}>
          <span style={{ fontWeight: 500 }}>{brand}</span>
          {brand && <span style={{ opacity: 0.4, margin: '0 6px' }}>·</span>}
          {serving}
        </div>
      </div>
      <div style={{ textAlign: 'right', flexShrink: 0 }}>
        <div style={{ fontSize: 15, fontWeight: 700, color: t.text, letterSpacing: -0.24, fontVariantNumeric: 'tabular-nums' }}>
          {kcal}
        </div>
        <div style={{ fontSize: 10, color: t.textTer, marginTop: 1, fontWeight: 600, letterSpacing: 0.3, textTransform: 'uppercase' }}>kcal</div>
      </div>
      <button style={{
        width: 32, height: 32, borderRadius: 999,
        background: t.primary, color: '#fff', border: 'none',
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        cursor: 'pointer', flexShrink: 0,
        boxShadow: '0 2px 6px rgba(24,95,165,0.30)',
      }}>
        <BCIcon name="plus" size={18} color="#fff" strokeWidth={2.6} />
      </button>
    </div>
  );
}

// ─── Data ──────────────────────────────────────────────────────────────
const LF_RECENTS = [
  { name: 'Greek yogurt + granola', kcal: 322, p: 18, c: 42, f: 8 },
  { name: 'Oat milk latte',          kcal: 110, p: 4,  c: 15, f: 3 },
  { name: 'Chipotle bowl',           kcal: 715, p: 56, c: 52, f: 22 },
  { name: 'Apple + peanut butter',   kcal: 280, p: 8,  c: 30, f: 16 },
];
const LF_MYFOODS = [
  { name: 'My protein shake',     kcal: 280, p: 35, c: 18, f: 6 },
  { name: 'My Sunday omelette',   kcal: 420, p: 28, c: 4,  f: 32 },
  { name: 'Backyard salad',       kcal: 165, p: 5,  c: 18, f: 9 },
];
const LF_RECIPES = [
  { name: 'Chicken pesto pasta',  kcal: 540, p: 38, c: 56, f: 18, sub: '6 servings · 25 min' },
  { name: 'Sheet-pan salmon',     kcal: 480, p: 42, c: 14, f: 28, sub: '4 servings · 30 min' },
  { name: 'Overnight oats',       kcal: 360, p: 14, c: 52, f: 10, sub: '1 serving · 5 min + chill' },
];
const LF_RESULTS = [
  { name: 'Chipotle Chicken Bowl',          brand: 'Chipotle',         serving: '1 bowl',     kcal: 715, badge: null },
  { name: 'Grilled chicken breast',         brand: 'Generic',          serving: '4 oz · cooked', kcal: 165, badge: null },
  { name: 'Chicken Caesar salad',           brand: 'Sweetgreen',       serving: '1 salad',    kcal: 470, badge: null },
  { name: 'Chick-fil-A Grilled Sandwich',   brand: 'Chick-fil-A',      serving: '1 sandwich', kcal: 380, badge: null },
  { name: 'Chicken & brown rice bowl',      brand: 'Trader Joe\'s',    serving: '1 bowl',     kcal: 480, badge: 'High protein' },
  { name: 'Chicken thigh, baked',           brand: 'Generic',          serving: '6 oz',       kcal: 280, badge: null },
  { name: 'Chicken noodle soup',            brand: 'Campbell\'s',      serving: '1 cup',      kcal: 60,  badge: null },
  { name: 'Chickpeas, canned',              brand: 'Generic',          serving: '½ cup',      kcal: 110, badge: null },
];

// ─── Screen ────────────────────────────────────────────────────────────
function LogFoodScreen({ mode, initialQuery = '', onDismiss }) {
  const [query, setQuery] = React.useState(initialQuery);
  const [focused, setFocused] = React.useState(!!initialQuery);
  // Re-sync if the host re-mounts us with a different initialQuery (e.g.
  // focus-mode overlay rendering the same element in a fresh React tree).
  React.useEffect(() => { setQuery(initialQuery); }, [initialQuery]);
  const t = mode === 'dark' ? BC_DARK : BC_LIGHT;
  const searching = query.length > 0;

  // Filter results by query — case-insensitive substring on name or brand.
  const results = LF_RESULTS.filter(r =>
    r.name.toLowerCase().includes(query.toLowerCase()) ||
    r.brand.toLowerCase().includes(query.toLowerCase())
  );

  return (
    <BCTheme mode={mode} padding={0} style={{ position: 'relative', overflow: 'hidden', height: '100%' }}>
      <LFStatusBar mode={mode} />
      <LFHeader mode={mode} onDismiss={onDismiss} />

      <div style={{
        position: 'absolute', top: 54 + 56, left: 0, right: 0, bottom: 0,
        overflowY: 'auto',
      }}>
        {/* Search bar — sticky-feel */}
        <div style={{ padding: '14px 16px 4px', background: t.bg }}>
          <LFSearchBar mode={mode} query={query} setQuery={setQuery} focused={focused} setFocused={setFocused} />
        </div>

        {/* Quick actions — hide when searching */}
        {!searching && (
          <div style={{ padding: '14px 16px 0' }}>
            <HStack gap={10} align="stretch">
              <LFQuickCard mode={mode} icon={<BCIcon name="barcode" size={20} />} label="Scan barcode" sub="Packaged foods" />
              <LFQuickCard mode={mode} icon={<PhotoAIIcon size={22} />} label="Photo AI" sub="Snap a meal" accent="teal" />
            </HStack>
          </div>
        )}

        {/* Sections OR results */}
        {!searching ? (
          <div style={{ padding: '0 16px 24px' }}>
            <LFSection mode={mode} label="Recents" count={LF_RECENTS.length}>
              {LF_RECENTS.map((r, i) => (
                <LFFoodRow key={r.name} mode={mode} {...r} divider={i < LF_RECENTS.length - 1} />
              ))}
            </LFSection>
            <LFSection mode={mode} label="My foods" count={LF_MYFOODS.length}>
              {LF_MYFOODS.map((r, i) => (
                <LFFoodRow key={r.name} mode={mode} {...r} divider={i < LF_MYFOODS.length - 1} />
              ))}
            </LFSection>
            <LFSection mode={mode} label="My recipes" count={LF_RECIPES.length}>
              {LF_RECIPES.map((r, i) => (
                <LFFoodRow key={r.name} mode={mode} {...r} divider={i < LF_RECIPES.length - 1} />
              ))}
            </LFSection>
          </div>
        ) : (
          <div style={{ padding: '14px 16px 24px' }}>
            <div style={{
              fontSize: 11, fontWeight: 700, letterSpacing: 0.8, textTransform: 'uppercase',
              color: t.textTer, marginBottom: 6,
            }}>
              {results.length} result{results.length === 1 ? '' : 's'} for "{query}"
            </div>
            {results.map((r, i) => (
              <LFResultRow key={r.name} mode={mode} {...r}
                highlight={query}
                divider={i < results.length - 1}
              />
            ))}
            {results.length === 0 && (
              <div style={{
                padding: '40px 20px', textAlign: 'center',
                background: t.surface, border: '1px solid ' + t.separator,
                borderRadius: BC_RADIUS.md,
                marginTop: 8,
              }}>
                <div style={{ fontSize: 15, fontWeight: 700, color: t.text }}>No matches</div>
                <div style={{ fontSize: 13, color: t.textSec, marginTop: 4 }}>
                  Try a barcode scan, or create a custom food.
                </div>
              </div>
            )}
          </div>
        )}
      </div>
    </BCTheme>
  );
}

Object.assign(window, { LogFoodScreen });
