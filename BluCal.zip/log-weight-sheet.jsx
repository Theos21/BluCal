// log-weight-sheet.jsx — Log weight bottom sheet modal

function LWStatusBar({ mode }) {
  const c = mode === 'dark' ? '#fff' : '#000';
  return (
    <div style={{
      height: 54, padding: '14px 28px 0',
      display: 'flex', alignItems: 'center', justifyContent: 'space-between',
      fontSize: 17, fontWeight: 600, letterSpacing: -0.41, color: c,
      fontFamily: SF_STACK,
    }}>
      <span style={{ fontVariantNumeric: 'tabular-nums' }}>9:41</span>
      <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
        <svg width="18" height="11" viewBox="0 0 18 11">
          <rect x="0" y="7" width="3" height="4" rx="0.6" fill={c}/>
          <rect x="5" y="5" width="3" height="6" rx="0.6" fill={c}/>
          <rect x="10" y="3" width="3" height="8" rx="0.6" fill={c}/>
          <rect x="15" y="0" width="3" height="11" rx="0.6" fill={c}/>
        </svg>
        <svg width="26" height="12" viewBox="0 0 26 12">
          <rect x="0.5" y="0.5" width="22" height="11" rx="3" stroke={c} strokeOpacity="0.4" fill="none"/>
          <rect x="2" y="2" width="19" height="8" rx="1.5" fill={c}/>
          <rect x="23.5" y="4" width="1.5" height="4" rx="0.7" fill={c} fillOpacity="0.4"/>
        </svg>
      </div>
    </div>
  );
}

// 7-day sparkline
const WEIGHT_7D = [179.0, 178.8, 179.1, 178.5, 178.2, 178.0, 177.7];
const WEIGHT_DAYS = ['W', 'T', 'F', 'S', 'S', 'M', 'T'];

function WeightSparkline({ mode, todayValue }) {
  const t = mode === 'dark' ? BC_DARK : BC_LIGHT;
  const W = 320, H = 80, PADX = 8, PADY = 10;
  const data = WEIGHT_7D.slice(0, -1).concat([todayValue]);
  const min = Math.min(...data) - 0.5;
  const max = Math.max(...data) + 0.5;
  const x = (i) => PADX + (i / (data.length - 1)) * (W - 2 * PADX);
  const y = (v) => PADY + (1 - (v - min) / (max - min)) * (H - 2 * PADY);
  const path = data.map((v, i) => `${i === 0 ? 'M' : 'L'} ${x(i).toFixed(1)} ${y(v).toFixed(1)}`).join(' ');
  const areaPath = `${path} L ${x(data.length - 1)} ${H - PADY} L ${x(0)} ${H - PADY} Z`;
  return (
    <div>
      <svg width="100%" viewBox={`0 0 ${W} ${H}`} preserveAspectRatio="none" style={{ display: 'block', overflow: 'visible' }}>
        <path d={areaPath} fill={t.primarySoft} />
        <path d={path} fill="none" stroke={t.primary} strokeWidth="2.4" strokeLinejoin="round" strokeLinecap="round" />
        {data.map((v, i) => {
          const last = i === data.length - 1;
          return (
            <g key={i}>
              {last && <circle cx={x(i)} cy={y(v)} r="9" fill={t.primary} opacity="0.18" />}
              <circle cx={x(i)} cy={y(v)} r={last ? 4.5 : 2.4}
                fill={last ? t.primary : t.surface}
                stroke={t.primary} strokeWidth={last ? 0 : 1.6} />
            </g>
          );
        })}
      </svg>
      <div style={{ display: 'flex', justifyContent: 'space-between', padding: '4px 4px 0', fontSize: 10, color: t.textTer, fontWeight: 600 }}>
        {WEIGHT_DAYS.map((d, i) => (
          <span key={i} style={{ color: i === WEIGHT_DAYS.length - 1 ? t.primary : t.textTer, fontWeight: i === WEIGHT_DAYS.length - 1 ? 800 : 600 }}>
            {d}
          </span>
        ))}
      </div>
    </div>
  );
}

// ─── Sheet ────────────────────────────────────────────────────────────
function LogWeightSheet({ mode, onClose }) {
  const t = mode === 'dark' ? BC_DARK : BC_LIGHT;
  const [weight, setWeight] = React.useState(177.7);
  const [unit, setUnit] = React.useState('lbs');
  const [note, setNote] = React.useState('');
  const dateStr = 'Today · 9:41 AM';

  return (
    <>
      <div onClick={onClose} style={{
        position: 'absolute', inset: 0, background: t.scrim, zIndex: 20,
        backdropFilter: 'blur(2px)',
      }} />
      <div style={{
        position: 'absolute', left: 0, right: 0, bottom: 0, zIndex: 21,
        background: t.surface,
        borderTopLeftRadius: 24, borderTopRightRadius: 24,
        boxShadow: '0 -10px 40px rgba(0,0,0,0.30)',
        padding: '8px 20px 26px',
      }}>
        {/* Grabber */}
        <div style={{ display: 'flex', justifyContent: 'center', padding: '4px 0 10px' }}>
          <div style={{ width: 38, height: 5, borderRadius: 999, background: t.hairline }} />
        </div>

        {/* Title */}
        <div style={{ textAlign: 'center', marginBottom: 6 }}>
          <div style={{ fontSize: 17, fontWeight: 700, color: t.text, letterSpacing: -0.3 }}>Log weight</div>
        </div>

        {/* Big weight + unit toggle */}
        <div style={{
          marginTop: 18,
          display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 14,
        }}>
          <div style={{ display: 'flex', alignItems: 'baseline', gap: 8 }}>
            <button onClick={() => setWeight(w => +(w - 0.1).toFixed(1))} style={{
              width: 38, height: 38, borderRadius: 999, border: 'none',
              background: t.surface2, color: t.text, fontSize: 22, cursor: 'pointer',
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              alignSelf: 'center',
            }}>−</button>
            <input
              value={weight}
              onChange={(e) => {
                const v = parseFloat(e.target.value);
                if (!isNaN(v)) setWeight(v);
              }}
              style={{
                width: 160, background: 'transparent', border: 'none', outline: 'none',
                fontSize: 64, fontWeight: 800, color: t.text, textAlign: 'center',
                letterSpacing: -1.5, fontVariantNumeric: 'tabular-nums',
                fontFamily: SF_STACK,
              }}
            />
            <button onClick={() => setWeight(w => +(w + 0.1).toFixed(1))} style={{
              width: 38, height: 38, borderRadius: 999, border: 'none',
              background: t.surface2, color: t.text, fontSize: 22, cursor: 'pointer',
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              alignSelf: 'center',
            }}>+</button>
          </div>
          {/* Unit toggle */}
          <div style={{
            display: 'inline-flex', padding: 3,
            background: t.surface2, borderRadius: 999, height: 32,
          }}>
            {['lbs', 'kg'].map(u => (
              <button key={u} onClick={() => setUnit(u)} style={{
                padding: '0 18px', height: 26, borderRadius: 999, border: 'none',
                background: unit === u ? t.surface : 'transparent',
                color: t.text, fontSize: 13, fontWeight: unit === u ? 700 : 500,
                boxShadow: unit === u ? '0 1px 2px rgba(0,0,0,0.08)' : 'none',
                cursor: 'pointer', fontFamily: SF_STACK,
              }}>{u}</button>
            ))}
          </div>
        </div>

        {/* Date / Note */}
        <div style={{ marginTop: 22 }}>
          <div style={{
            background: t.surface, border: '1px solid ' + t.separator,
            borderTopLeftRadius: BC_RADIUS.md, borderTopRightRadius: BC_RADIUS.md,
            borderBottom: '0.5px solid ' + t.separator,
            padding: '12px 14px',
            display: 'flex', alignItems: 'center', gap: 10, cursor: 'pointer',
          }}>
            <BCIcon name="check" size={14} color={t.primary} style={{ display: 'none' }} />
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke={t.textSec} strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
              <rect x="3" y="5" width="18" height="16" rx="2"/>
              <path d="M3 9h18M8 3v4M16 3v4"/>
            </svg>
            <div style={{ flex: 1, fontSize: 15, fontWeight: 600, color: t.text, letterSpacing: -0.2 }}>{dateStr}</div>
            <BCIcon name="chev" size={14} color={t.textTer} />
          </div>
          <div style={{
            background: t.surface, border: '1px solid ' + t.separator, borderTop: 'none',
            borderBottomLeftRadius: BC_RADIUS.md, borderBottomRightRadius: BC_RADIUS.md,
            padding: '12px 14px',
            display: 'flex', alignItems: 'center', gap: 10,
          }}>
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke={t.textSec} strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
              <path d="M4 5h16M4 11h16M4 17h10"/>
            </svg>
            <input
              value={note}
              onChange={(e) => setNote(e.target.value)}
              placeholder="Add a note…"
              style={{
                flex: 1, background: 'transparent', border: 'none', outline: 'none',
                fontSize: 15, color: t.text, fontFamily: SF_STACK, letterSpacing: -0.2,
              }}
            />
          </div>
        </div>

        {/* CTA */}
        <div style={{ marginTop: 14 }}>
          <BCButton kind="primary" size="lg" block onClick={onClose}>Log weight</BCButton>
        </div>

        {/* 7-day sparkline */}
        <div style={{ marginTop: 18 }}>
          <div style={{
            display: 'flex', alignItems: 'baseline', justifyContent: 'space-between',
            marginBottom: 4,
          }}>
            <span style={{ fontSize: 11, fontWeight: 700, color: t.textTer, letterSpacing: 0.6, textTransform: 'uppercase' }}>
              Last 7 days
            </span>
            <span style={{ fontSize: 12, color: t.success, fontWeight: 700, fontVariantNumeric: 'tabular-nums' }}>
              −1.3 lbs this week
            </span>
          </div>
          <WeightSparkline mode={mode} todayValue={weight} />
        </div>
      </div>
    </>
  );
}

// ─── Background / wrapper ─────────────────────────────────────────────
function LogWeightHost({ mode = 'light' }) {
  const t = mode === 'dark' ? BC_DARK : BC_LIGHT;
  return (
    <BCTheme mode={mode} padding={0} style={{ position: 'relative', overflow: 'hidden', height: '100%' }}>
      <LWStatusBar mode={mode} />
      {/* Faux background — Today header preview */}
      <div style={{
        padding: '8px 20px 0',
        filter: 'blur(0.5px)',
        opacity: 0.95,
      }}>
        <div style={{ fontSize: 34, fontWeight: 800, color: t.text, letterSpacing: -0.8, lineHeight: '41px' }}>Profile</div>
        <div style={{ fontSize: 14, color: t.textSec, marginTop: 2, fontWeight: 500 }}>Weight & body</div>
        <div style={{
          marginTop: 16, padding: '16px 18px',
          background: t.surface, border: '1px solid ' + t.separator, borderRadius: 16,
        }}>
          <div style={{ fontSize: 11, fontWeight: 700, color: t.textTer, letterSpacing: 0.6, textTransform: 'uppercase' }}>Current weight</div>
          <div style={{ display: 'flex', alignItems: 'baseline', gap: 5, marginTop: 4 }}>
            <span style={{ fontSize: 36, fontWeight: 800, color: t.text, letterSpacing: -0.8, lineHeight: 1 }}>177.7</span>
            <span style={{ fontSize: 15, color: t.textSec, fontWeight: 600 }}>lbs</span>
          </div>
        </div>
      </div>
      <LogWeightSheet mode={mode} onClose={() => {}} />
    </BCTheme>
  );
}

Object.assign(window, { LogWeightSheet, LogWeightHost });
