// meals-screen.jsx — Meals tab (weekly plan + shopping list sheet)

function MLStatusBar({ mode }) {
  const c = mode === 'dark' ? '#fff' : '#000';
  return (
    <div style={{
      height: 54, padding: '14px 28px 0',
      display: 'flex', alignItems: 'center', justifyContent: 'space-between',
      fontSize: 17, fontWeight: 600, letterSpacing: -0.41, color: c,
      fontFamily: SF_STACK,
    }}>
      <span style={{ fontVariantNumeric: 'tabular-nums' }}>9:41</span>
      <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
        <svg width="18" height="11" viewBox="0 0 18 11">
          <rect x="0" y="7" width="3" height="4" rx="0.6" fill={c}/>
          <rect x="5" y="5" width="3" height="6" rx="0.6" fill={c}/>
          <rect x="10" y="3" width="3" height="8" rx="0.6" fill={c}/>
          <rect x="15" y="0" width="3" height="11" rx="0.6" fill={c}/>
        </svg>
        <svg width="26" height="12" viewBox="0 0 26 12">
          <rect x="0.5" y="0.5" width="22" height="11" rx="3" stroke={c} strokeOpacity="0.4" fill="none"/>
          <rect x="2" y="2" width="19" height="8" rx="1.5" fill={c}/>
          <rect x="23.5" y="4" width="1.5" height="4" rx="0.7" fill={c} fillOpacity="0.4"/>
        </svg>
      </div>
    </div>
  );
}

// ─── Week strip ───────────────────────────────────────────────────────
const WEEK = [
  { d: 'M', date: 12, kcal: 1820 },
  { d: 'T', date: 13, kcal: 2100, today: true },
  { d: 'W', date: 14, kcal: 1980 },
  { d: 'T', date: 15, kcal: 1750 },
  { d: 'F', date: 16, kcal: 2240 },
  { d: 'S', date: 17, kcal: 1620 },
  { d: 'S', date: 18, kcal: null },
];

function WeekStrip({ mode, selectedIdx, onSelect }) {
  const t = mode === 'dark' ? BC_DARK : BC_LIGHT;
  return (
    <div style={{ display: 'flex', gap: 6, padding: '0 16px' }}>
      {WEEK.map((day, i) => {
        const sel = i === selectedIdx;
        return (
          <button key={i} onClick={() => onSelect(i)} style={{
            flex: 1, padding: '8px 0 10px',
            background: sel ? t.primary : t.surface,
            border: '1px solid ' + (sel ? t.primary : t.separator),
            borderRadius: 14,
            display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 2,
            cursor: 'pointer',
            color: sel ? '#fff' : t.text,
            fontFamily: SF_STACK,
            WebkitTapHighlightColor: 'transparent',
            position: 'relative',
          }}>
            <span style={{ fontSize: 10, fontWeight: 700, letterSpacing: 0.4, opacity: sel ? 0.85 : 0.55 }}>{day.d}</span>
            <span style={{ fontSize: 17, fontWeight: 700, letterSpacing: -0.3, fontVariantNumeric: 'tabular-nums' }}>{day.date}</span>
            {day.today && !sel && (
              <span style={{
                position: 'absolute', bottom: 4, width: 4, height: 4, borderRadius: 999, background: t.primary,
              }} />
            )}
            {sel && day.today && (
              <span style={{
                position: 'absolute', bottom: 4, width: 4, height: 4, borderRadius: 999, background: '#fff',
              }} />
            )}
          </button>
        );
      })}
    </div>
  );
}

// ─── Day macro summary ────────────────────────────────────────────────
function DayMacroSummary({ mode, kcal, target, p, c, f, pTarget, cTarget, fTarget }) {
  const t = mode === 'dark' ? BC_DARK : BC_LIGHT;
  const Bar = ({ value, max, color }) => (
    <div style={{ height: 4, background: t.surface2, borderRadius: 4, overflow: 'hidden' }}>
      <div style={{ height: '100%', width: Math.min(100, (value / max) * 100) + '%', background: color, borderRadius: 4 }} />
    </div>
  );
  return (
    <div style={{
      background: t.surface, border: '1px solid ' + t.separator, borderRadius: BC_RADIUS.lg,
      padding: '14px 16px',
    }}>
      <div style={{ display: 'flex', alignItems: 'baseline', gap: 14 }}>
        <div style={{ flex: 1 }}>
          <div style={{ fontSize: 11, fontWeight: 700, letterSpacing: 0.6, textTransform: 'uppercase', color: t.textTer }}>Planned</div>
          <div style={{ display: 'flex', alignItems: 'baseline', gap: 5, marginTop: 4 }}>
            <span style={{ fontSize: 26, fontWeight: 800, color: t.text, letterSpacing: -0.6, lineHeight: 1, fontVariantNumeric: 'tabular-nums' }}>{kcal.toLocaleString()}</span>
            <span style={{ fontSize: 13, color: t.textSec, fontWeight: 600 }}>/ {target.toLocaleString()} kcal</span>
          </div>
        </div>
        <div style={{ fontSize: 12, color: t.textSec, textAlign: 'right' }}>
          <div style={{ fontWeight: 700, color: t.success }}>+58 kcal</div>
          <div style={{ marginTop: 1 }}>vs target</div>
        </div>
      </div>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 12, marginTop: 12 }}>
        {[
          ['P', p, pTarget, t.protein],
          ['C', c, cTarget, t.carbs],
          ['F', f, fTarget, t.fat],
        ].map(([label, val, mx, color]) => (
          <div key={label}>
            <div style={{ display: 'flex', alignItems: 'baseline', gap: 4, marginBottom: 4 }}>
              <span style={{ fontSize: 11, fontWeight: 700, color, letterSpacing: 0.3, textTransform: 'uppercase' }}>{label}</span>
              <span style={{ marginLeft: 'auto', fontSize: 12, color: t.text, fontWeight: 700, fontVariantNumeric: 'tabular-nums' }}>
                {val}<span style={{ color: t.textSec, fontWeight: 500, marginLeft: 1 }}>/{mx}g</span>
              </span>
            </div>
            <Bar value={val} max={mx} color={color} />
          </div>
        ))}
      </div>
    </div>
  );
}

// ─── Planned entry row ────────────────────────────────────────────────
function PlannedEntry({ mode, time, name, sub, kcal, p, c, f, logged, first, last }) {
  const t = mode === 'dark' ? BC_DARK : BC_LIGHT;
  return (
    <div style={{
      background: t.surface,
      borderTopLeftRadius: first ? BC_RADIUS.lg : 0,
      borderTopRightRadius: first ? BC_RADIUS.lg : 0,
      borderBottomLeftRadius: last ? BC_RADIUS.lg : 0,
      borderBottomRightRadius: last ? BC_RADIUS.lg : 0,
      borderTop: first ? '1px solid ' + t.separator : 'none',
      borderBottom: last ? '1px solid ' + t.separator : '0.5px solid ' + t.separator,
      borderLeft: '1px solid ' + t.separator,
      borderRight: '1px solid ' + t.separator,
      padding: '12px 14px',
      display: 'flex', alignItems: 'center', gap: 12,
      opacity: logged ? 0.55 : 1,
    }}>
      {/* Clock + time */}
      <div style={{ width: 44, flexShrink: 0, textAlign: 'right' }}>
        <div style={{
          display: 'inline-flex', flexDirection: 'column', alignItems: 'center',
        }}>
          <BCIcon name={logged ? 'check' : 'flame'} size={14} color={logged ? t.success : t.textTer}
            strokeWidth={logged ? 2.6 : 1.8} style={{ display: 'none' }} />
          {/* Clock-style icon — minimal */}
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke={logged ? t.success : t.textSec} strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
            <circle cx="12" cy="12" r="9"/>
            <path d="M12 7v5l3 2"/>
          </svg>
          <div style={{
            fontSize: 11, fontWeight: 700, color: t.textSec, letterSpacing: 0.1, marginTop: 3,
            fontVariantNumeric: 'tabular-nums', textAlign: 'center',
          }}>{time}</div>
        </div>
      </div>

      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{
          fontSize: 15, fontWeight: 700, color: t.text, letterSpacing: -0.2,
          whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis',
        }}>{name}</div>
        <div style={{
          fontSize: 12, color: t.textSec, marginTop: 2, display: 'flex', alignItems: 'center', gap: 8,
          fontVariantNumeric: 'tabular-nums',
        }}>
          <span style={{ whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{sub}</span>
        </div>
        <div style={{
          marginTop: 6, fontSize: 12, fontWeight: 700,
          fontVariantNumeric: 'tabular-nums', display: 'flex', gap: 10,
        }}>
          <span style={{ color: t.text }}>{kcal}<span style={{ color: t.textTer, fontWeight: 500 }}> kcal</span></span>
          <span style={{ color: t.protein }}>{p}p</span>
          <span style={{ color: t.carbs }}>{c}c</span>
          <span style={{ color: t.fat }}>{f}f</span>
        </div>
      </div>

      {logged ? (
        <div style={{
          padding: '5px 10px', borderRadius: 999,
          background: t.successSoft, color: t.success,
          fontSize: 11, fontWeight: 700, letterSpacing: 0.2, textTransform: 'uppercase',
          flexShrink: 0,
          display: 'inline-flex', alignItems: 'center', gap: 4,
        }}>
          <BCIcon name="check" size={11} color={t.success} strokeWidth={3} />
          Logged
        </div>
      ) : (
        <button style={{
          padding: '6px 12px', borderRadius: 999, border: 'none',
          background: t.primary, color: '#fff',
          fontSize: 12, fontWeight: 700, letterSpacing: -0.1,
          cursor: 'pointer', flexShrink: 0,
          fontFamily: SF_STACK,
        }}>Log now</button>
      )}
    </div>
  );
}

// ─── Day templates row ────────────────────────────────────────────────
function DayTemplates({ mode }) {
  const t = mode === 'dark' ? BC_DARK : BC_LIGHT;
  const templates = [
    { name: 'High-protein',  kcal: 2050, p: 180, c: 200, f: 60 },
    { name: 'Lower carb',     kcal: 1900, p: 165, c: 100, f: 105 },
    { name: 'Vegetarian',     kcal: 2000, p: 110, c: 250, f: 70 },
    { name: 'Rest day',       kcal: 1750, p: 130, c: 175, f: 60 },
    { name: 'Race fueling',   kcal: 2700, p: 140, c: 380, f: 70 },
  ];
  return (
    <div>
      <div style={{
        padding: '0 4px 8px',
        display: 'flex', alignItems: 'baseline', justifyContent: 'space-between',
      }}>
        <span style={{ fontSize: 11, fontWeight: 700, letterSpacing: 0.6, textTransform: 'uppercase', color: t.textTer }}>Day templates</span>
        <span style={{ fontSize: 13, fontWeight: 600, color: t.primary }}>See all</span>
      </div>
      <div style={{ display: 'flex', gap: 10, overflowX: 'auto', paddingBottom: 4 }}>
        {templates.map(tp => (
          <button key={tp.name} style={{
            flex: '0 0 auto',
            background: t.surface, border: '1px solid ' + t.separator, borderRadius: 14,
            padding: '12px 14px', minWidth: 150,
            display: 'flex', flexDirection: 'column', gap: 6, textAlign: 'left',
            cursor: 'pointer', fontFamily: SF_STACK,
            WebkitTapHighlightColor: 'transparent',
          }}>
            <div style={{ fontSize: 14, fontWeight: 700, color: t.text, letterSpacing: -0.2 }}>{tp.name}</div>
            <div style={{ fontSize: 13, color: t.text, fontWeight: 800, fontVariantNumeric: 'tabular-nums' }}>
              {tp.kcal.toLocaleString()} <span style={{ fontSize: 11, color: t.textSec, fontWeight: 600 }}>kcal</span>
            </div>
            <div style={{ display: 'flex', gap: 8, fontSize: 11, fontWeight: 700, fontVariantNumeric: 'tabular-nums' }}>
              <span style={{ color: t.protein }}>{tp.p}p</span>
              <span style={{ color: t.carbs }}>{tp.c}c</span>
              <span style={{ color: t.fat }}>{tp.f}f</span>
            </div>
          </button>
        ))}
      </div>
    </div>
  );
}

// ─── Shopping list sheet ──────────────────────────────────────────────
const SHOPPING = {
  Produce:  [
    { name: 'Broccoli',          qty: '2 heads',     checked: false },
    { name: 'Cherry tomatoes',   qty: '2 pints',     checked: true },
    { name: 'Lemons',            qty: '4',           checked: false },
    { name: 'Spinach, baby',     qty: '10 oz',       checked: false },
    { name: 'Sweet potatoes',    qty: '3 medium',    checked: false },
  ],
  Protein: [
    { name: 'Chicken breast',    qty: '2 lb',        checked: false },
    { name: 'Greek yogurt',      qty: '32 oz',       checked: false },
    { name: 'Eggs',              qty: '1 dozen',     checked: true },
    { name: 'Salmon fillets',    qty: '1 lb',        checked: false },
  ],
  Dairy: [
    { name: 'Oat milk',          qty: '½ gallon',    checked: false },
    { name: 'Parmesan',          qty: '4 oz',        checked: false },
  ],
  Pantry: [
    { name: 'Quinoa',            qty: '1 bag',       checked: false },
    { name: 'Basil pesto',       qty: '8 oz jar',    checked: false },
    { name: 'Olive oil',         qty: '1 bottle',    checked: false },
    { name: 'Penne pasta',       qty: '1 lb',        checked: false },
  ],
};

function ShoppingListSheet({ mode, onClose }) {
  const t = mode === 'dark' ? BC_DARK : BC_LIGHT;
  const [items, setItems] = React.useState(SHOPPING);
  const flip = (cat, idx) => setItems(s => ({
    ...s,
    [cat]: s[cat].map((it, i) => i === idx ? { ...it, checked: !it.checked } : it),
  }));
  const all = Object.values(items).flat();
  const remaining = all.filter(i => !i.checked).length;

  return (
    <>
      <div onClick={onClose} style={{
        position: 'absolute', inset: 0, background: t.scrim, zIndex: 20,
      }} />
      <div style={{
        position: 'absolute', left: 0, right: 0, bottom: 0, zIndex: 21,
        background: t.surface, height: '82%',
        borderTopLeftRadius: 22, borderTopRightRadius: 22,
        boxShadow: '0 -10px 40px rgba(0,0,0,0.30)',
        display: 'flex', flexDirection: 'column', overflow: 'hidden',
      }}>
        {/* Grabber */}
        <div style={{ display: 'flex', justifyContent: 'center', padding: '8px 0 4px' }}>
          <div style={{ width: 38, height: 5, borderRadius: 999, background: t.hairline }} />
        </div>

        {/* Header */}
        <div style={{
          padding: '6px 18px 12px', display: 'flex', alignItems: 'flex-start',
          borderBottom: '0.5px solid ' + t.separator,
        }}>
          <div style={{ flex: 1 }}>
            <div style={{ fontSize: 18, fontWeight: 800, color: t.text, letterSpacing: -0.3 }}>Shopping list</div>
            <div style={{ fontSize: 13, color: t.textSec, marginTop: 2 }}>
              {remaining} of {all.length} remaining · this week
            </div>
          </div>
          <button style={{
            width: 36, height: 36, borderRadius: 999, border: 'none',
            background: t.primarySoft, color: t.primary,
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            cursor: 'pointer',
          }} aria-label="Share">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke={t.primary} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <path d="M12 3v14M7 8l5-5 5 5"/>
              <path d="M5 13v6a2 2 0 002 2h10a2 2 0 002-2v-6"/>
            </svg>
          </button>
          <button onClick={onClose} style={{
            width: 30, height: 30, marginLeft: 8, borderRadius: 999, border: 'none',
            background: t.surface2, color: t.textSec,
            display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer',
          }}><BCIcon name="close" size={14} color={t.textSec} strokeWidth={2.4}/></button>
        </div>

        {/* Categories list */}
        <div style={{ flex: 1, overflowY: 'auto', padding: '4px 18px 80px' }}>
          {Object.entries(items).map(([cat, list]) => (
            <div key={cat} style={{ paddingTop: 14 }}>
              <div style={{
                fontSize: 11, fontWeight: 700, color: t.textTer,
                letterSpacing: 0.6, textTransform: 'uppercase', marginBottom: 4,
                display: 'flex', alignItems: 'baseline', gap: 8,
              }}>
                <span>{cat}</span>
                <span style={{ opacity: 0.7 }}>{list.length}</span>
              </div>
              {list.map((it, i) => (
                <button key={it.name} onClick={() => flip(cat, i)} style={{
                  width: '100%', padding: '10px 0',
                  borderBottom: i < list.length - 1 ? '0.5px solid ' + t.separator : 'none',
                  background: 'transparent', border: 'none',
                  display: 'flex', alignItems: 'center', gap: 12,
                  cursor: 'pointer', fontFamily: SF_STACK, textAlign: 'left',
                }}>
                  <span style={{
                    width: 22, height: 22, borderRadius: 6,
                    background: it.checked ? t.primary : 'transparent',
                    border: `1.8px solid ${it.checked ? t.primary : t.hairline}`,
                    display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0,
                  }}>
                    {it.checked && <BCIcon name="check" size={13} color="#fff" strokeWidth={3} />}
                  </span>
                  <span style={{
                    flex: 1, fontSize: 15, fontWeight: 600,
                    color: t.text, letterSpacing: -0.2,
                    textDecoration: it.checked ? 'line-through' : 'none',
                    opacity: it.checked ? 0.55 : 1,
                  }}>{it.name}</span>
                  <span style={{ fontSize: 13, color: t.textSec, fontWeight: 600 }}>{it.qty}</span>
                </button>
              ))}
            </div>
          ))}
        </div>

        {/* Sticky export */}
        <div style={{
          position: 'absolute', left: 0, right: 0, bottom: 0,
          padding: '10px 18px 22px',
          background: t.surface,
          borderTop: '0.5px solid ' + t.separator,
          display: 'flex', gap: 8,
        }}>
          <BCButton kind="secondary" size="md" style={{ flex: 1 }}>Send to email</BCButton>
          <BCButton kind="primary" size="md" style={{ flex: 1 }}
            icon={
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#fff" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
                <rect x="3" y="3" width="18" height="14" rx="2"/>
                <path d="M3 17l5 4M21 17l-5 4M8 21h8"/>
              </svg>
            }>Apple Reminders</BCButton>
        </div>
      </div>
    </>
  );
}

// ─── Tab bar ─────────────────────────────────────────────────────────
function MLTabBar({ mode, active }) {
  const t = mode === 'dark' ? BC_DARK : BC_LIGHT;
  const tabs = [
    { name: 'Today',  icon: 'flame' },
    { name: 'Trends', icon: 'chart' },
    { name: 'Meals',  icon: 'fork' },
    { name: 'Coach',  icon: 'spark' },
    { name: 'Profile',icon: 'user' },
  ];
  return (
    <div style={{
      background: t.surface,
      borderTop: '0.5px solid ' + t.separator,
      paddingTop: 8,
    }}>
      <div style={{ display: 'flex' }}>
        {tabs.map((tb, i) => {
          const isActive = i === active;
          const c = isActive ? t.primary : t.textTer;
          const inactive = '#8E8E93';
          return (
            <div key={tb.name} style={{
              flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 3,
            }}>
              {tb.name === 'Today' ? (
                <BluCalMark size={26} color={isActive ? t.primary : inactive} />
              ) : (
                <BCIcon name={tb.icon} size={26} color={c} strokeWidth={isActive ? 2.2 : 1.8} />
              )}
              <div style={{ fontSize: 10, fontWeight: 600, color: c, letterSpacing: 0.1 }}>{tb.name}</div>
            </div>
          );
        })}
      </div>
      <div style={{ height: 14, display: 'flex', justifyContent: 'center', alignItems: 'flex-end', paddingBottom: 6 }}>
        <div style={{ width: 134, height: 5, borderRadius: 999, background: mode === 'dark' ? 'rgba(255,255,255,0.6)' : 'rgba(0,0,0,0.3)' }} />
      </div>
    </div>
  );
}

// ─── Screen ───────────────────────────────────────────────────────────
function MealsScreen({ mode = 'light', showShopping = false }) {
  const t = mode === 'dark' ? BC_DARK : BC_LIGHT;
  const [selectedIdx, setSelectedIdx] = React.useState(1); // Tuesday
  const [sheet, setSheet] = React.useState(showShopping ? 'shopping' : null);
  React.useEffect(() => { setSheet(showShopping ? 'shopping' : null); }, [showShopping]);

  const plan = [
    { time: '7:30a',  name: 'Greek yogurt + granola',  sub: '1 cup + ¼ cup',          kcal: 322, p: 18, c: 42, f: 8,  logged: true },
    { time: '9:00a',  name: 'Oat milk latte',          sub: '12 oz · oat milk',       kcal: 110, p: 4,  c: 15, f: 3,  logged: true },
    { time: '12:30p', name: 'Chicken pesto pasta',     sub: 'recipe · 1 serving',     kcal: 540, p: 38, c: 56, f: 18, logged: false },
    { time: '3:30p',  name: 'Apple + peanut butter',   sub: '1 medium + 2 tbsp',      kcal: 280, p: 8,  c: 30, f: 16, logged: false },
    { time: '6:30p',  name: 'Sheet-pan salmon bowl',   sub: 'recipe · 1 serving',     kcal: 480, p: 42, c: 14, f: 28, logged: false },
    { time: '8:30p',  name: 'Cottage cheese + berries',sub: '½ cup + ½ cup',          kcal: 130, p: 14, c: 12, f: 3,  logged: false },
  ];
  const totalKcal = plan.reduce((s, e) => s + e.kcal, 0);
  const totP = plan.reduce((s, e) => s + e.p, 0);
  const totC = plan.reduce((s, e) => s + e.c, 0);
  const totF = plan.reduce((s, e) => s + e.f, 0);

  const dayLabels = ['Mon · May 12', 'Tue · May 13 · Today', 'Wed · May 14', 'Thu · May 15', 'Fri · May 16', 'Sat · May 17', 'Sun · May 18'];

  return (
    <BCTheme mode={mode} padding={0} style={{ position: 'relative', overflow: 'hidden', height: '100%' }}>
      <MLStatusBar mode={mode} />

      <div style={{ position: 'absolute', top: 54, left: 0, right: 0, bottom: 86, overflowY: 'auto', overflowX: 'hidden' }}>
        {/* Title */}
        <div style={{ padding: '8px 20px 4px', display: 'flex', alignItems: 'flex-end', justifyContent: 'space-between' }}>
          <div>
            <div style={{ fontSize: 34, fontWeight: 800, color: t.text, letterSpacing: -0.8, lineHeight: '41px' }}>Plan</div>
            <div style={{ fontSize: 14, color: t.textSec, marginTop: 2, fontWeight: 600 }}>This week · May 12 – 18</div>
          </div>
          <button style={{
            height: 32, padding: '0 12px',
            background: t.primarySoft, color: t.primary, border: 'none',
            borderRadius: 999, fontSize: 13, fontWeight: 700,
            display: 'inline-flex', alignItems: 'center', gap: 4,
            cursor: 'pointer', fontFamily: SF_STACK,
          }}>
            <BCIcon name="spark" size={14} color={t.primary} />
            Auto-plan
          </button>
        </div>

        {/* Week strip */}
        <div style={{ marginTop: 12 }}>
          <WeekStrip mode={mode} selectedIdx={selectedIdx} onSelect={setSelectedIdx} />
        </div>

        {/* Day section header */}
        <div style={{ padding: '20px 20px 8px' }}>
          <div style={{ fontSize: 17, fontWeight: 700, color: t.text, letterSpacing: -0.3 }}>{dayLabels[selectedIdx]}</div>
          <div style={{ fontSize: 12, color: t.textSec, marginTop: 2 }}>{plan.length} planned · {plan.filter(p => p.logged).length} logged</div>
        </div>

        {/* Day macro summary */}
        <div style={{ padding: '0 16px' }}>
          <DayMacroSummary mode={mode}
            kcal={totalKcal} target={2000}
            p={totP} c={totC} f={totF}
            pTarget={140} cTarget={250} fTarget={65}
          />
        </div>

        {/* Plan list */}
        <div style={{ padding: '12px 16px 0' }}>
          {plan.map((e, i) => (
            <PlannedEntry key={i} mode={mode} {...e}
              first={i === 0} last={false}
            />
          ))}
          {/* Dashed add */}
          <button style={{
            width: '100%',
            background: 'transparent', border: `1.5px dashed ${t.primary}`,
            borderTopLeftRadius: 0, borderTopRightRadius: 0,
            borderBottomLeftRadius: BC_RADIUS.lg, borderBottomRightRadius: BC_RADIUS.lg,
            borderTopWidth: 0,
            padding: '14px',
            color: t.primary, fontSize: 14, fontWeight: 700, letterSpacing: -0.2,
            display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8,
            cursor: 'pointer', fontFamily: SF_STACK,
          }}>
            <BCIcon name="plus" size={16} color={t.primary} strokeWidth={2.4} />
            Add to plan
          </button>
        </div>

        {/* Day templates */}
        <div style={{ padding: '24px 16px 0' }}>
          <DayTemplates mode={mode} />
        </div>

        {/* Generate shopping list */}
        <div style={{ padding: '20px 16px 24px' }}>
          <BCButton kind="secondary" size="lg" block onClick={() => setSheet('shopping')}
            icon={
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke={t.text} strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
                <path d="M3 5h2l2 12h12l2-9H6"/>
                <circle cx="9" cy="20" r="1.4"/>
                <circle cx="17" cy="20" r="1.4"/>
              </svg>
            }>
            Generate shopping list
          </BCButton>
        </div>
      </div>

      {/* Tab bar */}
      <div style={{ position: 'absolute', left: 0, right: 0, bottom: 0 }}>
        <MLTabBar mode={mode} active={2} />
      </div>

      {sheet === 'shopping' && (
        <ShoppingListSheet mode={mode} onClose={() => setSheet(null)} />
      )}
    </BCTheme>
  );
}

Object.assign(window, { MealsScreen });
