// onboarding-screens.jsx — BluCal onboarding flow (8 screens)
// Each screen is a stateless component receiving { state, set, onNext }
// — they all share the same ScreenLayout shell.

// ─── Shared shell ────────────────────────────────────────────────────────

function StatusChrome({ mode }) {
  const c = mode === 'dark' ? '#fff' : '#000';
  return (
    <div style={{
      height: 54, padding: '14px 28px 0',
      display: 'flex', alignItems: 'center', justifyContent: 'space-between',
      fontSize: 17, fontWeight: 600, letterSpacing: -0.41, color: c,
      fontFamily: SF_STACK,
    }}>
      <span style={{ fontVariantNumeric: 'tabular-nums' }}>9:41</span>
      <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
        <svg width="18" height="11" viewBox="0 0 18 11">
          <rect x="0" y="7" width="3" height="4" rx="0.6" fill={c}/>
          <rect x="5" y="5" width="3" height="6" rx="0.6" fill={c}/>
          <rect x="10" y="3" width="3" height="8" rx="0.6" fill={c}/>
          <rect x="15" y="0" width="3" height="11" rx="0.6" fill={c}/>
        </svg>
        <svg width="26" height="12" viewBox="0 0 26 12">
          <rect x="0.5" y="0.5" width="22" height="11" rx="3" stroke={c} strokeOpacity="0.4" fill="none"/>
          <rect x="2" y="2" width="19" height="8" rx="1.5" fill={c}/>
          <rect x="23.5" y="4" width="1.5" height="4" rx="0.7" fill={c} fillOpacity="0.4"/>
        </svg>
      </div>
    </div>
  );
}

function ProgressBar({ step, total = 7, onBack }) {
  const { t } = useBC();
  return (
    <div style={{
      display: 'flex', alignItems: 'center', gap: 12,
      padding: '6px 20px 4px',
    }}>
      <button onClick={onBack} style={{
        width: 32, height: 32, borderRadius: 999,
        background: t.surface2, border: 'none',
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        cursor: 'pointer', flexShrink: 0, opacity: step > 0 ? 1 : 0,
        pointerEvents: step > 0 ? 'auto' : 'none',
      }}>
        <BCIcon name="chev" size={16} color={t.text} style={{ transform: 'scaleX(-1)' }} />
      </button>
      <div style={{ flex: 1, display: 'flex', gap: 4 }}>
        {Array.from({ length: total }).map((_, i) => (
          <div key={i} style={{
            flex: 1, height: 4, borderRadius: 4,
            background: i < step ? t.primary : t.surface2,
            transition: 'background .25s',
          }} />
        ))}
      </div>
      <div style={{
        fontSize: 12, fontWeight: 700, color: t.textSec,
        fontVariantNumeric: 'tabular-nums', width: 32, textAlign: 'right',
      }}>{step}<span style={{ opacity: 0.5 }}>/{total}</span></div>
    </div>
  );
}

function ScreenLayout({ mode, step, totalSteps, onBack, onNext, ctaLabel = 'Continue', ctaDisabled,
                       title, subtitle, eyebrow, secondaryCta, children, showProgress = true,
                       contentPad = 20 }) {
  const t = mode === 'dark' ? BC_DARK : BC_LIGHT;
  return (
    <BCTheme mode={mode} padding={0} style={{ position: 'relative', overflow: 'hidden', height: '100%' }}>
      <StatusChrome mode={mode} />
      {showProgress && <ProgressBar step={step} total={totalSteps} onBack={onBack} />}

      <div style={{
        position: 'absolute',
        top: showProgress ? 54 + 46 : 54,
        left: 0, right: 0, bottom: 0,
        display: 'flex', flexDirection: 'column',
      }}>
        {(title || eyebrow) && (
          <div style={{ padding: `4px ${contentPad}px 8px` }}>
            {eyebrow && (
              <div style={{ fontSize: 12, fontWeight: 700, letterSpacing: 0.8, textTransform: 'uppercase', color: t.primary, marginBottom: 10 }}>
                {eyebrow}
              </div>
            )}
            {title && (
              <div style={{ fontSize: 28, fontWeight: 700, color: t.text, letterSpacing: -0.6, lineHeight: '34px' }}>{title}</div>
            )}
            {subtitle && (
              <div style={{ fontSize: 15, color: t.textSec, marginTop: 8, letterSpacing: -0.2, lineHeight: '21px', textWrap: 'pretty' }}>{subtitle}</div>
            )}
          </div>
        )}

        <div style={{ flex: 1, padding: `8px ${contentPad}px 0`, overflowY: 'auto' }}>
          {children}
        </div>

        <div style={{
          padding: `12px ${contentPad}px 26px`,
          display: 'flex', flexDirection: 'column', gap: 10,
          background: t.bg,
        }}>
          <BCButton kind="primary" size="lg" block
            state={ctaDisabled ? 'disabled' : undefined}
            style={{ pointerEvents: ctaDisabled ? 'none' : 'auto' }}
            onClick={ctaDisabled ? undefined : onNext}
          >{ctaLabel}</BCButton>
          {secondaryCta}
        </div>
      </div>
    </BCTheme>
  );
}

// ─── 1. Welcome ──────────────────────────────────────────────────────────

function ScreenWelcome({ mode, onNext }) {
  const t = mode === 'dark' ? BC_DARK : BC_LIGHT;
  return (
    <BCTheme mode={mode} padding={0} style={{ position: 'relative', overflow: 'hidden', height: '100%' }}>
      <StatusChrome mode={mode} />
      <div style={{
        position: 'absolute', top: 54, left: 0, right: 0, bottom: 0,
        display: 'flex', flexDirection: 'column',
      }}>
        {/* Hero space */}
        <div style={{
          flex: 1,
          display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center',
          padding: '0 24px',
          textAlign: 'center',
        }}>
          {/* Logo */}
          <BluCalLogo size={96} />

          <div style={{ fontSize: 36, fontWeight: 800, color: t.text, marginTop: 28, letterSpacing: -1.0 }}>BluCal</div>
          <div style={{ fontSize: 19, color: t.text, marginTop: 14, fontWeight: 600, letterSpacing: -0.4 }}>
            Your nutrition, your way.
          </div>
          <div style={{ fontSize: 15, color: t.textSec, marginTop: 10, letterSpacing: -0.2, lineHeight: '21px', maxWidth: 280, textWrap: 'pretty' }}>
            Track meals, hit your macros, and learn what actually works for you.
          </div>

          {/* Small feature row */}
          <div style={{ display: 'flex', gap: 28, marginTop: 38 }}>
            {[
              ['flame', 'Macros'],
              ['chart', 'Trends'],
              ['spark', 'Coach'],
            ].map(([icon, label]) => (
              <div key={label} style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 6 }}>
                <div style={{
                  width: 42, height: 42, borderRadius: 12,
                  background: t.primarySoft, color: t.primary,
                  display: 'flex', alignItems: 'center', justifyContent: 'center',
                }}><BCIcon name={icon} size={22} color={t.primary} /></div>
                <div style={{ fontSize: 11, fontWeight: 600, color: t.textSec, letterSpacing: 0.2 }}>{label}</div>
              </div>
            ))}
          </div>
        </div>

        <div style={{ padding: '12px 20px 26px', display: 'flex', flexDirection: 'column', gap: 10 }}>
          <BCButton kind="primary" size="lg" block onClick={onNext}>Get started</BCButton>
          <div style={{ textAlign: 'center', fontSize: 14, color: t.textSec, padding: 6 }}>
            Already have an account?{' '}
            <span style={{ color: t.primary, fontWeight: 600 }}>Sign in</span>
          </div>
        </div>
      </div>
    </BCTheme>
  );
}

// ─── 2. Goal ─────────────────────────────────────────────────────────────

function GoalCard({ icon, title, desc, color, selected, onClick }) {
  const { t } = useBC();
  return (
    <div onClick={onClick} style={{
      background: t.surface,
      border: `${selected ? 2 : 1}px solid ${selected ? t.primary : t.separator}`,
      borderRadius: BC_RADIUS.lg,
      padding: selected ? 15 : 16,
      display: 'flex', alignItems: 'center', gap: 14,
      cursor: 'pointer', WebkitTapHighlightColor: 'transparent',
      transition: 'border-color .12s, background .12s',
    }}>
      <div style={{
        width: 44, height: 44, borderRadius: 12,
        background: color || t.primarySoft,
        color: color ? '#fff' : t.primary,
        display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0,
      }}><BCIcon name={icon} size={22} color={color ? '#fff' : t.primary} /></div>
      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{ fontSize: 16, fontWeight: 700, color: t.text, letterSpacing: -0.3 }}>{title}</div>
        <div style={{ fontSize: 13, color: t.textSec, marginTop: 2, lineHeight: '17px' }}>{desc}</div>
      </div>
      <div style={{
        width: 24, height: 24, borderRadius: 999,
        border: `2px solid ${selected ? t.primary : t.hairline}`,
        background: selected ? t.primary : 'transparent',
        display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0,
      }}>{selected && <BCIcon name="check" size={14} color="#fff" strokeWidth={2.6} />}</div>
    </div>
  );
}

function ScreenGoal({ mode, state, set, onNext, onBack }) {
  const t = mode === 'dark' ? BC_DARK : BC_LIGHT;
  const goals = [
    { id: 'lose',     icon: 'flame', title: 'Lose fat',           desc: 'Calorie deficit, protein-forward macros', color: t.primary },
    { id: 'build',    icon: 'spark', title: 'Build muscle',       desc: 'Slight surplus, higher protein',           color: t.teal },
    { id: 'maintain', icon: 'check', title: 'Maintain weight',    desc: 'Stay where you are, eat balanced',         color: '#5C5C63' },
    { id: 'perform',  icon: 'chart', title: 'Improve performance',desc: 'Fuel training & recovery',                 color: t.carbs },
  ];
  return (
    <ScreenLayout mode={mode} step={1} totalSteps={7} onBack={onBack} onNext={onNext}
      title="What's your goal?"
      subtitle="We'll personalize your daily targets and recommendations around it."
      ctaDisabled={!state.goal}
    >
      <VStack gap={10}>
        {goals.map(g => (
          <GoalCard key={g.id} {...g} selected={state.goal === g.id} onClick={() => set({ goal: g.id })} />
        ))}
      </VStack>
    </ScreenLayout>
  );
}

// ─── 3. Stats ────────────────────────────────────────────────────────────

function LabeledInput({ label, value, unit, onClick, active }) {
  const { t } = useBC();
  return (
    <div onClick={onClick} style={{
      flex: 1,
      background: t.surface, borderRadius: BC_RADIUS.md,
      border: `${active ? 2 : 1}px solid ${active ? t.primary : t.separator}`,
      padding: active ? '11px 13px' : '12px 14px',
      cursor: 'pointer', WebkitTapHighlightColor: 'transparent',
    }}>
      <div style={{ fontSize: 11, fontWeight: 700, color: t.textTer, letterSpacing: 0.6, textTransform: 'uppercase' }}>{label}</div>
      <div style={{ display: 'flex', alignItems: 'baseline', gap: 4, marginTop: 4 }}>
        <span style={{ fontSize: 22, fontWeight: 700, color: t.text, fontVariantNumeric: 'tabular-nums', letterSpacing: -0.5 }}>{value}</span>
        {unit && <span style={{ fontSize: 13, color: t.textSec, fontWeight: 600 }}>{unit}</span>}
      </div>
    </div>
  );
}

function ScreenStats({ mode, state, set, onNext, onBack }) {
  const t = mode === 'dark' ? BC_DARK : BC_LIGHT;
  const cyclesSex = ['Female', 'Male', 'Other'];

  return (
    <ScreenLayout mode={mode} step={2} totalSteps={7} onBack={onBack} onNext={onNext}
      title="Tell us about you"
      subtitle="We use this for accurate calorie and macro targets. Always editable later."
    >
      <VStack gap={20}>
        {/* Sex */}
        <VStack gap={8}>
          <div style={{ fontSize: 13, fontWeight: 600, color: t.textSec, letterSpacing: -0.1 }}>Biological sex</div>
          <div style={{
            display: 'flex', padding: 3,
            background: t.surface2, borderRadius: BC_RADIUS.sm,
            height: 44,
          }}>
            {cyclesSex.map(s => {
              const active = state.sex === s;
              return (
                <div key={s} onClick={() => set({ sex: s })} style={{
                  flex: 1, height: 38,
                  borderRadius: BC_RADIUS.xs,
                  background: active ? t.surface : 'transparent',
                  color: t.text,
                  fontSize: 14, fontWeight: active ? 700 : 500,
                  display: 'flex', alignItems: 'center', justifyContent: 'center',
                  boxShadow: active ? '0 1px 3px rgba(0,0,0,0.10)' : 'none',
                  cursor: 'pointer',
                }}>{s}</div>
              );
            })}
          </div>
        </VStack>

        {/* Age / Weight row */}
        <HStack gap={12} align="stretch">
          <LabeledInput label="Age" value={state.age} unit="yrs" />
          <LabeledInput label="Weight" value={state.weight}
            unit={state.weightUnit}
            onClick={() => set({ weightUnit: state.weightUnit === 'lbs' ? 'kg' : 'lbs' })} />
        </HStack>

        {/* Height */}
        <VStack gap={8}>
          <HStack gap={8} style={{ justifyContent: 'space-between' }}>
            <div style={{ fontSize: 13, fontWeight: 600, color: t.textSec }}>Height</div>
            <div style={{
              display: 'inline-flex', padding: 2,
              background: t.surface2, borderRadius: 999, height: 26,
            }}>
              {['ft/in', 'cm'].map(u => (
                <div key={u} onClick={() => set({ heightUnit: u })} style={{
                  padding: '0 12px', height: 22,
                  borderRadius: 999,
                  background: state.heightUnit === u ? t.surface : 'transparent',
                  fontSize: 11, fontWeight: 700, color: t.text,
                  display: 'flex', alignItems: 'center',
                  boxShadow: state.heightUnit === u ? '0 1px 2px rgba(0,0,0,0.08)' : 'none',
                  cursor: 'pointer',
                }}>{u}</div>
              ))}
            </div>
          </HStack>
          {state.heightUnit === 'ft/in' ? (
            <HStack gap={12}>
              <LabeledInput label="Feet" value={state.feet} unit="ft" />
              <LabeledInput label="Inches" value={state.inches} unit="in" />
            </HStack>
          ) : (
            <LabeledInput label="Centimeters" value={state.cm} unit="cm" />
          )}
        </VStack>

        {/* Helper note */}
        <div style={{
          padding: '10px 14px', background: t.primarySoft, borderRadius: BC_RADIUS.md,
          fontSize: 12, color: t.text, lineHeight: '17px', display: 'flex', gap: 8,
        }}>
          <BCIcon name="info" size={16} color={t.primary} style={{ flexShrink: 0, marginTop: 1 }} />
          <span>We never share your stats. Sync to Apple Health to keep weight up to date automatically.</span>
        </div>
      </VStack>
    </ScreenLayout>
  );
}

// ─── 4. Goal weight ──────────────────────────────────────────────────────

function ScreenGoalWeight({ mode, state, set, onNext, onBack }) {
  const t = mode === 'dark' ? BC_DARK : BC_LIGHT;
  const goalDelta = state.weight - state.goalWeight;
  const direction = goalDelta > 0 ? 'lose' : goalDelta < 0 ? 'gain' : 'maintain';
  const weeks = Math.ceil(Math.abs(goalDelta) / 1.0); // 1 lb/wk
  return (
    <ScreenLayout mode={mode} step={3} totalSteps={7} onBack={onBack} onNext={onNext}
      title="What's your goal weight?"
      subtitle="We'll never rush you — this is just for pacing your plan."
    >
      <VStack gap={20}>
        {/* current */}
        <div style={{
          padding: '12px 14px', background: t.surface, border: '1px solid ' + t.separator,
          borderRadius: BC_RADIUS.md,
          display: 'flex', justifyContent: 'space-between', alignItems: 'center',
        }}>
          <div style={{ fontSize: 13, color: t.textSec, fontWeight: 600 }}>Current weight</div>
          <div style={{ fontSize: 17, fontWeight: 700, color: t.text, fontVariantNumeric: 'tabular-nums', letterSpacing: -0.2 }}>
            {state.weight} <span style={{ color: t.textSec, fontWeight: 500 }}>{state.weightUnit}</span>
          </div>
        </div>

        {/* big input */}
        <div style={{
          background: t.surface, border: `2px solid ${t.primary}`,
          borderRadius: BC_RADIUS.lg,
          padding: '24px 16px',
          display: 'flex', flexDirection: 'column', alignItems: 'center',
        }}>
          <div style={{ fontSize: 11, fontWeight: 700, color: t.primary, letterSpacing: 0.8, textTransform: 'uppercase' }}>
            Goal weight
          </div>
          <div style={{ display: 'flex', alignItems: 'baseline', gap: 6, marginTop: 8 }}>
            <span style={{
              fontSize: 64, fontWeight: 800, color: t.text, letterSpacing: -2,
              fontVariantNumeric: 'tabular-nums', lineHeight: 1,
            }}>{state.goalWeight}</span>
            <span style={{ fontSize: 20, color: t.textSec, fontWeight: 700 }}>{state.weightUnit}</span>
          </div>

          {/* stepper */}
          <div style={{
            marginTop: 16, display: 'inline-flex', alignItems: 'center', gap: 0,
            background: t.surface2, borderRadius: 999, padding: 4,
          }}>
            <button onClick={() => set({ goalWeight: state.goalWeight - 1 })} style={{
              width: 40, height: 36, borderRadius: 999, border: 'none', background: 'transparent', color: t.text, fontSize: 22, cursor: 'pointer',
            }}>−</button>
            <div style={{ width: 70, textAlign: 'center', fontSize: 14, fontWeight: 700, color: t.text, fontVariantNumeric: 'tabular-nums' }}>
              {state.goalWeight} {state.weightUnit}
            </div>
            <button onClick={() => set({ goalWeight: state.goalWeight + 1 })} style={{
              width: 40, height: 36, borderRadius: 999, border: 'none', background: 'transparent', color: t.text, fontSize: 22, cursor: 'pointer',
            }}>+</button>
          </div>
        </div>

        {/* pace summary */}
        <div style={{
          padding: '14px 16px', background: t.tealSoft, borderRadius: BC_RADIUS.md,
          display: 'flex', alignItems: 'center', gap: 12,
        }}>
          <div style={{
            width: 36, height: 36, borderRadius: 999, background: t.teal, color: '#fff',
            display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0,
          }}><BCIcon name="check" size={20} color="#fff" strokeWidth={2.4} /></div>
          <div style={{ flex: 1 }}>
            <div style={{ fontSize: 14, fontWeight: 700, color: t.text }}>
              {direction === 'lose' && `Healthy pace · about ${weeks} weeks`}
              {direction === 'gain' && `Healthy pace · about ${weeks} weeks`}
              {direction === 'maintain' && 'Maintenance · steady state'}
            </div>
            <div style={{ fontSize: 12, color: t.textSec, marginTop: 2 }}>
              {direction === 'lose' && '~1 lb per week. Sustainable and easy to keep off.'}
              {direction === 'gain' && '~0.5 lb per week of lean gain.'}
              {direction === 'maintain' && 'You\'re aiming to stay where you are.'}
            </div>
          </div>
        </div>
      </VStack>
    </ScreenLayout>
  );
}

// ─── 5. Activity ─────────────────────────────────────────────────────────

function ActivityCard({ icon, title, desc, factor, selected, onClick }) {
  const { t } = useBC();
  return (
    <div onClick={onClick} style={{
      background: t.surface,
      border: `${selected ? 2 : 1}px solid ${selected ? t.primary : t.separator}`,
      borderRadius: BC_RADIUS.lg,
      padding: selected ? 13 : 14,
      display: 'flex', alignItems: 'center', gap: 12,
      cursor: 'pointer', WebkitTapHighlightColor: 'transparent',
    }}>
      <div style={{
        width: 36, height: 36, borderRadius: 10, flexShrink: 0,
        background: selected ? t.primary : t.primarySoft,
        color: selected ? '#fff' : t.primary,
        display: 'flex', alignItems: 'center', justifyContent: 'center',
      }}><BCIcon name={icon} size={18} color={selected ? '#fff' : t.primary} /></div>
      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{ fontSize: 15, fontWeight: 700, color: t.text, letterSpacing: -0.2 }}>{title}</div>
        <div style={{ fontSize: 12, color: t.textSec, marginTop: 1, lineHeight: '16px' }}>{desc}</div>
      </div>
      <div style={{
        fontSize: 11, fontWeight: 700, color: t.textTer,
        fontFamily: 'ui-monospace, SFMono-Regular, Menlo, monospace', flexShrink: 0,
      }}>×{factor}</div>
    </div>
  );
}

function ScreenActivity({ mode, state, set, onNext, onBack }) {
  const t = mode === 'dark' ? BC_DARK : BC_LIGHT;
  const levels = [
    { id: 'sedentary', icon: 'user',  title: 'Sedentary',         desc: 'Desk job, little movement',         factor: '1.20' },
    { id: 'light',     icon: 'check', title: 'Lightly active',    desc: 'Light walks, 1–2 workouts a week',  factor: '1.38' },
    { id: 'moderate',  icon: 'flame', title: 'Moderately active', desc: 'On feet often, 3–4 workouts',       factor: '1.55' },
    { id: 'very',      icon: 'chart', title: 'Very active',       desc: 'Daily training, manual job',        factor: '1.72' },
    { id: 'athlete',   icon: 'spark', title: 'Athlete',           desc: 'Multi-session daily training',      factor: '1.90' },
  ];
  return (
    <ScreenLayout mode={mode} step={4} totalSteps={7} onBack={onBack} onNext={onNext}
      title="How active are you?"
      subtitle="Day-to-day activity only — we'll add planned workouts separately."
      ctaDisabled={!state.activity}
    >
      <VStack gap={8}>
        {levels.map(l => (
          <ActivityCard key={l.id} {...l}
            selected={state.activity === l.id}
            onClick={() => set({ activity: l.id })}
          />
        ))}
      </VStack>
    </ScreenLayout>
  );
}

// ─── 6. Diet ─────────────────────────────────────────────────────────────

function Chip({ label, selected, onClick }) {
  const { t } = useBC();
  return (
    <div onClick={onClick} style={{
      display: 'inline-flex', alignItems: 'center', gap: 6,
      padding: '10px 14px', height: 40, boxSizing: 'border-box',
      borderRadius: 999,
      background: selected ? t.primary : t.surface,
      color: selected ? '#fff' : t.text,
      border: `${selected ? 0 : 1}px solid ${t.separator}`,
      fontSize: 14, fontWeight: 600, letterSpacing: -0.1,
      cursor: 'pointer', WebkitTapHighlightColor: 'transparent',
      transition: 'background .12s, color .12s',
    }}>
      {selected && <BCIcon name="check" size={14} color="#fff" strokeWidth={2.6} />}
      {label}
    </div>
  );
}

function ScreenDiet({ mode, state, set, onNext, onBack }) {
  const t = mode === 'dark' ? BC_DARK : BC_LIGHT;
  const opts = ['None', 'Vegetarian', 'Vegan', 'Keto', 'Paleo', 'Gluten-free', 'Dairy-free', 'Halal', 'Kosher'];
  const toggle = (o) => {
    let next;
    if (o === 'None') next = ['None'];
    else {
      const cur = state.diet.filter(x => x !== 'None');
      next = cur.includes(o) ? cur.filter(x => x !== o) : [...cur, o];
      if (next.length === 0) next = ['None'];
    }
    set({ diet: next });
  };
  return (
    <ScreenLayout mode={mode} step={5} totalSteps={7} onBack={onBack} onNext={onNext}
      title="Any dietary preferences?"
      subtitle="Optional. We'll filter foods and meal suggestions accordingly. Pick as many as apply."
    >
      <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8 }}>
        {opts.map(o => (
          <Chip key={o} label={o} selected={state.diet.includes(o)} onClick={() => toggle(o)} />
        ))}
      </div>

      <div style={{
        marginTop: 24, padding: '14px 16px',
        background: t.surface, border: '1px solid ' + t.separator,
        borderRadius: BC_RADIUS.md,
        display: 'flex', gap: 12, alignItems: 'flex-start',
      }}>
        <div style={{
          width: 32, height: 32, borderRadius: 8,
          background: t.tealSoft, color: t.teal,
          display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0,
        }}><BCIcon name="info" size={18} color={t.teal} /></div>
        <div>
          <div style={{ fontSize: 14, fontWeight: 700, color: t.text }}>You can change this anytime</div>
          <div style={{ fontSize: 13, color: t.textSec, marginTop: 2, lineHeight: '18px' }}>
            We'll never block you from logging foods that don't match — preferences just sort recommendations.
          </div>
        </div>
      </div>
    </ScreenLayout>
  );
}

// ─── 7. Macro targets ────────────────────────────────────────────────────

function ScreenTargets({ mode, state, set, onNext, onBack }) {
  const t = mode === 'dark' ? BC_DARK : BC_LIGHT;
  const { kcal, p, c, f } = state.targets;

  return (
    <ScreenLayout mode={mode} step={6} totalSteps={7} onBack={onBack} onNext={onNext}
      title="Your daily targets"
      subtitle="Calculated from your goal, stats, and activity. These adapt over time based on your real data."
    >
      <VStack gap={16}>
        {/* Hero card */}
        <div style={{
          background: t.surface, border: '1px solid ' + t.separator,
          borderRadius: BC_RADIUS.lg,
          padding: 22,
        }}>
          <div style={{ display: 'flex', alignItems: 'flex-end', gap: 14 }}>
            <BCMacroRing size={120} stroke={13}
              values={{ c: 0.01, p: 0.01, f: 0.01 }}
              showCenter={false}
            />
            <div style={{ flex: 1, paddingBottom: 4 }}>
              <div style={{ fontSize: 11, fontWeight: 700, color: t.textTer, letterSpacing: 0.8, textTransform: 'uppercase' }}>Daily calories</div>
              <div style={{ fontSize: 40, fontWeight: 800, color: t.text, letterSpacing: -1.2, fontVariantNumeric: 'tabular-nums', lineHeight: 1, marginTop: 4 }}>
                {kcal.toLocaleString()}
              </div>
              <div style={{ fontSize: 13, color: t.textSec, marginTop: 6, fontWeight: 500 }}>kcal / day</div>
            </div>
          </div>

          <div style={{ height: 1, background: t.separator, margin: '18px -4px 16px' }} />

          {/* macro rows */}
          <VStack gap={12}>
            {[
              ['Protein', p, 140, t.protein],
              ['Carbs',   c, 250, t.carbs],
              ['Fat',     f, 65,  t.fat],
            ].map(([name, val, _max, color]) => (
              <div key={name}>
                <HStack gap={10}>
                  <span style={{ width: 8, height: 8, borderRadius: 999, background: color }} />
                  <span style={{ fontSize: 14, fontWeight: 700, color: t.text }}>{name}</span>
                  <span style={{ marginLeft: 'auto', fontSize: 14, color: t.text, fontWeight: 700, fontVariantNumeric: 'tabular-nums' }}>
                    {val}<span style={{ fontSize: 12, color: t.textSec, fontWeight: 500 }}>g</span>
                  </span>
                  <span style={{ fontSize: 12, color: t.textTer, width: 36, textAlign: 'right', fontVariantNumeric: 'tabular-nums' }}>
                    {Math.round((val * (name === 'Fat' ? 9 : 4) / kcal) * 100)}%
                  </span>
                </HStack>
              </div>
            ))}
          </VStack>
        </div>

        {/* edit manually */}
        <div style={{
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          padding: '14px 0',
        }}>
          <span style={{ fontSize: 15, fontWeight: 600, color: t.primary, letterSpacing: -0.2 }}>
            Edit targets manually
          </span>
        </div>

        {/* small explanation */}
        <div style={{
          padding: '12px 14px', background: t.primarySoft, borderRadius: BC_RADIUS.md,
          fontSize: 12, color: t.text, lineHeight: '17px', display: 'flex', gap: 10,
        }}>
          <BCIcon name="spark" size={18} color={t.primary} style={{ flexShrink: 0, marginTop: 1 }} />
          <span><b>Your Coach will tune these as you go.</b> If you stall for two weeks, we suggest a small adjustment.</span>
        </div>
      </VStack>
    </ScreenLayout>
  );
}

// ─── 8. Apple Health ─────────────────────────────────────────────────────

function ScreenHealth({ mode, state, set, onNext, onBack }) {
  const t = mode === 'dark' ? BC_DARK : BC_LIGHT;

  const HeartIcon = ({ size = 100 }) => (
    <svg width={size} height={size} viewBox="0 0 100 100" fill="none">
      <circle cx="50" cy="50" r="48" fill="#FF3B30" opacity="0.10" />
      <path d="M50 78c-1-1-22-15-22-32 0-9 7-16 15-16 4 0 8 2 11 6 3-4 7-6 11-6 8 0 15 7 15 16C72 63 51 77 50 78z"
        fill="#FF3B30"/>
    </svg>
  );

  return (
    <ScreenLayout mode={mode} step={7} totalSteps={7} onBack={onBack} onNext={onNext}
      ctaLabel="Connect Apple Health"
      secondaryCta={
        <BCButton kind="plain" size="lg" block onClick={onNext}>Skip for now</BCButton>
      }
    >
      <VStack gap={16} style={{ alignItems: 'center', textAlign: 'center', paddingTop: 8 }}>
        <HeartIcon size={104} />
        <div style={{ fontSize: 26, fontWeight: 800, color: t.text, letterSpacing: -0.6, marginTop: 2 }}>
          Connect Apple Health
        </div>
        <div style={{ fontSize: 15, color: t.textSec, lineHeight: '21px', maxWidth: 300, textWrap: 'pretty' }}>
          Skip manual entry. BluCal syncs two-way with Apple Health so your data stays in one place.
        </div>
      </VStack>

      <div style={{ marginTop: 22, display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10 }}>
        <div style={{
          background: t.surface, border: '1px solid ' + t.separator,
          borderRadius: BC_RADIUS.md, padding: 14,
        }}>
          <div style={{ fontSize: 11, fontWeight: 700, color: t.teal, letterSpacing: 0.8, textTransform: 'uppercase' }}>BluCal reads</div>
          <VStack gap={8} style={{ marginTop: 10 }}>
            {[
              'Workouts',
              'Body weight',
              'Active energy',
              'Standing minutes',
            ].map(s => (
              <HStack key={s} gap={8}>
                <BCIcon name="check" size={14} color={t.teal} strokeWidth={2.6} />
                <span style={{ fontSize: 13, color: t.text }}>{s}</span>
              </HStack>
            ))}
          </VStack>
        </div>
        <div style={{
          background: t.surface, border: '1px solid ' + t.separator,
          borderRadius: BC_RADIUS.md, padding: 14,
        }}>
          <div style={{ fontSize: 11, fontWeight: 700, color: t.primary, letterSpacing: 0.8, textTransform: 'uppercase' }}>BluCal writes</div>
          <VStack gap={8} style={{ marginTop: 10 }}>
            {[
              'Dietary energy',
              'Protein, carbs, fat',
              'Water intake',
              'Caffeine',
            ].map(s => (
              <HStack key={s} gap={8}>
                <BCIcon name="check" size={14} color={t.primary} strokeWidth={2.6} />
                <span style={{ fontSize: 13, color: t.text }}>{s}</span>
              </HStack>
            ))}
          </VStack>
        </div>
      </div>

      <div style={{
        marginTop: 16, padding: '10px 14px',
        background: t.surface2,
        borderRadius: BC_RADIUS.md,
        display: 'flex', gap: 8, fontSize: 12, color: t.textSec, lineHeight: '17px',
      }}>
        <BCIcon name="info" size={16} color={t.textSec} style={{ flexShrink: 0, marginTop: 1 }} />
        <span>You control exactly what's shared. Change permissions anytime in iOS Settings → Health.</span>
      </div>
    </ScreenLayout>
  );
}

// ─── Controller ──────────────────────────────────────────────────────────

const DEFAULT_STATE = {
  goal: null,
  sex: 'Female',
  age: 32,
  weight: 168, weightUnit: 'lbs',
  feet: 5, inches: 7, cm: 170, heightUnit: 'ft/in',
  goalWeight: 150,
  activity: null,
  diet: ['None'],
  targets: { kcal: 1830, p: 150, c: 172, f: 60 },
};

function OnboardingFlow({ mode, startStep = 0, autoFill = false }) {
  const [step, setStep] = React.useState(startStep);
  const [state, setState] = React.useState(() => {
    // For preview screens we pre-fill so a single screen looks "in progress"
    if (!autoFill) return DEFAULT_STATE;
    return {
      ...DEFAULT_STATE,
      goal: 'lose',
      activity: 'moderate',
      diet: ['Vegetarian'],
    };
  });
  const set = (patch) => setState(s => ({ ...s, ...patch }));
  const next = () => setStep(s => Math.min(7, s + 1));
  const back = () => setStep(s => Math.max(0, s - 1));

  const screens = [
    <ScreenWelcome    mode={mode} state={state} set={set} onNext={next} onBack={back} />,
    <ScreenGoal       mode={mode} state={state} set={set} onNext={next} onBack={back} />,
    <ScreenStats      mode={mode} state={state} set={set} onNext={next} onBack={back} />,
    <ScreenGoalWeight mode={mode} state={state} set={set} onNext={next} onBack={back} />,
    <ScreenActivity   mode={mode} state={state} set={set} onNext={next} onBack={back} />,
    <ScreenDiet       mode={mode} state={state} set={set} onNext={next} onBack={back} />,
    <ScreenTargets    mode={mode} state={state} set={set} onNext={next} onBack={back} />,
    <ScreenHealth     mode={mode} state={state} set={set} onNext={next} onBack={back} />,
  ];

  return screens[step];
}

// Pinned-step renderer for the gallery — uses fresh per-screen state so each
// preview phone shows its assigned screen in a representative filled-in state.
function PinnedStep({ mode, step }) {
  const seed = {
    ...DEFAULT_STATE,
    goal: step >= 1 ? 'lose' : null,
    activity: step >= 4 ? 'moderate' : null,
    diet: step >= 5 ? ['Vegetarian', 'Gluten-free'] : ['None'],
  };
  const [state, setLocal] = React.useState(seed);
  const set = (patch) => setLocal(s => ({ ...s, ...patch }));
  const noop = () => {};
  const screens = [
    <ScreenWelcome    mode={mode} state={state} set={set} onNext={noop} onBack={noop} />,
    <ScreenGoal       mode={mode} state={state} set={set} onNext={noop} onBack={noop} />,
    <ScreenStats      mode={mode} state={state} set={set} onNext={noop} onBack={noop} />,
    <ScreenGoalWeight mode={mode} state={state} set={set} onNext={noop} onBack={noop} />,
    <ScreenActivity   mode={mode} state={state} set={set} onNext={noop} onBack={noop} />,
    <ScreenDiet       mode={mode} state={state} set={set} onNext={noop} onBack={noop} />,
    <ScreenTargets    mode={mode} state={state} set={set} onNext={noop} onBack={noop} />,
    <ScreenHealth     mode={mode} state={state} set={set} onNext={noop} onBack={noop} />,
  ];
  return screens[step];
}

Object.assign(window, { OnboardingFlow, PinnedStep });
