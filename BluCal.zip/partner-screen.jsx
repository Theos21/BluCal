// partner-screen.jsx — Profile › Train together (partner)

function PTStatusBar({ mode }) {
  const c = mode === 'dark' ? '#fff' : '#000';
  return (
    <div style={{
      height: 54, padding: '14px 28px 0',
      display: 'flex', alignItems: 'center', justifyContent: 'space-between',
      fontSize: 17, fontWeight: 600, letterSpacing: -0.41, color: c, fontFamily: SF_STACK,
    }}>
      <span style={{ fontVariantNumeric: 'tabular-nums' }}>9:41</span>
      <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
        <svg width="18" height="11" viewBox="0 0 18 11">
          <rect x="0" y="7" width="3" height="4" rx="0.6" fill={c}/>
          <rect x="5" y="5" width="3" height="6" rx="0.6" fill={c}/>
          <rect x="10" y="3" width="3" height="8" rx="0.6" fill={c}/>
          <rect x="15" y="0" width="3" height="11" rx="0.6" fill={c}/>
        </svg>
        <svg width="26" height="12" viewBox="0 0 26 12">
          <rect x="0.5" y="0.5" width="22" height="11" rx="3" stroke={c} strokeOpacity="0.4" fill="none"/>
          <rect x="2" y="2" width="19" height="8" rx="1.5" fill={c}/>
          <rect x="23.5" y="4" width="1.5" height="4" rx="0.7" fill={c} fillOpacity="0.4"/>
        </svg>
      </div>
    </div>
  );
}

function PTNavBar({ mode }) {
  const t = mode === 'dark' ? BC_DARK : BC_LIGHT;
  return (
    <div style={{ height: 44, padding: '0 8px', display: 'flex', alignItems: 'center' }}>
      <button style={{
        height: 32, padding: '0 8px 0 4px', border: 'none', background: 'transparent',
        display: 'inline-flex', alignItems: 'center', gap: 2,
        color: t.primary, fontSize: 17, letterSpacing: -0.41,
        fontFamily: SF_STACK, cursor: 'pointer',
      }}>
        <BCIcon name="chev" size={20} color={t.primary} style={{ transform: 'scaleX(-1)' }} />
        <span>Profile</span>
      </button>
      <div style={{ flex: 1, textAlign: 'center', fontSize: 17, fontWeight: 600, color: t.text, letterSpacing: -0.41 }}>
        Train together
      </div>
      <div style={{ width: 80 }} />
    </div>
  );
}

// ─── Two-figure illustration ─────────────────────────────────────────
function TwoFigures({ mode, size = 130 }) {
  const t = mode === 'dark' ? BC_DARK : BC_LIGHT;
  return (
    <svg width={size * 1.8} height={size} viewBox="0 0 240 130" fill="none">
      {/* shared baseline ellipse */}
      <ellipse cx="120" cy="118" rx="100" ry="8" fill={t.primarySoft} />
      {/* figure 1 — brand blue silhouette */}
      <g transform="translate(64, 14)">
        <circle cx="22" cy="18" r="14" fill={t.primary}/>
        <path d="M 6 38 Q 22 32 38 38 L 40 92 Q 32 100 22 100 Q 12 100 4 92 Z" fill={t.primary} />
        <rect x="12" y="92" width="8" height="14" rx="3" fill={t.primary} />
        <rect x="24" y="92" width="8" height="14" rx="3" fill={t.primary} />
      </g>
      {/* figure 2 — teal silhouette */}
      <g transform="translate(132, 18)">
        <circle cx="22" cy="18" r="14" fill={t.teal}/>
        <path d="M 6 38 Q 22 32 38 38 L 40 88 Q 32 96 22 96 Q 12 96 4 88 Z" fill={t.teal} />
        <rect x="12" y="88" width="8" height="14" rx="3" fill={t.teal} />
        <rect x="24" y="88" width="8" height="14" rx="3" fill={t.teal} />
      </g>
      {/* link between heads */}
      <path d="M 100 30 Q 120 12 154 32" stroke={t.primary} strokeWidth="2" strokeLinecap="round" strokeDasharray="2 4" fill="none" opacity="0.55"/>
      {/* heart between */}
      <g transform="translate(110, 0)">
        <path d="M 10 14 C 6 8 0 8 0 14 C 0 20 10 26 10 26 C 10 26 20 20 20 14 C 20 8 14 8 10 14 Z" fill={t.danger} opacity="0.85" />
      </g>
    </svg>
  );
}

// ─── No-partner state ────────────────────────────────────────────────
function NoPartnerState({ mode }) {
  const t = mode === 'dark' ? BC_DARK : BC_LIGHT;
  return (
    <div style={{ padding: '24px 20px 24px' }}>
      <div style={{ display: 'flex', justifyContent: 'center', marginTop: 8 }}>
        <TwoFigures mode={mode} size={130} />
      </div>
      <div style={{ textAlign: 'center', marginTop: 18 }}>
        <div style={{ fontSize: 28, fontWeight: 800, color: t.text, letterSpacing: -0.6, lineHeight: '34px' }}>
          Train together
        </div>
        <div style={{ fontSize: 15, color: t.textSec, marginTop: 10, lineHeight: '22px', textWrap: 'pretty', maxWidth: 320, marginLeft: 'auto', marginRight: 'auto' }}>
          Invite a friend to see your weekly progress. They see your summary —
          <b style={{ color: t.text }}> not your individual meals</b>.
        </div>
      </div>

      {/* What's shared list */}
      <div style={{
        marginTop: 20, padding: '12px 16px',
        background: t.surface, border: '1px solid ' + t.separator, borderRadius: BC_RADIUS.lg,
      }}>
        <div style={{ fontSize: 11, fontWeight: 700, color: t.textTer, letterSpacing: 0.6, textTransform: 'uppercase' }}>
          What they see
        </div>
        <div style={{ marginTop: 10, display: 'flex', flexDirection: 'column', gap: 8 }}>
          {[
            ['Weekly summary',     true],
            ['Streaks & momentum', true],
            ['Weight trend direction', true],
            ['Your daily meals',   false],
            ['Photos & body measurements', false],
          ].map(([label, ok]) => (
            <div key={label} style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
              {ok ? (
                <div style={{
                  width: 18, height: 18, borderRadius: 999, background: t.success, color: '#fff',
                  display: 'flex', alignItems: 'center', justifyContent: 'center',
                }}>
                  <BCIcon name="check" size={11} color="#fff" strokeWidth={3} />
                </div>
              ) : (
                <div style={{
                  width: 18, height: 18, borderRadius: 999, background: t.surface2,
                  border: '1.5px solid ' + t.hairline,
                  display: 'flex', alignItems: 'center', justifyContent: 'center', color: t.textTer,
                }}>
                  <BCIcon name="close" size={11} color={t.textTer} strokeWidth={2.4} />
                </div>
              )}
              <span style={{ fontSize: 14, color: ok ? t.text : t.textSec, fontWeight: ok ? 600 : 500 }}>{label}</span>
            </div>
          ))}
        </div>
      </div>

      {/* CTA */}
      <div style={{ marginTop: 22 }}>
        <BCButton kind="primary" size="lg" block
          icon={<BCIcon name="plus" size={20} color="#fff" strokeWidth={2.4} />}>
          Invite a partner
        </BCButton>
      </div>
    </div>
  );
}

// ─── Partner-connected state ─────────────────────────────────────────
function ConnectedState({ mode }) {
  const t = mode === 'dark' ? BC_DARK : BC_LIGHT;
  const [sent, setSent] = React.useState(null);

  const nudges = [
    { label: 'Keep going!', emoji: '🔥' },
    { label: 'Great week!', emoji: '🎉' },
    { label: 'Check in',    emoji: '👋' },
  ];

  return (
    <div style={{ padding: '12px 16px 24px' }}>
      {/* Header card with avatar + status */}
      <div style={{
        background: t.surface, border: '1px solid ' + t.separator, borderRadius: BC_RADIUS.lg,
        padding: '16px',
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 14 }}>
          <div style={{
            width: 60, height: 60, borderRadius: 999,
            background: t.teal, color: '#fff',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            fontSize: 22, fontWeight: 800, letterSpacing: 0.2, flexShrink: 0,
            boxShadow: '0 0 0 3px ' + t.bg + ', 0 0 0 4.5px ' + t.tealSoft,
          }}>SJ</div>
          <div style={{ flex: 1, minWidth: 0 }}>
            <div style={{ fontSize: 18, fontWeight: 800, color: t.text, letterSpacing: -0.3 }}>Sarah J.</div>
            <div style={{ fontSize: 13, color: t.textSec, marginTop: 2 }}>
              Training partner · Connected 4 weeks
            </div>
            <div style={{ display: 'inline-flex', alignItems: 'center', gap: 6, marginTop: 6 }}>
              <span style={{ width: 7, height: 7, borderRadius: 999, background: t.success }} />
              <span style={{ fontSize: 12, fontWeight: 700, color: t.success, letterSpacing: 0.1 }}>
                Logged today · 1h ago
              </span>
            </div>
          </div>
          {/* Momentum ring */}
          <div style={{ position: 'relative', width: 64, height: 64, flexShrink: 0 }}>
            <svg width="64" height="64" viewBox="0 0 64 64">
              <circle cx="32" cy="32" r="26" stroke={t.surface2} strokeWidth="7" fill="none" />
              <circle cx="32" cy="32" r="26"
                stroke={t.success} strokeWidth="7" fill="none"
                strokeDasharray={2 * Math.PI * 26}
                strokeDashoffset={2 * Math.PI * 26 * (1 - 0.79)}
                strokeLinecap="round"
                transform="rotate(-90 32 32)"
              />
            </svg>
            <div style={{
              position: 'absolute', inset: 0,
              display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center',
            }}>
              <span style={{ fontSize: 17, fontWeight: 800, color: t.text, letterSpacing: -0.3, lineHeight: 1, fontVariantNumeric: 'tabular-nums' }}>79</span>
              <span style={{ fontSize: 8, color: t.textTer, fontWeight: 700, letterSpacing: 0.3, textTransform: 'uppercase', marginTop: 1 }}>WK</span>
            </div>
          </div>
        </div>
      </div>

      {/* Nudge bar */}
      <div style={{
        marginTop: 12, padding: '14px 16px',
        background: t.surface, border: '1px solid ' + t.separator, borderRadius: BC_RADIUS.lg,
      }}>
        <div style={{ display: 'flex', alignItems: 'baseline', justifyContent: 'space-between' }}>
          <span style={{ fontSize: 11, fontWeight: 700, color: t.textTer, letterSpacing: 0.6, textTransform: 'uppercase' }}>
            Send a nudge
          </span>
          {sent && (
            <span style={{ fontSize: 12, fontWeight: 700, color: t.success }}>
              ✓ Sent · {sent}
            </span>
          )}
        </div>
        <div style={{ display: 'flex', gap: 8, marginTop: 10 }}>
          {nudges.map(n => (
            <button key={n.label} onClick={() => setSent(n.label)} style={{
              flex: 1, padding: '10px 8px',
              background: sent === n.label ? t.primary : t.surface2,
              border: sent === n.label ? '1px solid ' + t.primary : '1px solid ' + t.separator,
              color: sent === n.label ? '#fff' : t.text,
              borderRadius: 12, cursor: 'pointer', fontFamily: SF_STACK,
              display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 4,
              WebkitTapHighlightColor: 'transparent',
            }}>
              <span style={{ fontSize: 22, lineHeight: 1 }}>{n.emoji}</span>
              <span style={{ fontSize: 12, fontWeight: 700, letterSpacing: -0.1 }}>{n.label}</span>
            </button>
          ))}
        </div>
      </div>

      {/* Weekly summary */}
      <div style={{
        marginTop: 12, padding: '14px 16px',
        background: t.surface, border: '1px solid ' + t.separator, borderRadius: BC_RADIUS.lg,
      }}>
        <div style={{ display: 'flex', alignItems: 'baseline', justifyContent: 'space-between' }}>
          <span style={{ fontSize: 11, fontWeight: 700, color: t.textTer, letterSpacing: 0.6, textTransform: 'uppercase' }}>
            Sarah's week · May 6 – 12
          </span>
          <span style={{ fontSize: 12, fontWeight: 600, color: t.primary }}>Full history</span>
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 12, marginTop: 12 }}>
          {[
            { label: 'Avg calories', value: '1,920', sub: 'kcal/day', color: t.text },
            { label: 'Weight trend', value: '↓', sub: '−0.6 lb/wk', color: t.success, big: true },
            { label: 'Streak',       value: '14', sub: 'days', color: t.primary },
          ].map((stat, i) => (
            <div key={i} style={{ textAlign: 'left' }}>
              <div style={{ fontSize: 10, fontWeight: 700, color: t.textTer, letterSpacing: 0.4, textTransform: 'uppercase' }}>{stat.label}</div>
              <div style={{ fontSize: stat.big ? 28 : 22, fontWeight: 800, color: stat.color, letterSpacing: -0.4, fontVariantNumeric: 'tabular-nums', lineHeight: 1, marginTop: 5 }}>
                {stat.value}
              </div>
              <div style={{ fontSize: 11, color: t.textSec, marginTop: 3, fontWeight: 600 }}>{stat.sub}</div>
            </div>
          ))}
        </div>
        <div style={{ height: 1, background: t.separator, margin: '14px -2px 12px' }} />
        {/* Tiny calorie bar week */}
        <div style={{ display: 'flex', alignItems: 'flex-end', gap: 5, height: 40 }}>
          {[1820, 2110, 1950, 2050, 1880, 2020, 1860].map((v, i) => (
            <div key={i} style={{
              flex: 1, height: ((v - 1700) / 600) * 100 + '%',
              background: i === 6 ? t.primary : t.primarySoft,
              borderRadius: 4,
            }} />
          ))}
        </div>
        <div style={{ display: 'flex', justifyContent: 'space-between', marginTop: 4, fontSize: 10, color: t.textTer, fontWeight: 600 }}>
          {['M', 'T', 'W', 'T', 'F', 'S', 'S'].map((d, i) => <span key={i}>{d}</span>)}
        </div>
      </div>

      {/* Disconnect */}
      <div style={{ marginTop: 16 }}>
        <button style={{
          width: '100%', padding: '14px',
          background: 'transparent', border: 'none',
          color: t.danger, fontSize: 15, fontWeight: 600, letterSpacing: -0.2,
          cursor: 'pointer', fontFamily: SF_STACK,
        }}>
          Disconnect partner
        </button>
      </div>
    </div>
  );
}

// ─── Wrapper ─────────────────────────────────────────────────────────
function PartnerScreen({ mode = 'light', state = 'empty' }) {
  return (
    <BCTheme mode={mode} padding={0} style={{ position: 'relative', overflow: 'hidden', height: '100%' }}>
      <PTStatusBar mode={mode} />
      <PTNavBar mode={mode} />
      <div style={{ position: 'absolute', top: 54 + 44, left: 0, right: 0, bottom: 0, overflowY: 'auto', overflowX: 'hidden' }}>
        {state === 'empty' ? <NoPartnerState mode={mode} /> : <ConnectedState mode={mode} />}
      </div>
    </BCTheme>
  );
}

Object.assign(window, { PartnerScreen });
