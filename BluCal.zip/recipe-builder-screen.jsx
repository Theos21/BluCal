// recipe-builder-screen.jsx — Recipe builder with ingredients, details + import-from-URL sheet

function RBStatusBar({ mode }) {
  const c = mode === 'dark' ? '#fff' : '#000';
  return (
    <div style={{
      height: 54, padding: '14px 28px 0',
      display: 'flex', alignItems: 'center', justifyContent: 'space-between',
      fontSize: 17, fontWeight: 600, letterSpacing: -0.41, color: c,
      fontFamily: SF_STACK,
    }}>
      <span style={{ fontVariantNumeric: 'tabular-nums' }}>9:41</span>
      <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
        <svg width="18" height="11" viewBox="0 0 18 11">
          <rect x="0" y="7" width="3" height="4" rx="0.6" fill={c}/>
          <rect x="5" y="5" width="3" height="6" rx="0.6" fill={c}/>
          <rect x="10" y="3" width="3" height="8" rx="0.6" fill={c}/>
          <rect x="15" y="0" width="3" height="11" rx="0.6" fill={c}/>
        </svg>
        <svg width="26" height="12" viewBox="0 0 26 12">
          <rect x="0.5" y="0.5" width="22" height="11" rx="3" stroke={c} strokeOpacity="0.4" fill="none"/>
          <rect x="2" y="2" width="19" height="8" rx="1.5" fill={c}/>
          <rect x="23.5" y="4" width="1.5" height="4" rx="0.7" fill={c} fillOpacity="0.4"/>
        </svg>
      </div>
    </div>
  );
}

function RBNavBar({ mode, onCancel, onImport }) {
  const t = mode === 'dark' ? BC_DARK : BC_LIGHT;
  return (
    <div style={{
      height: 52, padding: '0 16px',
      display: 'flex', alignItems: 'center',
      borderBottom: '0.5px solid ' + t.separator,
      background: t.bg,
      position: 'relative',
    }}>
      <button onClick={onCancel} style={{
        height: 32, padding: '0 4px', border: 'none', background: 'transparent',
        color: t.primary, fontSize: 17, letterSpacing: -0.41, fontFamily: SF_STACK, cursor: 'pointer',
      }}>Cancel</button>
      <div style={{
        position: 'absolute', inset: 0,
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        pointerEvents: 'none',
        fontSize: 17, fontWeight: 600, color: t.text, lineHeight: '22px',
      }}>Recipe</div>
      <div style={{ flex: 1 }} />
      <button onClick={onImport} style={{
        height: 32, padding: '0 10px',
        background: t.primarySoft, color: t.primary,
        border: 'none', borderRadius: 999,
        fontSize: 13, fontWeight: 700, fontFamily: SF_STACK,
        cursor: 'pointer',
        display: 'inline-flex', alignItems: 'center', gap: 5,
      }}>
        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke={t.primary} strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
          <path d="M10 13a5 5 0 007.5.5l3-3a5 5 0 00-7-7l-1.5 1.5"/>
          <path d="M14 11a5 5 0 00-7.5-.5l-3 3a5 5 0 007 7l1.5-1.5"/>
        </svg>
        Import URL
      </button>
    </div>
  );
}

// ─── Ingredient row ───────────────────────────────────────────────────
function IngredientRow({ mode, ing, first, last, onRemove }) {
  const t = mode === 'dark' ? BC_DARK : BC_LIGHT;
  return (
    <div style={{
      background: t.surface,
      borderTopLeftRadius: first ? BC_RADIUS.lg : 0,
      borderTopRightRadius: first ? BC_RADIUS.lg : 0,
      borderBottomLeftRadius: last ? BC_RADIUS.lg : 0,
      borderBottomRightRadius: last ? BC_RADIUS.lg : 0,
      borderTop: first ? '1px solid ' + t.separator : 'none',
      borderBottom: last ? '1px solid ' + t.separator : '0.5px solid ' + t.separator,
      borderLeft: '1px solid ' + t.separator,
      borderRight: '1px solid ' + t.separator,
      padding: '12px 14px',
      display: 'flex', alignItems: 'center', gap: 10,
    }}>
      {/* drag handle */}
      <div style={{ color: t.textTer, cursor: 'grab', display: 'flex', alignItems: 'center', flexShrink: 0 }}>
        <svg width="14" height="20" viewBox="0 0 14 20" fill="currentColor">
          <circle cx="4" cy="4" r="1.4"/><circle cx="10" cy="4" r="1.4"/>
          <circle cx="4" cy="10" r="1.4"/><circle cx="10" cy="10" r="1.4"/>
          <circle cx="4" cy="16" r="1.4"/><circle cx="10" cy="16" r="1.4"/>
        </svg>
      </div>
      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{ fontSize: 15, fontWeight: 600, color: t.text, letterSpacing: -0.2,
          whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{ing.name}</div>
        <div style={{ fontSize: 12, color: t.textSec, marginTop: 2 }}>
          {ing.qty} {ing.unit} · <span style={{ fontWeight: 600, color: t.text }}>{ing.kcal}</span> kcal
        </div>
      </div>
      <button onClick={onRemove} style={{
        width: 28, height: 28, borderRadius: 999, border: 'none',
        background: t.surface2, color: t.textSec,
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        cursor: 'pointer', flexShrink: 0,
      }} aria-label="Remove ingredient">
        <BCIcon name="close" size={14} color={t.textSec} strokeWidth={2.4} />
      </button>
    </div>
  );
}

// ─── Import-from-URL bottom sheet ─────────────────────────────────────
function ImportSheet({ mode, state = 'input', onClose, onConfirm }) {
  const t = mode === 'dark' ? BC_DARK : BC_LIGHT;
  const [url, setUrl] = React.useState('https://cooking.nytimes.com/recipes/1014820-chicken-pesto-pasta');
  return (
    <>
      <div onClick={onClose} style={{
        position: 'absolute', inset: 0, background: t.scrim, zIndex: 20,
      }} />
      <div style={{
        position: 'absolute', left: 0, right: 0, bottom: 0, zIndex: 21,
        background: t.surface,
        borderTopLeftRadius: 22, borderTopRightRadius: 22,
        boxShadow: '0 -10px 40px rgba(0,0,0,0.30)',
        padding: '8px 18px 24px',
      }}>
        <div style={{ display: 'flex', justifyContent: 'center', padding: '4px 0 8px' }}>
          <div style={{ width: 38, height: 5, borderRadius: 999, background: t.hairline }} />
        </div>
        <div style={{ display: 'flex', alignItems: 'center', marginBottom: 6 }}>
          <div style={{ flex: 1, fontSize: 18, fontWeight: 700, color: t.text, letterSpacing: -0.3 }}>Import from URL</div>
          <button onClick={onClose} style={{
            width: 30, height: 30, borderRadius: 999, background: t.surface2, border: 'none',
            color: t.textSec, display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer',
          }}><BCIcon name="close" size={14} color={t.textSec} strokeWidth={2.4} /></button>
        </div>
        <div style={{ fontSize: 13, color: t.textSec, marginBottom: 16, lineHeight: '18px' }}>
          Paste a recipe link. BluCal will pull ingredients, yield, and nutrition.
        </div>

        {state === 'input' && (
          <>
            <div style={{
              display: 'flex', alignItems: 'center', gap: 8,
              height: 48, padding: '0 14px',
              background: t.surface2, borderRadius: 12,
              border: '2px solid ' + t.primary,
              marginBottom: 12,
            }}>
              {/* link icon */}
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke={t.textSec} strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
                <path d="M10 13a5 5 0 007.5.5l3-3a5 5 0 00-7-7l-1.5 1.5"/>
                <path d="M14 11a5 5 0 00-7.5-.5l-3 3a5 5 0 007 7l1.5-1.5"/>
              </svg>
              <input value={url} onChange={(e) => setUrl(e.target.value)}
                placeholder="https://…"
                style={{
                  flex: 1, minWidth: 0, background: 'transparent', border: 'none', outline: 'none',
                  fontSize: 15, color: t.text, fontFamily: SF_STACK, letterSpacing: -0.2,
                  fontVariantNumeric: 'tabular-nums',
                }} />
            </div>
            {/* Supported sites */}
            <div style={{
              fontSize: 11, fontWeight: 700, color: t.textTer, letterSpacing: 0.5, textTransform: 'uppercase',
              marginBottom: 8,
            }}>Works with</div>
            <div style={{ display: 'flex', flexWrap: 'wrap', gap: 6, marginBottom: 14 }}>
              {['NYT Cooking', 'AllRecipes', 'Serious Eats', 'BBC Good Food', 'Smitten Kitchen', '+ 240 more'].map(s => (
                <span key={s} style={{
                  padding: '5px 10px', borderRadius: 999,
                  background: t.surface2, color: t.text,
                  fontSize: 12, fontWeight: 600,
                  border: '1px solid ' + t.separator,
                }}>{s}</span>
              ))}
            </div>
            <BCButton kind="primary" size="lg" block onClick={onConfirm}
              icon={
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#fff" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M12 4v12"/><path d="M6 10l6-6 6 6"/>
                </svg>
              }>
              Import
            </BCButton>
          </>
        )}

        {state === 'loading' && (
          <div style={{
            padding: '32px 8px',
            display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 18,
          }}>
            <div style={{
              width: 56, height: 56, borderRadius: 999,
              border: `3px solid ${t.surface2}`,
              borderTopColor: t.primary,
              animation: 'rb-spin 0.8s linear infinite',
            }} />
            <div style={{ textAlign: 'center' }}>
              <div style={{ fontSize: 17, fontWeight: 700, color: t.text, letterSpacing: -0.3 }}>Scraping recipe…</div>
              <div style={{ fontSize: 13, color: t.textSec, marginTop: 4 }}>cooking.nytimes.com</div>
            </div>
            <div style={{ width: '100%' }}>
              {[
                ['Fetched page',          true],
                ['Parsed ingredient list', true],
                ['Estimating nutrition',  false],
                ['Computing per serving', false],
              ].map(([label, done], i) => (
                <div key={i} style={{
                  display: 'flex', alignItems: 'center', gap: 10,
                  padding: '8px 0', borderBottom: i < 3 ? '0.5px solid ' + t.separator : 'none',
                }}>
                  {done ? (
                    <div style={{
                      width: 18, height: 18, borderRadius: 999,
                      background: t.success, color: '#fff',
                      display: 'flex', alignItems: 'center', justifyContent: 'center',
                    }}><BCIcon name="check" size={11} color="#fff" strokeWidth={3} /></div>
                  ) : (
                    <div style={{
                      width: 18, height: 18, borderRadius: 999, border: '2px solid ' + t.hairline,
                    }} />
                  )}
                  <span style={{ fontSize: 14, color: done ? t.text : t.textSec, fontWeight: done ? 600 : 500 }}>{label}</span>
                </div>
              ))}
            </div>
            <style>{`@keyframes rb-spin { to { transform: rotate(360deg) } }`}</style>
          </div>
        )}
      </div>
    </>
  );
}

// ─── Top-level recipe builder screen ──────────────────────────────────
function RecipeBuilderScreen({ mode = 'light', sheet, onCancel }) {
  const t = mode === 'dark' ? BC_DARK : BC_LIGHT;
  const [activeSheet, setActiveSheet] = React.useState(sheet || null);
  React.useEffect(() => { setActiveSheet(sheet || null); }, [sheet]);

  const [name, setName] = React.useState('Chicken pesto pasta');
  const [yieldServings, setYieldServings] = React.useState('4');

  const [ingredients, setIngredients] = React.useState([
    { name: 'Chicken breast',     qty: '1',  unit: 'lb',    kcal: 660 },
    { name: 'Penne pasta',        qty: '12', unit: 'oz',    kcal: 1200 },
    { name: 'Basil pesto',        qty: '½',  unit: 'cup',   kcal: 520 },
    { name: 'Cherry tomatoes',    qty: '1',  unit: 'cup',   kcal: 27 },
    { name: 'Parmesan, grated',   qty: '¼',  unit: 'cup',   kcal: 108 },
    { name: 'Olive oil',          qty: '2',  unit: 'tbsp',  kcal: 240 },
  ]);

  const total = ingredients.reduce((sum, i) => sum + i.kcal, 0);
  const servings = parseFloat(yieldServings) || 1;
  const perServingKcal = Math.round(total / servings);

  // Plausible per-serving macros derived from the recipe profile
  const perP = Math.round((perServingKcal * 0.28) / 4);
  const perC = Math.round((perServingKcal * 0.46) / 4);
  const perF = Math.round((perServingKcal * 0.26) / 9);

  return (
    <BCTheme mode={mode} padding={0} style={{ position: 'relative', overflow: 'hidden', height: '100%' }}>
      <RBStatusBar mode={mode} />
      <RBNavBar mode={mode} onCancel={onCancel} onImport={() => setActiveSheet('input')} />

      <div style={{ position: 'absolute', top: 54 + 52, left: 0, right: 0, bottom: 86, overflowY: 'auto', overflowX: 'hidden' }}>
        <div style={{ padding: '12px 16px 24px' }}>

          {/* Recipe details */}
          <div style={{
            padding: '20px 4px 8px',
            fontSize: 11, fontWeight: 700, letterSpacing: 0.6, textTransform: 'uppercase', color: t.textTer,
          }}>Recipe</div>

          <div>
            {/* Name row */}
            <div style={{
              background: t.surface,
              borderTopLeftRadius: BC_RADIUS.lg, borderTopRightRadius: BC_RADIUS.lg,
              border: '1px solid ' + t.separator, borderBottom: '0.5px solid ' + t.separator,
              padding: '12px 14px',
              display: 'flex', alignItems: 'center', gap: 12,
            }}>
              <div style={{ width: 100, fontSize: 14, fontWeight: 500, color: t.text }}>Name</div>
              <input value={name} onChange={(e) => setName(e.target.value)} style={{
                flex: 1, minWidth: 0, background: 'transparent', border: 'none', outline: 'none',
                fontSize: 16, fontWeight: 700, color: t.text,
                fontFamily: SF_STACK, letterSpacing: -0.2, textAlign: 'right',
              }} />
            </div>
            {/* Yield row */}
            <div style={{
              background: t.surface,
              borderBottomLeftRadius: BC_RADIUS.lg, borderBottomRightRadius: BC_RADIUS.lg,
              border: '1px solid ' + t.separator, borderTop: 'none',
              padding: '12px 14px',
              display: 'flex', alignItems: 'center', gap: 12,
            }}>
              <div style={{ width: 100, fontSize: 14, fontWeight: 500, color: t.text }}>Total yield</div>
              <input value={yieldServings} onChange={(e) => setYieldServings(e.target.value)} style={{
                flex: 1, minWidth: 0, background: 'transparent', border: 'none', outline: 'none',
                fontSize: 16, fontWeight: 700, color: t.text,
                fontFamily: SF_STACK, textAlign: 'right',
                fontVariantNumeric: 'tabular-nums',
              }} />
              <span style={{ fontSize: 14, color: t.textSec, fontWeight: 600 }}>servings</span>
            </div>
          </div>

          {/* Per-serving summary */}
          <div style={{ marginTop: 12 }}>
            <div style={{
              background: t.surface, border: '1px solid ' + t.separator, borderRadius: BC_RADIUS.lg,
              padding: '14px 16px',
            }}>
              <div style={{ display: 'flex', alignItems: 'baseline', justifyContent: 'space-between' }}>
                <div>
                  <div style={{ fontSize: 11, fontWeight: 700, color: t.textTer, letterSpacing: 0.6, textTransform: 'uppercase' }}>
                    Per serving
                  </div>
                  <div style={{ display: 'flex', alignItems: 'baseline', gap: 5, marginTop: 6 }}>
                    <span style={{ fontSize: 32, fontWeight: 800, color: t.text, letterSpacing: -0.6, lineHeight: 1, fontVariantNumeric: 'tabular-nums' }}>
                      {perServingKcal}
                    </span>
                    <span style={{ fontSize: 13, color: t.textSec, fontWeight: 600 }}>kcal</span>
                  </div>
                </div>
                <div style={{ display: 'flex', gap: 12, fontVariantNumeric: 'tabular-nums' }}>
                  {[
                    ['protein', perP, t.protein],
                    ['carbs',   perC, t.carbs],
                    ['fat',     perF, t.fat],
                  ].map(([label, val, c]) => (
                    <div key={label} style={{ textAlign: 'right' }}>
                      <div style={{ fontSize: 17, fontWeight: 800, color: c, lineHeight: 1 }}>{val}g</div>
                      <div style={{ fontSize: 10, color: t.textTer, marginTop: 3, fontWeight: 700, textTransform: 'uppercase', letterSpacing: 0.3 }}>{label}</div>
                    </div>
                  ))}
                </div>
              </div>
              <div style={{ height: 1, background: t.separator, margin: '12px 0' }} />
              <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 12 }}>
                <span style={{ color: t.textSec, fontWeight: 500 }}>Auto-calculated from ingredients</span>
                <span style={{ color: t.text, fontWeight: 600 }}>{total.toLocaleString()} kcal total · ÷ {servings}</span>
              </div>
            </div>
          </div>

          {/* Ingredients */}
          <div style={{
            padding: '20px 4px 8px',
            display: 'flex', alignItems: 'baseline', justifyContent: 'space-between',
          }}>
            <div style={{
              fontSize: 11, fontWeight: 700, letterSpacing: 0.6, textTransform: 'uppercase', color: t.textTer,
            }}>Ingredients · {ingredients.length}</div>
            <span style={{ fontSize: 12, color: t.textTer, fontWeight: 600, fontVariantNumeric: 'tabular-nums' }}>
              drag to reorder
            </span>
          </div>

          <div>
            {ingredients.map((ing, i) => (
              <IngredientRow key={i} mode={mode} ing={ing}
                first={i === 0}
                last={false}
                onRemove={() => setIngredients(arr => arr.filter((_, j) => j !== i))}
              />
            ))}
            {/* Add ingredient row */}
            <button style={{
              width: '100%',
              background: t.surface,
              borderBottomLeftRadius: BC_RADIUS.lg, borderBottomRightRadius: BC_RADIUS.lg,
              border: '1px solid ' + t.separator, borderTop: '0.5px solid ' + t.separator,
              padding: '14px 14px',
              display: 'flex', alignItems: 'center', gap: 10,
              color: t.primary, fontSize: 15, fontWeight: 700, letterSpacing: -0.2,
              cursor: 'pointer', textAlign: 'left',
              fontFamily: SF_STACK,
            }}>
              <div style={{
                width: 22, height: 22, borderRadius: 999, background: t.primarySoft,
                display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0,
              }}>
                <BCIcon name="plus" size={14} color={t.primary} strokeWidth={2.6} />
              </div>
              Add ingredient
              <span style={{ marginLeft: 'auto', fontSize: 12, color: t.textTer, fontWeight: 600 }}>search foods</span>
            </button>
          </div>

          {/* Helper tip */}
          <div style={{
            marginTop: 14, padding: '10px 14px',
            background: t.primarySoft, borderRadius: BC_RADIUS.md,
            display: 'flex', gap: 8, fontSize: 12, lineHeight: '17px', color: t.text,
          }}>
            <BCIcon name="info" size={14} color={t.primary} style={{ marginTop: 2, flexShrink: 0 }} />
            <span>Have a link? Use <b>Import URL</b> in the top right to pull in ingredients automatically.</span>
          </div>
        </div>
      </div>

      {/* Sticky save */}
      <div style={{
        position: 'absolute', left: 0, right: 0, bottom: 0,
        padding: '12px 16px 26px', background: t.bg,
        borderTop: '0.5px solid ' + t.separator,
      }}>
        <BCButton kind="primary" size="lg" block>Save recipe</BCButton>
      </div>

      {/* Import sheet overlay */}
      {activeSheet && (
        <ImportSheet mode={mode} state={activeSheet}
          onClose={() => setActiveSheet(null)}
          onConfirm={() => setActiveSheet('loading')}
        />
      )}
    </BCTheme>
  );
}

Object.assign(window, { RecipeBuilderScreen, ImportSheet });
