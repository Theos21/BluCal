// settings-screen.jsx — Profile › Settings (iOS-style grouped list)

function STStatusBar({ mode }) {
  const c = mode === 'dark' ? '#fff' : '#000';
  return (
    <div style={{
      height: 54, padding: '14px 28px 0',
      display: 'flex', alignItems: 'center', justifyContent: 'space-between',
      fontSize: 17, fontWeight: 600, letterSpacing: -0.41, color: c, fontFamily: SF_STACK,
    }}>
      <span style={{ fontVariantNumeric: 'tabular-nums' }}>9:41</span>
      <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
        <svg width="18" height="11" viewBox="0 0 18 11">
          <rect x="0" y="7" width="3" height="4" rx="0.6" fill={c}/>
          <rect x="5" y="5" width="3" height="6" rx="0.6" fill={c}/>
          <rect x="10" y="3" width="3" height="8" rx="0.6" fill={c}/>
          <rect x="15" y="0" width="3" height="11" rx="0.6" fill={c}/>
        </svg>
        <svg width="26" height="12" viewBox="0 0 26 12">
          <rect x="0.5" y="0.5" width="22" height="11" rx="3" stroke={c} strokeOpacity="0.4" fill="none"/>
          <rect x="2" y="2" width="19" height="8" rx="1.5" fill={c}/>
          <rect x="23.5" y="4" width="1.5" height="4" rx="0.7" fill={c} fillOpacity="0.4"/>
        </svg>
      </div>
    </div>
  );
}

function STNavBar({ mode }) {
  const t = mode === 'dark' ? BC_DARK : BC_LIGHT;
  return (
    <div style={{ height: 44, padding: '0 8px', display: 'flex', alignItems: 'center' }}>
      <button style={{
        height: 32, padding: '0 8px 0 4px', border: 'none', background: 'transparent',
        display: 'inline-flex', alignItems: 'center', gap: 2,
        color: t.primary, fontSize: 17, letterSpacing: -0.41,
        fontFamily: SF_STACK, cursor: 'pointer',
      }}>
        <BCIcon name="chev" size={20} color={t.primary} style={{ transform: 'scaleX(-1)' }} />
        <span>Profile</span>
      </button>
      <div style={{ flex: 1, textAlign: 'center', fontSize: 17, fontWeight: 600, color: t.text, letterSpacing: -0.41 }}>
        Settings
      </div>
      <div style={{ width: 90 }} />
    </div>
  );
}

// ─── Group header ────────────────────────────────────────────────────
function SettingsGroupLabel({ mode, children, footer }) {
  const t = mode === 'dark' ? BC_DARK : BC_LIGHT;
  return (
    <>
      <div style={{
        padding: '22px 20px 6px',
        fontSize: 11, fontWeight: 700, letterSpacing: 0.6, textTransform: 'uppercase', color: t.textTer,
      }}>{children}</div>
      {footer && (
        <div style={{
          padding: '6px 20px 0',
          fontSize: 12, color: t.textSec, lineHeight: '16px',
        }}>{footer}</div>
      )}
    </>
  );
}

// ─── Row primitives ──────────────────────────────────────────────────
function STRow({ mode, icon, iconBg, title, value, accessory = 'chev', first, last, danger, onClick }) {
  const t = mode === 'dark' ? BC_DARK : BC_LIGHT;
  return (
    <button onClick={onClick} style={{
      width: '100%', textAlign: 'left',
      background: t.surface,
      borderTopLeftRadius: first ? BC_RADIUS.lg : 0,
      borderTopRightRadius: first ? BC_RADIUS.lg : 0,
      borderBottomLeftRadius: last ? BC_RADIUS.lg : 0,
      borderBottomRightRadius: last ? BC_RADIUS.lg : 0,
      borderTop: first ? '1px solid ' + t.separator : 'none',
      borderBottom: last ? '1px solid ' + t.separator : '0.5px solid ' + t.separator,
      borderLeft: '1px solid ' + t.separator,
      borderRight: '1px solid ' + t.separator,
      padding: icon ? '10px 14px' : '12px 14px',
      display: 'flex', alignItems: 'center', gap: 12,
      cursor: 'pointer', fontFamily: SF_STACK,
    }}>
      {icon && (
        <div style={{
          width: 30, height: 30, borderRadius: 7, flexShrink: 0,
          background: iconBg || t.primarySoft,
          color: iconBg ? '#fff' : t.primary,
          display: 'flex', alignItems: 'center', justifyContent: 'center',
        }}>{icon}</div>
      )}
      <div style={{ flex: 1, fontSize: 15, fontWeight: 500, color: danger ? t.danger : t.text, letterSpacing: -0.2 }}>{title}</div>
      {value && (
        <div style={{ fontSize: 14, color: t.textSec, fontWeight: 500, letterSpacing: -0.1, fontVariantNumeric: 'tabular-nums' }}>{value}</div>
      )}
      {accessory === 'chev' && <BCIcon name="chev" size={14} color={t.textTer} />}
      {accessory === 'switch-on'  && <BCSwitch on={true} />}
      {accessory === 'switch-off' && <BCSwitch on={false} />}
    </button>
  );
}

// ─── Profile header with avatar ──────────────────────────────────────
function ProfileHeader({ mode }) {
  const t = mode === 'dark' ? BC_DARK : BC_LIGHT;
  return (
    <div style={{
      padding: '12px 16px 0',
    }}>
      <div style={{
        background: t.surface, border: '1px solid ' + t.separator, borderRadius: BC_RADIUS.lg,
        padding: '16px',
        display: 'flex', alignItems: 'center', gap: 14,
      }}>
        <div style={{
          width: 64, height: 64, borderRadius: 999,
          background: t.teal, color: '#fff',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          fontSize: 22, fontWeight: 800, letterSpacing: 0.2, flexShrink: 0,
        }}>AM</div>
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ fontSize: 18, fontWeight: 800, color: t.text, letterSpacing: -0.3 }}>Alex Morgan</div>
          <div style={{ fontSize: 13, color: t.textSec, marginTop: 2 }}>alex@email.com</div>
          <div style={{ marginTop: 8, fontSize: 12, color: t.textSec, fontWeight: 500 }}>
            Member since May 2025 · 9-day streak
          </div>
        </div>
      </div>
    </div>
  );
}

// ─── Screen ──────────────────────────────────────────────────────────
function SettingsScreen({ mode = 'light' }) {
  const t = mode === 'dark' ? BC_DARK : BC_LIGHT;

  // ─── Tiny inline icons for setting rows ───
  const ic = (path, bg) => (
    <div style={{
      width: 30, height: 30, borderRadius: 7, flexShrink: 0,
      background: bg, color: '#fff',
      display: 'flex', alignItems: 'center', justifyContent: 'center',
    }}>
      <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#fff" strokeWidth="1.9" strokeLinecap="round" strokeLinejoin="round">{path}</svg>
    </div>
  );
  const iUser   = ic(<><circle cx="12" cy="8" r="3.5"/><path d="M5 20c0-3.5 3.1-6 7-6s7 2.5 7 6"/></>, '#0F6E56');
  const iCamera = ic(<><path d="M4 8a2 2 0 012-2h2l1.5-2h5L16 6h2a2 2 0 012 2v9a2 2 0 01-2 2H6a2 2 0 01-2-2z"/><circle cx="12" cy="13" r="3.5"/></>, '#185FA5');
  const iMail   = ic(<><rect x="3" y="5" width="18" height="14" rx="2"/><path d="M3 7l9 7 9-7"/></>, '#C8801C');
  const iCake   = ic(<><path d="M3 20V14h18v6"/><path d="M5 14V11a2 2 0 012-2h10a2 2 0 012 2v3"/><path d="M9 9V6M12 9V6M15 9V6"/></>, '#C8801C');
  const iVenus  = ic(<><circle cx="12" cy="9" r="5"/><path d="M12 14v8M8 19h8"/></>, '#7B61FF');
  const iRuler  = ic(<><path d="M2 8l6-6 14 14-6 6z"/><path d="M6 12l2 2M10 8l2 2M14 4l2 2"/></>, '#5C5C63');
  const iScale  = ic(<><rect x="3" y="3" width="18" height="18" rx="3"/><path d="M9 14a3 3 0 016 0"/><path d="M12 11V8"/></>, '#0F6E56');
  const iFlag   = ic(<><path d="M5 21V4l8 3 6-2v11l-6 2-8-3"/></>, '#D8362F');
  const iTarget = ic(<><circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="5"/><circle cx="12" cy="12" r="1.5" fill="#fff" stroke="none"/></>, '#185FA5');
  const iSpeed  = ic(<><path d="M5 18a7 7 0 0114 0"/><path d="M12 18l3-5"/></>, '#C8801C');
  const iChart  = ic(<><path d="M4 19V5"/><path d="M4 19h16"/><path d="M8 15l3-4 3 2 4-6"/></>, '#185FA5');
  const iBell   = ic(<><path d="M6 16V11a6 6 0 0112 0v5"/><path d="M4 17h16"/><path d="M10 20a2 2 0 004 0"/></>, '#C8801C');
  const iWeight = ic(<><rect x="3" y="6" width="18" height="14" rx="2"/><path d="M8 10v0M12 10v0M16 10v0"/></>, '#5C5C63');
  const iSpark  = ic(<><path d="M12 3v3M12 18v3M3 12h3M18 12h3M5.5 5.5l2 2M16.5 16.5l2 2M5.5 18.5l2-2M16.5 7.5l2-2"/></>, '#185FA5');
  const iFire   = ic(<><path d="M12 3.5c1.5 3 4.5 4.5 4.5 8.5a4.5 4.5 0 01-9 0c0-1.5.5-2.5 1.5-3.5C9.5 9.5 10 8 10 6.5c0-1 .5-2 2-3z"/></>, '#D8362F');
  const iHeart  = ic(<><path d="M12 21s-7-4.5-7-10a4 4 0 017-2.6A4 4 0 0119 11c0 5.5-7 10-7 10z" fill="#fff"/></>, '#FF3B30');
  const iBT     = ic(<><path d="M8 6l8 12-4 4V2l4 4-8 12"/></>, '#185FA5');
  const iDown   = ic(<><path d="M12 4v12M6 10l6 6 6-6M4 20h16"/></>, '#5C5C63');
  const iUp     = ic(<><path d="M12 20V8M18 14l-6-6-6 6M4 4h16"/></>, '#5C5C63');
  const iTrash  = ic(<><path d="M4 7h16"/><path d="M9 7V4h6v3"/><path d="M6 7l1 13a2 2 0 002 2h6a2 2 0 002-2l1-13"/></>, '#D8362F');
  const iStar   = ic(<><path d="M12 3l3 6 7 1-5 5 1 7-6-3-6 3 1-7-5-5 7-1z"/></>, '#F0A040');
  const iShare  = ic(<><path d="M12 3v14M7 8l5-5 5 5"/><path d="M5 13v6a2 2 0 002 2h10a2 2 0 002-2v-6"/></>, '#185FA5');
  const iShield = ic(<><path d="M12 3l8 4v6c0 5-4 8-8 8s-8-3-8-8V7z"/><path d="M9 12l2 2 4-4"/></>, '#0F6E56');
  const iDoc    = ic(<><path d="M6 3h9l3 3v15H6z"/><path d="M15 3v3h3"/><path d="M9 12h6M9 16h4"/></>, '#5C5C63');
  const iInfo   = ic(<><circle cx="12" cy="12" r="9"/><path d="M12 11v5"/><circle cx="12" cy="8" r="0.7" fill="#fff" stroke="none"/></>, '#5C5C63');

  return (
    <BCTheme mode={mode} padding={0} style={{ position: 'relative', overflow: 'hidden', height: '100%' }}>
      <STStatusBar mode={mode} />
      <STNavBar mode={mode} />

      <div style={{ position: 'absolute', top: 54 + 44, left: 0, right: 0, bottom: 0, overflowY: 'auto', overflowX: 'hidden' }}>
        <ProfileHeader mode={mode} />

        {/* Profile group */}
        <SettingsGroupLabel mode={mode}>Profile</SettingsGroupLabel>
        <div style={{ padding: '0 16px' }}>
          <STRow mode={mode} first icon={iUser}   title="Name"            value="Alex Morgan" />
          <STRow mode={mode}      icon={iCamera}  title="Profile photo"   value="Tap to change" />
          <STRow mode={mode}      icon={iMail}    title="Email"           value="alex@email.com" />
          <STRow mode={mode}      icon={iCake}    title="Birthday"        value="Mar 14, 1992" />
          <STRow mode={mode}      icon={iVenus}   title="Biological sex"  value="Female" />
          <STRow mode={mode}      icon={iRuler}   title="Height"          value="5′ 7″" />
          <STRow mode={mode} last icon={iScale}   title="Units"           value="Imperial" />
        </div>

        {/* Goals group */}
        <SettingsGroupLabel mode={mode}>Goals</SettingsGroupLabel>
        <div style={{ padding: '0 16px' }}>
          <STRow mode={mode} first icon={iFlag}    title="Current goal"        value="Lose fat" />
          <STRow mode={mode}      icon={iTarget}  title="Goal weight"          value="175 lbs" />
          <STRow mode={mode}      icon={iSpeed}   title="Weekly pace"          value="−1 lb / week" />
          <STRow mode={mode} last icon={iChart}   title="Edit macro targets"   value="1,830 · 150 · 172 · 60" />
        </div>

        {/* Notifications */}
        <SettingsGroupLabel mode={mode}>Notifications</SettingsGroupLabel>
        <div style={{ padding: '0 16px' }}>
          <STRow mode={mode} first icon={iBell}   title="Daily log reminder"   value="7:30 PM" accessory="chev" />
          <STRow mode={mode}      icon={iWeight} title="Weigh-in reminder"    value="Sun · 8:00 AM" accessory="chev" />
          <STRow mode={mode}      icon={iSpark}  title="Weekly coach summary" accessory="switch-on" />
          <STRow mode={mode} last icon={iFire}   title="Streak alerts"        accessory="switch-on" />
        </div>

        {/* Integrations */}
        <SettingsGroupLabel mode={mode} footer="Sync nutrition to Apple Health, weight to/from your scale.">
          Integrations
        </SettingsGroupLabel>
        <div style={{ padding: '8px 16px 0' }}>
          <STRow mode={mode} first icon={iHeart} title="Apple Health"        value="Connected" />
          <STRow mode={mode} last  icon={iBT}    title="Connected scale"     value="Withings · linked" />
        </div>

        {/* Data */}
        <SettingsGroupLabel mode={mode}>Data</SettingsGroupLabel>
        <div style={{ padding: '0 16px' }}>
          <STRow mode={mode} first icon={iDown}  title="Export my data (CSV)" />
          <STRow mode={mode}      icon={iUp}    title="Import data" />
          <STRow mode={mode} last icon={iTrash} title="Delete all data" danger accessory="chev" />
        </div>

        {/* About */}
        <SettingsGroupLabel mode={mode}>About</SettingsGroupLabel>
        <div style={{ padding: '0 16px' }}>
          <STRow mode={mode} first icon={iStar}   title="Rate BluCal" />
          <STRow mode={mode}      icon={iShare}  title="Share BluCal" />
          <STRow mode={mode}      icon={iShield} title="Privacy policy" />
          <STRow mode={mode}      icon={iDoc}    title="Terms of service" />
          <STRow mode={mode} last icon={iInfo}   title="Version" value="1.0.4 · build 41" accessory="" />
        </div>

        <div style={{ padding: '24px 20px 36px', textAlign: 'center', fontSize: 12, color: t.textTer }}>
          Made with care · BluCal © 2026
        </div>
      </div>
    </BCTheme>
  );
}

Object.assign(window, { SettingsScreen });
