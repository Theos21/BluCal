// today-screen.jsx — BluCal Today tab, interactive

// Per-entry timeline glyph: vertical line + dot
function TimelineDot({ first, last, color, isWater }) {
  return (
    <div style={{ position: 'relative', width: 8, alignSelf: 'stretch', flexShrink: 0 }}>
      <div style={{
        position: 'absolute', top: first ? 18 : 0, bottom: last ? 'calc(100% - 18px)' : 0,
        left: 3.5, width: 1, background: color,
      }} />
      <div style={{
        position: 'absolute', top: 14, left: 0,
        width: 8, height: 8, borderRadius: 999, background: isWater ? color : 'transparent',
        border: `2px solid ${color}`,
        boxSizing: 'border-box',
      }} />
    </div>
  );
}

function LogEntry({ time, name, portion, kcal, p, c, f, first, last, onTap }) {
  const { t } = useBC();
  return (
    <div onClick={onTap} style={{
      display: 'flex', gap: 14, padding: '4px 0',
      cursor: 'pointer', WebkitTapHighlightColor: 'transparent',
    }}>
      {/* timestamp */}
      <div style={{
        width: 38, paddingTop: 12, flexShrink: 0,
        fontSize: 12, fontWeight: 600, color: t.textTer, letterSpacing: 0.1,
        fontVariantNumeric: 'tabular-nums', textAlign: 'right',
      }}>{time}</div>
      {/* timeline */}
      <TimelineDot first={first} last={last} color={t.primary} />
      {/* card */}
      <div style={{
        flex: 1,
        background: t.surface, borderRadius: BC_RADIUS.md,
        border: '1px solid ' + t.separator,
        padding: '12px 14px',
        display: 'flex', alignItems: 'center', gap: 12,
        marginBottom: 6,
      }}>
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{
            fontSize: 15, fontWeight: 600, color: t.text, letterSpacing: -0.24,
            whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis',
          }}>{name}</div>
          <div style={{
            fontSize: 12, color: t.textSec, marginTop: 1,
            whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis',
          }}>{portion}</div>
        </div>
        <div style={{ textAlign: 'right', flexShrink: 0 }}>
          <div style={{ fontSize: 15, fontWeight: 700, color: t.text, letterSpacing: -0.24, fontVariantNumeric: 'tabular-nums' }}>
            {kcal} <span style={{ fontSize: 10, color: t.textTer, fontWeight: 600 }}>kcal</span>
          </div>
          <div style={{
            fontSize: 11, color: t.textTer, marginTop: 2,
            fontFamily: 'ui-monospace, SFMono-Regular, Menlo, monospace',
            fontVariantNumeric: 'tabular-nums',
          }}>
            <span style={{ color: t.protein, fontWeight: 600 }}>{p}p</span>
            <span style={{ margin: '0 4px', opacity: 0.4 }}>·</span>
            <span style={{ color: t.carbs, fontWeight: 600 }}>{c}c</span>
            <span style={{ margin: '0 4px', opacity: 0.4 }}>·</span>
            <span style={{ color: t.fat, fontWeight: 600 }}>{f}f</span>
          </div>
        </div>
      </div>
    </div>
  );
}

// Status bar — simple, matches iOS look
function StatusBar({ mode }) {
  const c = mode === 'dark' ? '#fff' : '#000';
  return (
    <div style={{
      height: 54, padding: '14px 28px 0',
      display: 'flex', alignItems: 'center', justifyContent: 'space-between',
      fontSize: 17, fontWeight: 600, letterSpacing: -0.41, color: c,
      fontFamily: SF_STACK,
    }}>
      <span style={{ fontVariantNumeric: 'tabular-nums' }}>9:41</span>
      <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
        {/* signal */}
        <svg width="18" height="11" viewBox="0 0 18 11">
          <rect x="0" y="7" width="3" height="4" rx="0.6" fill={c}/>
          <rect x="5" y="5" width="3" height="6" rx="0.6" fill={c}/>
          <rect x="10" y="3" width="3" height="8" rx="0.6" fill={c}/>
          <rect x="15" y="0" width="3" height="11" rx="0.6" fill={c}/>
        </svg>
        {/* battery */}
        <svg width="26" height="12" viewBox="0 0 26 12">
          <rect x="0.5" y="0.5" width="22" height="11" rx="3" stroke={c} strokeOpacity="0.4" fill="none"/>
          <rect x="2" y="2" width="19" height="8" rx="1.5" fill={c}/>
          <rect x="23.5" y="4" width="1.5" height="4" rx="0.7" fill={c} fillOpacity="0.4"/>
        </svg>
      </div>
    </div>
  );
}

function MiniMacro({ name, color, cur, target }) {
  const { t } = useBC();
  const pct = Math.min(1, cur / target);
  return (
    <div style={{ flex: 1 }}>
      <div style={{ display: 'flex', alignItems: 'baseline', justifyContent: 'space-between', marginBottom: 5 }}>
        <span style={{ fontSize: 12, fontWeight: 700, color: t.text, letterSpacing: 0.1 }}>{name}</span>
        <span style={{ fontSize: 11, color: t.textSec, fontVariantNumeric: 'tabular-nums' }}>
          <span style={{ fontWeight: 700, color: t.text }}>{cur}</span>
          <span style={{ opacity: 0.6 }}> / {target}g</span>
        </span>
      </div>
      <div style={{ height: 6, background: t.surface2, borderRadius: 6, overflow: 'hidden' }}>
        <div style={{
          height: '100%', width: (pct * 100) + '%',
          background: color, borderRadius: 6,
          transition: 'width .35s cubic-bezier(.4,.7,.2,1)',
        }} />
      </div>
    </div>
  );
}

function WaterDroplet({ size = 22, color }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none">
      <path d="M12 3.5C12 3.5 6 10 6 14.5a6 6 0 0 0 12 0C18 10 12 3.5 12 3.5Z"
        stroke={color} strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"/>
      <path d="M9 14.5a3 3 0 0 0 3 3" stroke={color} strokeWidth="1.8" strokeLinecap="round" strokeOpacity="0.5"/>
    </svg>
  );
}

function TodayScreen({ mode }) {
  const t = mode === 'dark' ? BC_DARK : BC_LIGHT;
  const [water, setWater] = React.useState(48);
  const [sheet, setSheet] = React.useState(null);   // 'log' | 'entry' | null
  const [activeTab, setActiveTab] = React.useState(0);
  const [selectedEntry, setSelectedEntry] = React.useState(null);

  const waterTarget = 80;
  const kcalConsumed = 1482;
  const kcalTarget = 2000;
  const kcalPct = kcalConsumed / kcalTarget;

  const macros = [
    { name: 'Protein', color: t.protein, cur: 87,  target: 140 },
    { name: 'Carbs',   color: t.carbs,   cur: 149, target: 250 },
    { name: 'Fat',     color: t.fat,     cur: 49,  target: 65 },
  ];

  const entries = [
    { time: '7:18a',  name: 'Greek yogurt + granola',     portion: '1 cup + ¼ cup',           kcal: 322, p: 18, c: 42, f: 8 },
    { time: '8:42a',  name: 'Oat milk latte',             portion: '12 oz · oat milk',        kcal: 110, p: 4,  c: 15, f: 3 },
    { time: '12:24p', name: 'Chipotle bowl',              portion: 'double chicken, brown rice', kcal: 715, p: 56, c: 52, f: 22 },
    { time: '3:10p',  name: 'Apple + peanut butter',      portion: '1 medium + 2 tbsp',       kcal: 280, p: 8,  c: 30, f: 16 },
    { time: '5:30p',  name: 'Cold brew',                  portion: '16 oz · black',           kcal: 5,   p: 0,  c: 0,  f: 0 },
    { time: '6:15p',  name: 'Mini pretzels',              portion: 'small bag',               kcal: 50,  p: 1,  c: 10, f: 0 },
  ];

  return (
    <BCTheme mode={mode} padding={0} style={{ position: 'relative', overflow: 'hidden', height: '100%' }}>
      <StatusBar mode={mode} />

      {/* Scroll region */}
      <div style={{
        position: 'absolute', top: 54, left: 0, right: 0, bottom: 0,
        overflowY: 'auto', overflowX: 'hidden',
      }}>
        {/* Header */}
        <div style={{ padding: '8px 20px 4px', display: 'flex', alignItems: 'flex-start' }}>
          <div style={{ flex: 1 }}>
            <BCType scale="largeTitle" style={{ letterSpacing: -0.8 }}>Today</BCType>
            <div style={{ fontSize: 14, color: t.textSec, marginTop: 2, fontWeight: 500, letterSpacing: -0.2 }}>
              Tuesday, May 12
            </div>
          </div>
          {/* Avatar */}
          <div style={{
            width: 38, height: 38, borderRadius: 999,
            background: t.teal, color: '#fff',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            fontSize: 14, fontWeight: 700, letterSpacing: 0.2,
            boxShadow: mode === 'dark'
              ? '0 0 0 2px ' + t.surface
              : '0 0 0 2px ' + t.bg,
          }}>AM</div>
        </div>

        {/* Macro summary card */}
        <div style={{ padding: '14px 16px 0' }}>
          <div style={{
            background: t.surface, borderRadius: BC_RADIUS.lg,
            border: '1px solid ' + t.separator,
            padding: 18,
          }}>
            <div style={{ display: 'flex', alignItems: 'baseline', justifyContent: 'space-between' }}>
              <div>
                <div style={{ fontSize: 11, fontWeight: 700, letterSpacing: 0.8, color: t.textTer, textTransform: 'uppercase' }}>
                  Calories
                </div>
                <div style={{ display: 'flex', alignItems: 'baseline', gap: 6, marginTop: 6 }}>
                  <span style={{ fontSize: 36, fontWeight: 700, color: t.text, letterSpacing: -1, fontVariantNumeric: 'tabular-nums', lineHeight: 1 }}>
                    {kcalConsumed.toLocaleString()}
                  </span>
                  <span style={{ fontSize: 17, color: t.textSec, fontWeight: 500, letterSpacing: -0.41 }}>
                    / {kcalTarget.toLocaleString()}
                  </span>
                </div>
              </div>
              <div style={{ textAlign: 'right' }}>
                <div style={{ fontSize: 11, fontWeight: 700, letterSpacing: 0.8, color: t.textTer, textTransform: 'uppercase' }}>
                  Left
                </div>
                <div style={{ fontSize: 22, fontWeight: 700, color: t.primary, marginTop: 6, letterSpacing: -0.4, fontVariantNumeric: 'tabular-nums', lineHeight: 1 }}>
                  {(kcalTarget - kcalConsumed).toLocaleString()}
                </div>
              </div>
            </div>

            {/* main progress bar */}
            <div style={{
              height: 8, background: t.surface2, borderRadius: 8, marginTop: 14, overflow: 'hidden',
              border: '1px solid ' + t.separator,
            }}>
              <div style={{
                height: '100%', width: (kcalPct * 100) + '%',
                background: t.primary, borderRadius: 8,
                transition: 'width .35s cubic-bezier(.4,.7,.2,1)',
              }} />
            </div>

            <div style={{ height: 1, background: t.separator, margin: '16px -2px 14px' }} />

            <div style={{ display: 'flex', gap: 16 }}>
              {macros.map(m => <MiniMacro key={m.name} {...m} />)}
            </div>
          </div>
        </div>

        {/* Water tracker */}
        <div style={{ padding: '12px 16px 0' }}>
          <div style={{
            background: t.surface, borderRadius: BC_RADIUS.lg,
            border: '1px solid ' + t.separator,
            padding: '14px 16px',
            display: 'flex', alignItems: 'center', gap: 14,
          }}>
            <div style={{
              width: 44, height: 44, borderRadius: 12,
              background: t.primarySoft, color: t.primary,
              display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0,
            }}>
              <WaterDroplet color={t.primary} size={24} />
            </div>
            <div style={{ flex: 1, minWidth: 0 }}>
              <div style={{ fontSize: 11, fontWeight: 700, letterSpacing: 0.8, color: t.textTer, textTransform: 'uppercase' }}>
                Water
              </div>
              <div style={{ marginTop: 4, fontSize: 17, fontWeight: 600, color: t.text, letterSpacing: -0.41, fontVariantNumeric: 'tabular-nums' }}>
                {water} <span style={{ color: t.textSec, fontWeight: 500 }}>/ {waterTarget} oz</span>
              </div>
              {/* sub bar */}
              <div style={{ height: 4, background: t.surface2, borderRadius: 4, marginTop: 8, overflow: 'hidden' }}>
                <div style={{
                  height: '100%', width: Math.min(100, (water / waterTarget) * 100) + '%',
                  background: t.primary, borderRadius: 4, transition: 'width .3s',
                }} />
              </div>
            </div>
            <div style={{ display: 'flex', gap: 6, flexShrink: 0 }}>
              <button onClick={() => setWater(w => Math.min(160, w + 8))} style={{
                height: 36, padding: '0 12px', borderRadius: 10,
                background: t.primarySoft, color: t.primary, border: 'none',
                fontSize: 13, fontWeight: 700, fontFamily: SF_STACK, letterSpacing: -0.1,
                cursor: 'pointer', display: 'flex', alignItems: 'center', gap: 2,
              }}>+8<span style={{ fontSize: 10, opacity: 0.7 }}>oz</span></button>
              <button onClick={() => setWater(w => Math.min(160, w + 16))} style={{
                height: 36, padding: '0 12px', borderRadius: 10,
                background: t.primarySoft, color: t.primary, border: 'none',
                fontSize: 13, fontWeight: 700, fontFamily: SF_STACK, letterSpacing: -0.1,
                cursor: 'pointer', display: 'flex', alignItems: 'center', gap: 2,
              }}>+16<span style={{ fontSize: 10, opacity: 0.7 }}>oz</span></button>
            </div>
          </div>
        </div>

        {/* Food log header */}
        <div style={{ padding: '24px 20px 8px', display: 'flex', alignItems: 'flex-end', justifyContent: 'space-between' }}>
          <div>
            <div style={{ fontSize: 11, fontWeight: 700, letterSpacing: 0.8, color: t.textTer, textTransform: 'uppercase' }}>
              Food log
            </div>
            <div style={{ fontSize: 17, fontWeight: 700, color: t.text, marginTop: 2, letterSpacing: -0.41 }}>
              Tue, May 12 · 6 entries
            </div>
          </div>
          <div style={{ fontSize: 14, fontWeight: 600, color: t.primary, letterSpacing: -0.2 }}>
            Edit
          </div>
        </div>

        {/* Timeline list */}
        <div style={{ padding: '4px 16px 0' }}>
          {entries.map((e, i) => (
            <LogEntry key={i} {...e}
              first={i === 0}
              last={false}
              onTap={() => { setSelectedEntry(e); setSheet('entry'); }}
            />
          ))}

          {/* Dashed log button — sits on the timeline */}
          <div style={{ display: 'flex', gap: 14, padding: '4px 0' }}>
            <div style={{ width: 38, flexShrink: 0 }} />
            <div style={{ position: 'relative', width: 8, alignSelf: 'stretch', flexShrink: 0 }}>
              <div style={{
                position: 'absolute', top: 0, bottom: 'calc(100% - 18px)',
                left: 3.5, width: 1, background: t.primary,
              }} />
            </div>
            <button onClick={() => setSheet('log')} style={{
              flex: 1, height: 52, borderRadius: BC_RADIUS.md,
              border: `1.5px dashed ${t.primary}`,
              background: 'transparent',
              color: t.primary,
              fontSize: 15, fontWeight: 700, fontFamily: SF_STACK, letterSpacing: -0.2,
              display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8,
              cursor: 'pointer',
            }}>
              <BCIcon name="plus" size={18} color={t.primary} strokeWidth={2.2} />
              Log food
            </button>
          </div>
        </div>

        {/* bottom padding for tab bar + FAB */}
        <div style={{ height: 110 }} />
      </div>

      {/* FAB — sits above tab bar */}
      <div style={{
        position: 'absolute', right: 18, bottom: 96, zIndex: 8,
      }}>
        <button onClick={() => setSheet('log')} style={{
          width: 56, height: 56, borderRadius: 28,
          background: t.primary, color: '#fff', border: 'none',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          cursor: 'pointer',
          boxShadow: '0 8px 22px rgba(24,95,165,0.45), 0 2px 6px rgba(0,0,0,0.12)',
        }}>
          <BCIcon name="plus" size={28} color="#fff" strokeWidth={2.4} />
        </button>
      </div>

      {/* Tab bar fixed at bottom */}
      <div style={{
        position: 'absolute', left: 0, right: 0, bottom: 0, zIndex: 6,
        background: t.surface,
        borderTop: '0.5px solid ' + t.separator,
        // backdrop-filter trick gives that iOS translucent feel even though we don't have real blur target
        backdropFilter: 'blur(20px)',
      }}>
        <BCTabBarLive active={activeTab} onChange={setActiveTab} />
        <div style={{
          height: 14, display: 'flex', justifyContent: 'center', alignItems: 'flex-end',
          paddingBottom: 6,
        }}>
          <div style={{
            width: 134, height: 5, borderRadius: 999,
            background: mode === 'dark' ? 'rgba(255,255,255,0.6)' : 'rgba(0,0,0,0.3)',
          }} />
        </div>
      </div>

      {/* Log food bottom sheet */}
      {sheet === 'log' && (
        <BCBottomSheet title="Log food" dismiss height={420}>
          <VStack gap={6}>
            <BCSearch placeholder="Search foods, brands or restaurants" />
            <div style={{ height: 8 }} />
            {[
              { label: 'Scan barcode',      icon: 'barcode' },
              { label: 'Voice log',         icon: 'mic' },
              { label: 'Quick add calories',icon: 'plus' },
              { label: 'Recent foods',      icon: 'fork' },
            ].map((it, i) => (
              <BCRow key={i}
                thumb={<div style={{
                  width: 40, height: 40, borderRadius: BC_RADIUS.sm,
                  background: t.primarySoft, display: 'flex', alignItems: 'center', justifyContent: 'center',
                }}><BCIcon name={it.icon} size={20} color={t.primary} /></div>}
                title={it.label}
                chev
                divider={i < 3}
                style={{ padding: '10px 0' }}
              />
            ))}
          </VStack>
          {/* close on backdrop */}
          <div onClick={() => setSheet(null)} style={{ position: 'absolute', inset: 0, top: -200, zIndex: -1 }} />
        </BCBottomSheet>
      )}
      {sheet === 'log' && (
        <div onClick={() => setSheet(null)} style={{ position: 'absolute', inset: 0, zIndex: 9, background: 'transparent' }} />
      )}

      {/* Action sheet on log entry */}
      {sheet === 'entry' && selectedEntry && (
        <>
          <div onClick={() => setSheet(null)} style={{
            position: 'absolute', inset: 0, background: t.scrim, zIndex: 10,
          }} />
          <div style={{ position: 'absolute', inset: 0, zIndex: 11, pointerEvents: 'none' }}>
            <BCActionSheet
              items={[
                { label: selectedEntry.name, detail: `${selectedEntry.kcal} kcal`, emphasis: false },
                { label: 'Edit serving size', emphasis: true },
                { label: 'Move to dinner' },
                { label: 'Save as favorite' },
                { label: 'Delete entry', destructive: true },
              ]}
            />
          </div>
        </>
      )}
    </BCTheme>
  );
}

// Tabbar with click handling for prototype
function BCTabBarLive({ active, onChange }) {
  const { t } = useBC();
  const tabs = [
    { name: 'Today',  icon: 'flame' },
    { name: 'Trends', icon: 'chart' },
    { name: 'Meals',  icon: 'fork' },
    { name: 'Coach',  icon: 'spark' },
    { name: 'Profile',icon: 'user' },
  ];
  return (
    <div style={{
      paddingTop: 8, display: 'flex',
    }}>
      {tabs.map((tb, i) => {
        const isActive = i === active;
        const c = isActive ? t.primary : t.textTer;
        const inactiveTabColor = '#8E8E93';
        return (
          <div key={tb.name} onClick={() => onChange(i)} style={{
            flex: 1, cursor: 'pointer',
            display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 3,
            WebkitTapHighlightColor: 'transparent',
          }}>
            {tb.name === 'Today' ? (
              <BluCalMark size={26} color={isActive ? t.primary : inactiveTabColor} />
            ) : (
              <BCIcon name={tb.icon} size={26} color={c} strokeWidth={isActive ? 2.2 : 1.8} />
            )}
            <div style={{ fontSize: 10, fontWeight: 600, color: c, letterSpacing: 0.1 }}>{tb.name}</div>
          </div>
        );
      })}
    </div>
  );
}

// Phone-shaped wrapper (no real device frame chrome; isolated rounded rect)
function PhoneShell({ width = 390, height = 844, mode, children }) {
  return (
    <div style={{
      width, height,
      borderRadius: 48,
      overflow: 'hidden',
      position: 'relative',
      background: mode === 'dark' ? BC_DARK.bg : BC_LIGHT.bg,
      boxShadow: mode === 'dark'
        ? '0 30px 60px -10px rgba(0,0,0,0.55), 0 0 0 8px #2D3035, 0 0 0 9px rgba(255,255,255,0.05)'
        : '0 30px 60px -10px rgba(20,30,40,0.20), 0 0 0 8px #1a1a1d',
    }}>
      {/* Dynamic island */}
      <div style={{
        position: 'absolute', top: 11, left: '50%', transform: 'translateX(-50%)',
        width: 124, height: 36, borderRadius: 999, background: '#000', zIndex: 100,
      }} />
      {children}
    </div>
  );
}

Object.assign(window, { TodayScreen, PhoneShell });
