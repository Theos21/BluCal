// trends-screen.jsx — Trends tab with calorie/weight/macro/momentum/energy cards

// ─── Status / nav ─────────────────────────────────────────────────────
function TRStatusBar({ mode }) {
  const c = mode === 'dark' ? '#fff' : '#000';
  return (
    <div style={{
      height: 54, padding: '14px 28px 0',
      display: 'flex', alignItems: 'center', justifyContent: 'space-between',
      fontSize: 17, fontWeight: 600, letterSpacing: -0.41, color: c,
      fontFamily: SF_STACK,
    }}>
      <span style={{ fontVariantNumeric: 'tabular-nums' }}>9:41</span>
      <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
        <svg width="18" height="11" viewBox="0 0 18 11">
          <rect x="0" y="7" width="3" height="4" rx="0.6" fill={c}/>
          <rect x="5" y="5" width="3" height="6" rx="0.6" fill={c}/>
          <rect x="10" y="3" width="3" height="8" rx="0.6" fill={c}/>
          <rect x="15" y="0" width="3" height="11" rx="0.6" fill={c}/>
        </svg>
        <svg width="26" height="12" viewBox="0 0 26 12">
          <rect x="0.5" y="0.5" width="22" height="11" rx="3" stroke={c} strokeOpacity="0.4" fill="none"/>
          <rect x="2" y="2" width="19" height="8" rx="1.5" fill={c}/>
          <rect x="23.5" y="4" width="1.5" height="4" rx="0.7" fill={c} fillOpacity="0.4"/>
        </svg>
      </div>
    </div>
  );
}

// ─── Card shell ───────────────────────────────────────────────────────
function TRCard({ mode, title, sub, right, children }) {
  const t = mode === 'dark' ? BC_DARK : BC_LIGHT;
  return (
    <div style={{
      background: t.surface, border: '1px solid ' + t.separator, borderRadius: BC_RADIUS.lg,
      padding: '14px 16px 16px',
    }}>
      <div style={{ display: 'flex', alignItems: 'baseline', gap: 10 }}>
        <div style={{ flex: 1 }}>
          <div style={{ fontSize: 11, fontWeight: 700, letterSpacing: 0.6, textTransform: 'uppercase', color: t.textTer }}>{title}</div>
          {sub && <div style={{ fontSize: 14, color: t.text, marginTop: 4, fontWeight: 600, letterSpacing: -0.2 }}>{sub}</div>}
        </div>
        {right}
      </div>
      <div style={{ marginTop: 12 }}>{children}</div>
    </div>
  );
}

// ─── Calorie trend line chart ─────────────────────────────────────────
// 14 days of values; target 2000.
const CAL_DATA = [1820, 2110, 1640, 2270, 1950, 1730, 2050, 1880, 2020, 1760, 2180, 1920, 1670, 1847];
const CAL_LABELS = ['M', 'T', 'W', 'T', 'F', 'S', 'S', 'M', 'T', 'W', 'T', 'F', 'S', 'S'];
const CAL_TARGET = 2000;

function CalorieChart({ mode }) {
  const t = mode === 'dark' ? BC_DARK : BC_LIGHT;
  const W = 320, H = 130, PADX = 6, PADY = 14;
  const min = 1400, max = 2400;   // y-axis bounds
  const x = (i) => PADX + (i / (CAL_DATA.length - 1)) * (W - 2 * PADX);
  const y = (v) => PADY + (1 - (v - min) / (max - min)) * (H - 2 * PADY);
  const targetY = y(CAL_TARGET);

  // Line path
  const linePath = CAL_DATA.map((v, i) => `${i === 0 ? 'M' : 'L'} ${x(i).toFixed(1)} ${y(v).toFixed(1)}`).join(' ');
  // Area below line for soft fill
  const areaPath = `${linePath} L ${x(CAL_DATA.length - 1)} ${H - PADY} L ${x(0)} ${H - PADY} Z`;

  return (
    <div style={{ position: 'relative' }}>
      <svg width="100%" viewBox={`0 0 ${W} ${H}`} preserveAspectRatio="none" style={{ display: 'block', overflow: 'visible' }}>
        {/* Y grid */}
        {[2400, 2000, 1600].map(g => (
          <line key={g} x1={PADX} x2={W - PADX} y1={y(g)} y2={y(g)} stroke={t.separator} strokeWidth="1" />
        ))}
        {/* Target line dashed */}
        <line x1={PADX} x2={W - PADX} y1={targetY} y2={targetY}
          stroke={t.teal} strokeWidth="1.6" strokeDasharray="6 4" opacity="0.95" />
        {/* Area fill */}
        <path d={areaPath} fill={t.primarySoft} />
        {/* Line */}
        <path d={linePath} fill="none" stroke={t.primary} strokeWidth="2.2" strokeLinejoin="round" strokeLinecap="round" />
        {/* Dots on each point */}
        {CAL_DATA.map((v, i) => (
          <circle key={i} cx={x(i)} cy={y(v)} r={i === CAL_DATA.length - 1 ? 4 : 2.4}
            fill={t.surface} stroke={t.primary} strokeWidth={i === CAL_DATA.length - 1 ? 2.5 : 1.6} />
        ))}
      </svg>
      {/* Target label */}
      <div style={{
        position: 'absolute', right: 8, top: targetY * (130 / 130) - 18 /* hack */,
        fontSize: 10, fontWeight: 700, color: t.teal, letterSpacing: 0.3, textTransform: 'uppercase',
      }}>Target 2,000</div>
      {/* x labels */}
      <div style={{ display: 'flex', justifyContent: 'space-between', padding: '6px 4px 0', fontSize: 10, color: t.textTer, fontWeight: 600 }}>
        {CAL_LABELS.filter((_, i) => i % 2 === 0).map((l, i) => <span key={i}>{l}</span>)}
      </div>
    </div>
  );
}

// ─── Weight chart (dots + trend line) ─────────────────────────────────
const WEIGHT_DATA = [184.2, 184.0, 183.6, 183.9, 183.1, 182.7, 183.2, 182.8, 182.4, 182.0, 182.3, 181.6, 181.2, 181.4, 181.0, 180.6, 180.4, 180.1, 180.3, 179.7, 179.4, 179.0, 178.8, 179.1, 178.5, 178.2, 178.0, 177.7];
const WEIGHT_GOAL = 175;
const WEIGHT_TREND_SLOPE = (WEIGHT_DATA[WEIGHT_DATA.length - 1] - WEIGHT_DATA[0]) / (WEIGHT_DATA.length - 1);

function WeightChart({ mode }) {
  const t = mode === 'dark' ? BC_DARK : BC_LIGHT;
  const W = 320, H = 130, PADX = 6, PADY = 14;
  const min = 176, max = 186;
  const x = (i) => PADX + (i / (WEIGHT_DATA.length - 1)) * (W - 2 * PADX);
  const y = (v) => PADY + (1 - (v - min) / (max - min)) * (H - 2 * PADY);

  // Trend line — straight from first to last via linear fit
  const n = WEIGHT_DATA.length;
  const mean = WEIGHT_DATA.reduce((a, b) => a + b) / n;
  let xy = 0, xx = 0;
  for (let i = 0; i < n; i++) {
    xy += (i - (n - 1) / 2) * (WEIGHT_DATA[i] - mean);
    xx += (i - (n - 1) / 2) ** 2;
  }
  const slope = xy / xx;
  const trendV = (i) => mean + slope * (i - (n - 1) / 2);
  const trendPath = `M ${x(0)} ${y(trendV(0))} L ${x(n - 1)} ${y(trendV(n - 1))}`;
  // Goal line
  const goalY = y(WEIGHT_GOAL);

  return (
    <div style={{ position: 'relative' }}>
      <svg width="100%" viewBox={`0 0 ${W} ${H}`} preserveAspectRatio="none" style={{ display: 'block', overflow: 'visible' }}>
        {/* Grid */}
        {[186, 183, 180, 177].map(g => (
          <line key={g} x1={PADX} x2={W - PADX} y1={y(g)} y2={y(g)} stroke={t.separator} strokeWidth="1" />
        ))}
        {/* Goal line dashed */}
        <line x1={PADX} x2={W - PADX} y1={goalY} y2={goalY}
          stroke={t.success} strokeWidth="1.6" strokeDasharray="6 4" opacity="0.9" />
        {/* Trend line */}
        <path d={trendPath} stroke={t.primary} strokeWidth="2.4" strokeLinecap="round" fill="none" />
        {/* Daily dots */}
        {WEIGHT_DATA.map((v, i) => (
          <circle key={i} cx={x(i)} cy={y(v)} r="2.2" fill={t.primary} opacity="0.55" />
        ))}
        {/* Last dot highlighted */}
        <circle cx={x(n - 1)} cy={y(WEIGHT_DATA[n - 1])} r="4.5" fill={t.surface} stroke={t.primary} strokeWidth="2.5" />
      </svg>
      <div style={{
        position: 'absolute', right: 8, top: goalY - 18,
        fontSize: 10, fontWeight: 700, color: t.success, letterSpacing: 0.3, textTransform: 'uppercase',
      }}>Goal 175</div>
    </div>
  );
}

// ─── Macro split donut (actual + target ring) ─────────────────────────
function MacroDonut({ mode, kind = 'actual' }) {
  const t = mode === 'dark' ? BC_DARK : BC_LIGHT;
  const data = kind === 'actual'
    ? { p: 26, c: 48, f: 26 }
    : { p: 30, c: 45, f: 25 };
  const size = 110, stroke = 18, r = (size - stroke) / 2;
  const C = 2 * Math.PI * r;
  // Build three arcs around the donut
  let start = 0;
  const seg = (frac, color) => {
    const len = C * (frac / 100);
    const out = (
      <circle cx={size / 2} cy={size / 2} r={r}
        stroke={color} strokeWidth={stroke} fill="none"
        strokeDasharray={`${len} ${C - len}`}
        strokeDashoffset={-C * (start / 100)}
        transform={`rotate(-90 ${size / 2} ${size / 2})`}
      />
    );
    start += frac;
    return out;
  };
  return (
    <div style={{ position: 'relative', width: size, height: size, flexShrink: 0 }}>
      <svg width={size} height={size}>
        {seg(data.p, t.protein)}
        {seg(data.c, t.carbs)}
        {seg(data.f, t.fat)}
      </svg>
      <div style={{
        position: 'absolute', inset: 0,
        display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center',
      }}>
        <div style={{ fontSize: 11, fontWeight: 700, color: t.textTer, letterSpacing: 0.4, textTransform: 'uppercase' }}>
          {kind === 'actual' ? 'Actual' : 'Target'}
        </div>
      </div>
    </div>
  );
}

// ─── Momentum bars ────────────────────────────────────────────────────
const MOMENTUM = [82, 76, 88, 92, 70, 64, 90, 85, 78, 95, 88, 72, 80, 84];

function MomentumBars({ mode }) {
  const t = mode === 'dark' ? BC_DARK : BC_LIGHT;
  const W = 320, H = 130, PADX = 6, PADY = 6;
  const bw = (W - 2 * PADX) / (MOMENTUM.length * 1.4);
  const gap = bw * 0.4;
  const color = (v) => v >= 80 ? t.success : v >= 65 ? t.warn : t.danger;
  return (
    <svg width="100%" viewBox={`0 0 ${W} ${H}`} preserveAspectRatio="none" style={{ display: 'block' }}>
      {[20, 40, 60, 80, 100].map(g => (
        <line key={g} x1={PADX} x2={W - PADX}
          y1={PADY + (1 - g / 100) * (H - 2 * PADY)}
          y2={PADY + (1 - g / 100) * (H - 2 * PADY)}
          stroke={t.separator} strokeWidth="1" />
      ))}
      {MOMENTUM.map((v, i) => {
        const bx = PADX + i * (bw + gap);
        const bh = ((v / 100) * (H - 2 * PADY));
        return (
          <rect key={i} x={bx} y={H - PADY - bh} width={bw} height={bh} rx="3" fill={color(v)} />
        );
      })}
    </svg>
  );
}

// ─── Energy + hunger lines ────────────────────────────────────────────
const ENERGY = [3.5, 4.0, 3.8, 4.2, 3.6, 3.0, 3.4, 4.0, 4.5, 4.2, 3.8, 3.6, 4.1, 4.3];
const HUNGER = [3.0, 2.6, 3.2, 2.4, 3.0, 3.6, 3.2, 2.8, 2.4, 2.6, 3.0, 3.4, 2.8, 2.6];

function EnergyHungerChart({ mode }) {
  const t = mode === 'dark' ? BC_DARK : BC_LIGHT;
  const W = 320, H = 130, PADX = 6, PADY = 10;
  const min = 1, max = 5;
  const x = (i) => PADX + (i / (ENERGY.length - 1)) * (W - 2 * PADX);
  const y = (v) => PADY + (1 - (v - min) / (max - min)) * (H - 2 * PADY);
  const pathOf = (arr) => arr.map((v, i) => `${i === 0 ? 'M' : 'L'} ${x(i).toFixed(1)} ${y(v).toFixed(1)}`).join(' ');
  return (
    <svg width="100%" viewBox={`0 0 ${W} ${H}`} preserveAspectRatio="none" style={{ display: 'block', overflow: 'visible' }}>
      {[5, 4, 3, 2, 1].map(g => (
        <line key={g} x1={PADX} x2={W - PADX} y1={y(g)} y2={y(g)} stroke={t.separator} strokeWidth="1" />
      ))}
      {/* Energy */}
      <path d={pathOf(ENERGY)} fill="none" stroke={t.teal} strokeWidth="2.2" strokeLinejoin="round" strokeLinecap="round" />
      {ENERGY.map((v, i) => (
        <circle key={`e${i}`} cx={x(i)} cy={y(v)} r="2.2" fill={t.teal} />
      ))}
      {/* Hunger */}
      <path d={pathOf(HUNGER)} fill="none" stroke={t.warn} strokeWidth="2.2" strokeLinejoin="round" strokeLinecap="round" strokeDasharray="0 0" />
      {HUNGER.map((v, i) => (
        <circle key={`h${i}`} cx={x(i)} cy={y(v)} r="2.2" fill={t.warn} />
      ))}
    </svg>
  );
}

// ─── Segmented time range ─────────────────────────────────────────────
function RangeSegmented({ mode, value, onChange }) {
  const t = mode === 'dark' ? BC_DARK : BC_LIGHT;
  const opts = ['7D', '30D', '90D', 'All'];
  return (
    <div style={{
      display: 'flex', padding: 3,
      background: t.surface2, borderRadius: 10,
      height: 36,
    }}>
      {opts.map(o => {
        const active = o === value;
        return (
          <button key={o} onClick={() => onChange(o)} style={{
            flex: 1, height: 30, border: 'none',
            background: active ? t.surface : 'transparent',
            color: t.text, fontSize: 13, fontWeight: active ? 700 : 500,
            borderRadius: 7,
            boxShadow: active ? '0 1px 3px rgba(0,0,0,0.1)' : 'none',
            cursor: 'pointer', fontFamily: SF_STACK,
          }}>{o}</button>
        );
      })}
    </div>
  );
}

// ─── Tab bar (reuse Today's live tabbar) ──────────────────────────────
function TRTabBar({ mode, active }) {
  const t = mode === 'dark' ? BC_DARK : BC_LIGHT;
  const tabs = [
    { name: 'Today',  icon: 'flame' },
    { name: 'Trends', icon: 'chart' },
    { name: 'Meals',  icon: 'fork' },
    { name: 'Coach',  icon: 'spark' },
    { name: 'Profile',icon: 'user' },
  ];
  return (
    <div style={{
      background: t.surface,
      borderTop: '0.5px solid ' + t.separator,
      paddingTop: 8,
    }}>
      <div style={{ display: 'flex' }}>
        {tabs.map((tb, i) => {
          const isActive = i === active;
          const c = isActive ? t.primary : t.textTer;
          const inactive = '#8E8E93';
          return (
            <div key={tb.name} style={{
              flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 3,
            }}>
              {tb.name === 'Today' ? (
                <BluCalMark size={26} color={isActive ? t.primary : inactive} />
              ) : (
                <BCIcon name={tb.icon} size={26} color={c} strokeWidth={isActive ? 2.2 : 1.8} />
              )}
              <div style={{ fontSize: 10, fontWeight: 600, color: c, letterSpacing: 0.1 }}>{tb.name}</div>
            </div>
          );
        })}
      </div>
      <div style={{ height: 14, display: 'flex', justifyContent: 'center', alignItems: 'flex-end', paddingBottom: 6 }}>
        <div style={{ width: 134, height: 5, borderRadius: 999, background: mode === 'dark' ? 'rgba(255,255,255,0.6)' : 'rgba(0,0,0,0.3)' }} />
      </div>
    </div>
  );
}

// ─── Screen ───────────────────────────────────────────────────────────
function TrendsScreen({ mode = 'light' }) {
  const t = mode === 'dark' ? BC_DARK : BC_LIGHT;
  const [range, setRange] = React.useState('30D');

  return (
    <BCTheme mode={mode} padding={0} style={{ position: 'relative', overflow: 'hidden', height: '100%' }}>
      <TRStatusBar mode={mode} />

      <div style={{ position: 'absolute', top: 54, left: 0, right: 0, bottom: 86, overflowY: 'auto', overflowX: 'hidden' }}>
        {/* Title + range */}
        <div style={{ padding: '8px 20px 4px' }}>
          <div style={{ fontSize: 34, fontWeight: 800, color: t.text, letterSpacing: -0.8, lineHeight: '41px' }}>Trends</div>
        </div>
        <div style={{ padding: '8px 16px 0' }}>
          <RangeSegmented mode={mode} value={range} onChange={setRange} />
        </div>

        {/* Cards */}
        <div style={{ padding: '14px 16px 24px', display: 'flex', flexDirection: 'column', gap: 12 }}>

          {/* Calories */}
          <TRCard mode={mode} title="Calories"
            sub={null}
            right={
              <div style={{ textAlign: 'right' }}>
                <div style={{ fontSize: 11, fontWeight: 700, color: t.textTer, letterSpacing: 0.4, textTransform: 'uppercase' }}>Avg this period</div>
                <div style={{ fontSize: 22, fontWeight: 800, color: t.text, letterSpacing: -0.5, fontVariantNumeric: 'tabular-nums', lineHeight: 1, marginTop: 4 }}>
                  1,847<span style={{ fontSize: 13, color: t.textSec, fontWeight: 600, marginLeft: 4 }}>kcal</span>
                </div>
              </div>
            }
          >
            <CalorieChart mode={mode} />
            <div style={{ display: 'flex', gap: 14, fontSize: 12, color: t.textSec, marginTop: 4 }}>
              <span style={{ display: 'inline-flex', alignItems: 'center', gap: 6 }}>
                <span style={{ display: 'inline-block', width: 12, height: 2, borderRadius: 2, background: t.primary }} /> Daily intake
              </span>
              <span style={{ display: 'inline-flex', alignItems: 'center', gap: 6 }}>
                <span style={{ display: 'inline-block', width: 12, height: 2, borderRadius: 2, background: t.teal,
                  backgroundImage: `linear-gradient(to right, ${t.teal} 50%, transparent 50%)`, backgroundSize: '6px 100%' }} />
                Target
              </span>
            </div>
          </TRCard>

          {/* Weight */}
          <TRCard mode={mode} title="Weight"
            right={
              <div style={{ textAlign: 'right' }}>
                <div style={{ fontSize: 11, fontWeight: 700, color: t.textTer, letterSpacing: 0.4, textTransform: 'uppercase' }}>Current</div>
                <div style={{ fontSize: 22, fontWeight: 800, color: t.text, letterSpacing: -0.5, fontVariantNumeric: 'tabular-nums', lineHeight: 1, marginTop: 4 }}>
                  177.7<span style={{ fontSize: 13, color: t.textSec, fontWeight: 600, marginLeft: 4 }}>lbs</span>
                </div>
              </div>
            }
          >
            <WeightChart mode={mode} />
            <div style={{
              marginTop: 10, padding: '10px 12px',
              background: t.surface2, borderRadius: 10,
              display: 'flex', gap: 12,
            }}>
              <div style={{ flex: 1 }}>
                <div style={{ fontSize: 11, fontWeight: 700, color: t.textTer, letterSpacing: 0.4, textTransform: 'uppercase' }}>Trend</div>
                <div style={{ fontSize: 14, fontWeight: 700, color: t.success, marginTop: 3, fontVariantNumeric: 'tabular-nums' }}>
                  −0.5 lbs / week
                </div>
              </div>
              <div style={{ width: 1, background: t.separator }} />
              <div style={{ flex: 1 }}>
                <div style={{ fontSize: 11, fontWeight: 700, color: t.textTer, letterSpacing: 0.4, textTransform: 'uppercase' }}>Goal</div>
                <div style={{ fontSize: 14, fontWeight: 700, color: t.text, marginTop: 3, fontVariantNumeric: 'tabular-nums' }}>
                  175 lbs · ~5 wks
                </div>
              </div>
            </div>
          </TRCard>

          {/* Macro split */}
          <TRCard mode={mode} title="Macro split"
            right={<span style={{ fontSize: 12, color: t.textSec, fontWeight: 600 }}>% of calories</span>}
          >
            <div style={{ display: 'flex', gap: 14, alignItems: 'center' }}>
              <MacroDonut mode={mode} kind="actual" />
              <MacroDonut mode={mode} kind="target" />
              <div style={{ flex: 1, minWidth: 0 }}>
                {[
                  ['Protein', t.protein, 26, 30],
                  ['Carbs',   t.carbs,   48, 45],
                  ['Fat',     t.fat,     26, 25],
                ].map(([label, color, actual, target]) => (
                  <div key={label} style={{ padding: '6px 0', borderBottom: '0.5px solid ' + t.separator }}>
                    <div style={{ display: 'flex', alignItems: 'baseline', gap: 6 }}>
                      <span style={{ width: 8, height: 8, borderRadius: 999, background: color }} />
                      <span style={{ fontSize: 12, fontWeight: 700, color: t.text }}>{label}</span>
                      <span style={{ marginLeft: 'auto', fontSize: 12, color: t.text, fontWeight: 700, fontVariantNumeric: 'tabular-nums' }}>
                        {actual}%
                      </span>
                      <span style={{ fontSize: 10, color: t.textTer, fontWeight: 600, fontVariantNumeric: 'tabular-nums' }}>
                        / {target}%
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </TRCard>

          {/* Momentum score */}
          <TRCard mode={mode} title="Momentum score"
            right={
              <div style={{ textAlign: 'right' }}>
                <div style={{ fontSize: 11, fontWeight: 700, color: t.textTer, letterSpacing: 0.4, textTransform: 'uppercase' }}>7-day avg</div>
                <div style={{ fontSize: 22, fontWeight: 800, color: t.success, letterSpacing: -0.5, fontVariantNumeric: 'tabular-nums', lineHeight: 1, marginTop: 4 }}>
                  84<span style={{ fontSize: 13, color: t.textSec, fontWeight: 600, marginLeft: 3 }}>/ 100</span>
                </div>
              </div>
            }
          >
            <MomentumBars mode={mode} />
            <div style={{ display: 'flex', gap: 14, fontSize: 12, color: t.textSec, marginTop: 6, justifyContent: 'flex-end' }}>
              <span style={{ display: 'inline-flex', alignItems: 'center', gap: 5 }}>
                <span style={{ width: 8, height: 8, borderRadius: 2, background: t.success }} /> 80+
              </span>
              <span style={{ display: 'inline-flex', alignItems: 'center', gap: 5 }}>
                <span style={{ width: 8, height: 8, borderRadius: 2, background: t.warn }} /> 65-79
              </span>
              <span style={{ display: 'inline-flex', alignItems: 'center', gap: 5 }}>
                <span style={{ width: 8, height: 8, borderRadius: 2, background: t.danger }} /> &lt;65
              </span>
            </div>
          </TRCard>

          {/* Energy + hunger */}
          <TRCard mode={mode} title="Energy & hunger"
            right={<span style={{ fontSize: 12, color: t.textSec, fontWeight: 600 }}>1 – 5 daily rating</span>}
          >
            <EnergyHungerChart mode={mode} />
            <div style={{ display: 'flex', gap: 14, fontSize: 12, color: t.textSec, marginTop: 4, justifyContent: 'space-between' }}>
              <span style={{ display: 'inline-flex', alignItems: 'center', gap: 6 }}>
                <span style={{ display: 'inline-block', width: 12, height: 2, borderRadius: 2, background: t.teal }} />
                <span style={{ color: t.text, fontWeight: 600 }}>Energy</span>
                <span style={{ color: t.textSec, fontWeight: 600 }}>avg 3.8</span>
              </span>
              <span style={{ display: 'inline-flex', alignItems: 'center', gap: 6 }}>
                <span style={{ display: 'inline-block', width: 12, height: 2, borderRadius: 2, background: t.warn }} />
                <span style={{ color: t.text, fontWeight: 600 }}>Hunger</span>
                <span style={{ color: t.textSec, fontWeight: 600 }}>avg 2.9</span>
              </span>
            </div>
          </TRCard>
        </div>
      </div>

      {/* Tab bar */}
      <div style={{ position: 'absolute', left: 0, right: 0, bottom: 0 }}>
        <TRTabBar mode={mode} active={1} />
      </div>
    </BCTheme>
  );
}

Object.assign(window, { TrendsScreen });
